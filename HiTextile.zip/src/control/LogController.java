package control;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.LogVO;
import model.StockVO;

public class LogController implements Initializable {
	@FXML
	private Button btnOk;
	@FXML
	private Button btnSave;
	@FXML
	private Button btnClear;
	@FXML
	private TableView<LogVO> log;
	private ObservableList<LogVO> logData = FXCollections.observableArrayList();
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		TableColumn colId = new TableColumn("���̵�");
		colId.setMaxWidth(100);
		colId.setMinWidth(100);
		colId.setStyle("-fx-alignment:CENTER");
		colId.setCellValueFactory(new PropertyValueFactory<>("id"));
		TableColumn colDepartment = new TableColumn("�μ�");
		colDepartment.setMaxWidth(80);
		colDepartment.setMinWidth(80);
		colDepartment.setCellValueFactory(new PropertyValueFactory<>("department"));
		TableColumn colLog_date = new TableColumn("�����");
		colLog_date.setMaxWidth(120);
		colLog_date.setMinWidth(120);
		colLog_date.setCellValueFactory(new PropertyValueFactory<>("log_date"));
		log.setItems(logData);
		log.getColumns().addAll(colId, colDepartment, colLog_date);
		LogList();

		btnOk.setOnAction(event -> handlerBtnOkAction(event));
		btnSave.setOnAction(event -> handlerBtnSaveAction(event));
		btnClear.setOnAction(event -> handlerBtnClearAction(event));
	}
	public void handlerBtnClearAction(ActionEvent event) {
		MemberDAO dao = new MemberDAO();
		dao.clearLog();
	}
	public void handlerBtnSaveAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/file_save3.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setScene(scene);
			mainMtage.setTitle("�α�����");
			mainMtage.setResizable(false);
			mainMtage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	public void handlerBtnOkAction(ActionEvent event) {
		Stage stage = (Stage) btnOk.getScene().getWindow();
		stage.close();
	}
	
	public void LogList() {
		Object data[][];
		LogVO model;
		ArrayList<String> title = new ArrayList<>();
		ArrayList<LogVO> list = new ArrayList<>();
		title = getColumnName();
		list = getInformation();
		int columnCount = title.size();
		int rowCount = list.size();
		data = new Object[rowCount][columnCount];
		for (int i = 0; i < rowCount; i++) {
			model = new LogVO();
			model = list.get(i);
			logData.add(model);
		}
	}
	
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<>();
		String sql = "select * from log";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) { }
		}
		return columnName;
	}
	
	public ArrayList<LogVO> getInformation() {
		ArrayList<LogVO> information = new ArrayList<>();
		String sql = "select * from log order by log_date desc";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		LogVO model = null;

		try { 
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				model = new LogVO();
				model.setId(rs.getString("id"));
				model.setDepartment(rs.getString("department"));
				model.setLog_date(rs.getString("log_date"));

				information.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return information;
	}
	
}
