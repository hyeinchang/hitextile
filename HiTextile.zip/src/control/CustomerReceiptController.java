package control;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;
import model.StockVO;
import model.TransactionVO;

public class CustomerReceiptController implements Initializable{
	@FXML
	private TextField txtMemberNo;
	@FXML
	private TextField txtCustomer;
	@FXML
	private Button btnCustomerSearch;
	@FXML
	private Button btnDelete;
	@FXML
	private TextField txtProduct1;
	@FXML
	private Button btnProduct1;
	@FXML
	private TextField txtCost1;
	@FXML
	private ComboBox<String> cbColour1;
	@FXML
	private TextField txtYard1;
	@FXML
	private TextField txtProduct2;
	@FXML
	private Button btnProduct2;
	@FXML
	private TextField txtCost2;
	@FXML
	private ComboBox<String> cbColour2;
	@FXML
	private TextField txtYard2;
	@FXML
	private TextField txtProduct3;
	@FXML
	private Button btnProduct3;
	@FXML
	private TextField txtCost3;
	@FXML
	private ComboBox<String> cbColour3;
	@FXML
	private TextField txtYard3;
	@FXML
	private TextField txtDiscount;
	@FXML
	private Button btnCal;
	@FXML
	private TextField txtPrice;
	@FXML
	private TextField txtContact1;
	@FXML
	private TextField txtContact2;
	@FXML
	private TextField txtAddress;
	@FXML
	private RadioButton rbBeforePayment;
	@FXML
	private RadioButton rbAfterPayment;
	@FXML
	private ToggleGroup paymentGroup;
	@FXML
	private RadioButton rbStock;
	@FXML
	private RadioButton rbHolding;
	@FXML
	private RadioButton rbComplete;
	@FXML
	private ToggleGroup deliveryGroup;
	@FXML
	private TextField txtMemo;
	@FXML
	private Button btnOk;
	@FXML
	private Button btnClear;
	@FXML
	private Button btnCancel;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		TransactionDAO dao = new TransactionDAO();
		StockDAO stockDao = null;
		
		TransactionVO model = null;
		StockVO fabric1 = null;
		StockVO fabric2 = null;
		StockVO fabric3 = null;
		String customer = "";
		String product1 = "";
		double yard1 = 0;
		String contact1 = "";
		String contact2 = "";
		String address = "";
		int price = 0;
		String pay = "";
		String delivery = "";
		String memo = "";
		String product2 = "";
		double yard2 = 0;
		String product3 = "";
		double yard3 = 0;
		int stock1 = 0;
		int stock2 = 0;
		int stock3 = 0;
		String colour1 = "";
		String colour2 = "";
		String colour3 = "";
		int cost1 = 0;
		int cost2 = 0;
		int cost3 = 0;
		double discount = 0;
		int memberNo = 0;

		dao = new TransactionDAO();
		model = new TransactionVO();
		model = dao.callReceiptInformation();

		memberNo = model.getMember_no();
		customer = model.getCustomerName();
		
		stock1 = model.getStock_no1();
		stock2 = model.getStock_no2();
		stock3 = model.getStock_no3();
		
		stockDao = new StockDAO();
		fabric1 = new StockVO();
		fabric1 = stockDao.callNameAndColourAndCost(stock1);
		product1 = fabric1.getFabric_name();
		colour1 = fabric1.getFabric_colour();
		cost1 = fabric1.getFabric_cost();
		txtProduct1.setText(product1);
		txtCost1.setText(cost1+"");
		cbColour1.setItems(FXCollections.observableArrayList(colour1));
		cbColour1.getSelectionModel().select(0);
		
		fabric2 = new StockVO();
		fabric2 = stockDao.callNameAndColourAndCost(stock2);
		product2 = fabric2.getFabric_name();
		colour2 = fabric2.getFabric_colour();
		cost2 = fabric2.getFabric_cost();
		txtProduct2.setText(product2);
		txtCost2.setText(cost2+"");
		cbColour2.setItems(FXCollections.observableArrayList(colour2));
		cbColour2.getSelectionModel().select(0);
		
		fabric3 = new StockVO();
		fabric3 = stockDao.callNameAndColourAndCost(stock3);
		product3 = fabric3.getFabric_name();
		colour3 = fabric3.getFabric_colour();
		cost3 = fabric3.getFabric_cost();
		txtProduct3.setText(product3);
		txtCost3.setText(cost3+"");
		cbColour3.setItems(FXCollections.observableArrayList(colour3));
		cbColour3.getSelectionModel().select(0);
		
		yard1 = model.getYard1();
		yard2 = model.getYard2();
		yard3 = model.getYard3();
		
		discount = model.getDiscount();
		
		price = model.getPayment();
		contact1 = model.getContact1();
		contact2 = model.getContact2();
		address = model.getAddress();
		pay = model.getCheck_payment();
		delivery = model.getCheck_delivery();
		memo = model.getMemo();
		
		txtMemberNo.setText(memberNo + "");
		txtCustomer.setText(customer);
		
		txtYard1.setText(yard1 + "");
		txtYard2.setText(yard2 + "");
		txtYard3.setText(yard3 + "");
		txtDiscount.setText(discount + "");
	
		txtPrice.setText(price +"");
		txtContact1.setText(contact1);
		txtContact2.setText(contact2);
		txtAddress.setText(address);
		txtMemo.setText(memo);
		
		if (pay.equals("û��")) {
			rbBeforePayment.setSelected(true);
			rbAfterPayment.setDisable(true);
		} else if (pay.equals("����")){
			rbAfterPayment.setSelected(true);
			rbBeforePayment.setDisable(true);
		}
		
		if (delivery.equals("���")) {
			rbStock.setSelected(true);
			rbHolding.setDisable(true);
			rbComplete.setDisable(true);
		} else if (delivery.equals("Ȧ��")){
			rbHolding.setSelected(true);
			rbStock.setDisable(true);
			rbComplete.setDisable(true);
		} else if (delivery.equals("�Ϸ�")) {
			rbComplete.setSelected(true);
			rbStock.setDisable(true);
			rbHolding.setDisable(true);
		}
		
		txtMemberNo.setEditable(false);
		txtProduct1.setEditable(false);
		txtProduct2.setEditable(false);
		txtProduct3.setEditable(false);
		txtCost1.setEditable(false);
		txtCost2.setEditable(false);
		txtCost3.setEditable(false);
		txtYard1.setEditable(false);
		txtYard2.setEditable(false);
		txtYard3.setEditable(false);
		cbColour1.setEditable(false);
		cbColour2.setEditable(false);
		cbColour3.setEditable(false);
		txtDiscount.setEditable(false);
		txtContact1.setEditable(false);
		txtContact2.setEditable(false);
		txtAddress.setEditable(false);
		txtMemo.setEditable(false);
		btnCal.setDisable(true);
		btnClear.setDisable(true);
		btnCustomerSearch.setDisable(true);
		btnProduct1.setDisable(true);
		btnProduct2.setDisable(true);
		btnProduct3.setDisable(true);
		btnDelete.setDisable(true);
		btnCancel.setDisable(true);
		
		btnOk.setOnAction(event -> handlerBtnOkAction(event));
	}

	public void handlerBtnOkAction(ActionEvent event) {
		Stage mainMtage = (Stage) btnOk.getScene().getWindow();
		mainMtage.close();
	}

}
