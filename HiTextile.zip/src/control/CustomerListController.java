package control;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.CustomerVO;

public class CustomerListController implements Initializable {
	@FXML
	private TextField txtCustomerNumber;
	@FXML
	private TextField txtCustomerName;
	@FXML
	private TextField txtContact1;
	@FXML
	private TextField txtContact2;
	@FXML
	private Button btnSearch;
	@FXML
	private Button btnEdit;
	@FXML
	private Button btnDelete;
	@FXML
	private TableView<CustomerVO> customerTable;
	
	ObservableList<CustomerVO> data = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		customerTable.setEditable(false);
		TableColumn colCustomer_no = new TableColumn("�ŷ�ó��ȣ");
		colCustomer_no.setPrefWidth(80);
		colCustomer_no.setCellValueFactory(new PropertyValueFactory<>("customer_no"));
		
		TableColumn colCustomer_name = new TableColumn("�ŷ�ó��");
		colCustomer_name.setPrefWidth(120);
		colCustomer_name.setCellValueFactory(new PropertyValueFactory<>("customer_name"));
		
		TableColumn colContact1 = new TableColumn("�����̳� ����ó");
		colContact1.setPrefWidth(120);
		colContact1.setCellValueFactory(new PropertyValueFactory<>("contact1"));
		
		TableColumn colContact2 = new TableColumn("���� ����ó");
		colContact2.setPrefWidth(120);
		colContact2.setCellValueFactory(new PropertyValueFactory<>("contact2"));
		
		TableColumn colCorporate_registration_number = new TableColumn("����� ��Ϲ�ȣ");
		colCorporate_registration_number.setPrefWidth(120);
		colCorporate_registration_number.setCellValueFactory(new PropertyValueFactory<>("corporate_registration_number"));
		
		TableColumn colRepresentative = new TableColumn("��ǥ��");
		colRepresentative.setPrefWidth(70);
		colRepresentative.setCellValueFactory(new PropertyValueFactory<>("representative"));
		
		TableColumn colBusiness_license = new TableColumn("����ڵ����");
		colBusiness_license.setPrefWidth(110);
		colBusiness_license.setCellValueFactory(new PropertyValueFactory<>("business_license"));
		
		customerTable.setItems(data);
		customerTable.getColumns().addAll(colCustomer_no,colCustomer_name,colContact1,colContact2,colCorporate_registration_number,
				colRepresentative,colBusiness_license);
		customerList();
	}
	
	public void customerList() {
		Object[][] customerData;
		
		CustomerDAO dao = new CustomerDAO();
		CustomerVO model = null;
		ArrayList<String> title;
		ArrayList<CustomerVO> information;
		
		title = dao.getCustomerColumnName();
		int columnCount = title.size();
		
		information = dao.getCustomerInformation();
		int rowCount = information.size();
		customerData = new Object[rowCount][columnCount];
		
		for (int index = 0; index < rowCount; index++) {
			model = information.get(index);
			data.add(model);
		}
	}
}
