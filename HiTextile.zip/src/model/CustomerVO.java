package model;

public class CustomerVO {
	private int customer_no;
	private String customer_name;
	private String contact1;
	private String contact2;
	private String corporate_registration_number;
	private String company_name;
	private String representative;
	private String business_license;
	
	public CustomerVO() {
		super();
	}
	
	
	public CustomerVO(String customer_name, String contact1, String contact2) {
		super();
		this.customer_name = customer_name;
		this.contact1 = contact1;
		this.contact2 = contact2;
	}

	public CustomerVO(String customer_name, String contact1, String contact2, String corporate_registration_number,
			String company_name, String representative, String business_license) {
		super();
		this.customer_name = customer_name;
		this.contact1 = contact1;
		this.contact2 = contact2;
		this.corporate_registration_number = corporate_registration_number;
		this.company_name = company_name;
		this.representative = representative;
		this.business_license = business_license;
	}

	public CustomerVO(String customer_name, String contact1, String contact2, String corporate_registration_number,
			String company_name, String representative) {
		super();
		this.customer_name = customer_name;
		this.contact1 = contact1;
		this.contact2 = contact2;
		this.corporate_registration_number = corporate_registration_number;
		this.company_name = company_name;
		this.representative = representative;
	}

	public CustomerVO(int customer_no, String customer_name, String contact1, String contact2,
			String corporate_registration_number, String company_name, String representative, String business_license) {
		super();
		this.customer_no = customer_no;
		this.customer_name = customer_name;
		this.contact1 = contact1;
		this.contact2 = contact2;
		this.corporate_registration_number = corporate_registration_number;
		this.company_name = company_name;
		this.representative = representative;
		this.business_license = business_license;
	}
	
	public CustomerVO(int customer_no, String customer_name, String contact1, String contact2,
			String corporate_registration_number, String company_name, String representative) {
		super();
		this.customer_no = customer_no;
		this.customer_name = customer_name;
		this.contact1 = contact1;
		this.contact2 = contact2;
		this.corporate_registration_number = corporate_registration_number;
		this.company_name = company_name;
		this.representative = representative;
	}

	public int getCustomer_no() {
		return customer_no;
	}

	public void setCustomer_no(int customer_no) {
		this.customer_no = customer_no;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getContact1() {
		return contact1;
	}

	public void setContact1(String contact1) {
		this.contact1 = contact1;
	}

	public String getContact2() {
		return contact2;
	}

	public void setContact2(String contact2) {
		this.contact2 = contact2;
	}

	public String getCorporate_registration_number() {
		return corporate_registration_number;
	}

	public void setCorporate_registration_number(String corporate_registration_number) {
		this.corporate_registration_number = corporate_registration_number;
	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getRepresentative() {
		return representative;
	}

	public void setRepresentative(String representative) {
		this.representative = representative;
	}

	public String getBusiness_license() {
		return business_license;
	}

	public void setBusiness_license(String business_license) {
		this.business_license = business_license;
	}
}
