package control;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginShopController implements Initializable {
	@FXML
	private Button btnShopRegistration;
	@FXML
	private TextField txtShopId;
	@FXML
	private TextField txtShopPw;
	@FXML
	private Button btnShopOk;
	@FXML
	private Button btnShopClear;
	@FXML
	private Button btnShopCancel;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		btnShopRegistration.setOnAction(event -> handlerBtnShopRegistrationAction(event));
		btnShopOk.setOnAction(event -> handlerShopOkAction(event));
		btnShopOk.setOnAction(event -> handlerShopOkLoginAction(event));
		btnShopClear.setOnAction(event -> handlerShopClearAction(event));
		btnShopCancel.setOnAction(event -> handlerShopCancelAction(event));
	}

	public void handlerShopOkLoginAction(ActionEvent event) {
		boolean loginSuccess = handlerShopOkAction(event);
		MemberDAO dao = null;
		String enteredId = "";
		String department = "";
		
		if (loginSuccess) {
			try {
				dao = new MemberDAO();
				enteredId = txtShopId.getText();
				department = "����";
				dao.log(enteredId, department);
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/main_shop.fxml"));
				Parent mainView = (Parent) loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("������� ����");
				mainMtage.setScene(scene);
				mainMtage.setResizable(false);
				Stage oldStage = (Stage) btnShopOk.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�α��� ����");
			alert.setHeaderText("�α��ο� �����߽��ϴ�.");
			alert.setContentText("�����");
			alert.showAndWait();
		}
	}

	public void handlerShopCancelAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/department.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�μ�����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnShopCancel.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void handlerShopClearAction(ActionEvent event) {
		txtShopId.clear();
		txtShopPw.clear();
	}

	public boolean handlerShopOkAction(ActionEvent event) {
		MemberDAO dao = null;
		String enteredId = "";
		String enteredPw = "";
		boolean result;
		boolean loginSuccess = false;
		String department = "";

		try {
			dao = new MemberDAO();
			enteredId = txtShopId.getText().trim();
			enteredPw = txtShopPw.getText().trim();
			result = dao.login(enteredId, enteredPw);
			department = dao.callDepartment(enteredId);

			if (result && !enteredId.equals("") && !enteredPw.equals("") && department.equals("����")) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�α���");
				alert.setHeaderText("�α��ο� �����߽��ϴ�.");
				alert.setContentText("�α��� ����");
				alert.showAndWait();

				loginSuccess = true;
			} else if (enteredId.equals("") || enteredPw.equals("")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�α���");
				alert.setHeaderText("���̵�/�н����带 �Է��Ͻʽÿ�.");
				alert.setContentText("�Է� �� ����");
				alert.showAndWait();
			
				txtShopId.requestFocus();
			} else if (!department.equals("����")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�α���");
				alert.setHeaderText("���� ���� ID�� �ƴմϴ�.");
				alert.setContentText("�μ� Ȯ��");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�α���");
				alert.setHeaderText("���̵�� �н����带 Ȯ���Ͻʽÿ�.");
				alert.setContentText("���� ���� ����");
				alert.showAndWait();

				txtShopId.requestFocus();
			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("�α��� ����");
			alert.setHeaderText("�α��� ������ ������ �߻��߽��ϴ�.");
			alert.setContentText("�����");
			alert.show();
		}

		return loginSuccess;
	}

	public void handlerBtnShopRegistrationAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/join_shop.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("���� ���� ���");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnShopRegistration.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
