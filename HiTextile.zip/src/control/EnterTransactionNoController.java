package control;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class EnterTransactionNoController implements Initializable {
	@FXML
	private TextField txtTransactionNo;
	@FXML
	private Button btnOk;
	@FXML
	private Button btnCancel;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		btnOk.setOnAction(event -> handlerBtnOkAction(event));
		btnOk.setOnAction(event -> handlerBtnOkAction2(event));
	}

	public void handlerBtnOkAction2(ActionEvent event) {
		boolean enter = handlerBtnOkAction(event);
		if (enter) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/receipt2.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setScene(scene);
			mainMtage.setResizable(false);
			mainMtage.setTitle("������");
			Stage oldStage = (Stage) btnOk.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
	}

	public boolean handlerBtnOkAction(ActionEvent event) {
		TransactionDAO dao = null;
		boolean enter = false;
		int no = 0;
		try {
			dao = new TransactionDAO();
			no = Integer.parseInt(txtTransactionNo.getText().trim());
			dao.callReceiptInformation2(no);
			if (dao == null) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� ������ ��ȸ");
				alert.setHeaderText("�ŷ���ȣ�� �������� �ʽ��ϴ�.");
				alert.setContentText("�ŷ���ȣ Ȯ��");
				alert.showAndWait();
			} else {
				dao.saveTransactionNo(no);
				enter = true;
			}
		} catch (NullPointerException ne) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�ŷ���ȣ �Է�");
			alert.setHeaderText("�ŷ���ȣ�� �Է��Ͻʽÿ�");
			alert.setContentText("�ŷ���ȣ �Է� �� ����");
			alert.showAndWait();
			txtTransactionNo.requestFocus();
		} catch (Exception se) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�ŷ���ȣ �Է�");
			alert.setHeaderText("�ŷ���ȣ�� ������ �Է��Ͻʽÿ�");
			alert.setContentText("�ŷ���ȣ ���Է�");
			alert.showAndWait();
			txtTransactionNo.requestFocus();
		}
		return enter;
	}
}
