package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.ChartVO;

public class ChartDAO {
	public ArrayList<String> getMonthlySalseColumnName(){
		ArrayList<String> columnName = new ArrayList<>(); 
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		String sql = "select " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/01/',sum(payment)),0) as \"January\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/02/',sum(payment)),0) as \"Febuary\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/03/',sum(payment)),0) as \"March\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/04/',sum(payment)),0) as \"April\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/05/',sum(payment)),0) as \"May\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/06/',sum(payment)),0) as \"June\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/07/',sum(payment)),0) as \"July\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/08/',sum(payment)),0) as \"August\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/09/',sum(payment)),0) as \"September\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/10/',sum(payment)),0) as \"October\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/11/',sum(payment)),0) as \"November\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/12/',sum(payment)),0) as \"December\" " +
				"from transaction";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i < columnCount; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return columnName;
	}
	
	public ArrayList<ChartVO> getMonthlySalseList(){
		ArrayList<ChartVO> monthlySalse = new ArrayList<>(); 
		ChartVO model = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/01/',sum(payment)),0) as \"January\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/02/',sum(payment)),0) as \"Febuary\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/03/',sum(payment)),0) as \"March\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/04/',sum(payment)),0) as \"April\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/05/',sum(payment)),0) as \"May\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/06/',sum(payment)),0) as \"June\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/07/',sum(payment)),0) as \"July\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/08/',sum(payment)),0) as \"August\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/09/',sum(payment)),0) as \"September\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/10/',sum(payment)),0) as \"October\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/11/',sum(payment)),0) as \"November\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/12/',sum(payment)),0) as \"December\" " +
				"from transaction";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
		
			while (rs.next()) {
				model = new ChartVO();
				model.setJanuary(rs.getInt("January"));
				model.setFebuary(rs.getInt("Febuary"));
				model.setMarch(rs.getInt("March"));
				model.setApril(rs.getInt("April"));
				model.setMay(rs.getInt("May"));
				model.setJune(rs.getInt("June"));
				model.setJuly(rs.getInt("July"));
				model.setAugust(rs.getInt("August"));
				model.setSeptember(rs.getInt("September"));
				model.setOctober(rs.getInt("October"));
				model.setNovember(rs.getInt("November"));
				model.setDecember(rs.getInt("December"));
				
				monthlySalse.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return monthlySalse;
	}
	
	public ObservableList<ChartVO> getMonthlySalseList2(){
		ObservableList<ChartVO> monthlySalse = FXCollections.observableArrayList();
		ChartVO model = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/01/',sum(payment)),0) as \"January\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/02/',sum(payment)),0) as \"Febuary\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/03/',sum(payment)),0) as \"March\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/04/',sum(payment)),0) as \"April\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/05/',sum(payment)),0) as \"May\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/06/',sum(payment)),0) as \"June\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/07/',sum(payment)),0) as \"July\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/08/',sum(payment)),0) as \"August\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/09/',sum(payment)),0) as \"September\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/10/',sum(payment)),0) as \"October\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/11/',sum(payment)),0) as \"November\", " +
				"nvl(decode(to_char(sysdate,'yy/mm/'),'18/12/',sum(payment)),0) as \"December\" " +
				"from transaction";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
		
			while (rs.next()) {
				model = new ChartVO();
				model.setJanuary(rs.getInt("January"));
				model.setFebuary(rs.getInt("Febuary"));
				model.setMarch(rs.getInt("March"));
				model.setApril(rs.getInt("April"));
				model.setMay(rs.getInt("May"));
				model.setJune(rs.getInt("June"));
				model.setJuly(rs.getInt("July"));
				model.setAugust(rs.getInt("August"));
				model.setSeptember(rs.getInt("September"));
				model.setOctober(rs.getInt("October"));
				model.setNovember(rs.getInt("November"));
				model.setDecember(rs.getInt("December"));
				
				monthlySalse.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return monthlySalse;
	}
	
	public ObservableList<ChartVO> getProductSalse(){
		ObservableList<ChartVO> productSalse = FXCollections.observableArrayList();
		ChartVO model = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select fabric_name, sum(stock_out) as sum from stock group by fabric_name having " +
				"fabric_name='January' or fabric_name='Febuary' or fabric_name='March' or " +
				"fabric_name='April' or fabric_name='May' or fabric_name='June' or fabric_name='July' or " +
				"fabric_name='August' or fabric_name='September'or fabric_name='October' or " +
				"fabric_name='November' or fabric_name='December' order by 1";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
		
			while (rs.next()) {
				model = new ChartVO();
				model.setFabric_name(rs.getString("fabric_name"));
				model.setSum(rs.getDouble("sum"));
	
				productSalse.addAll(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return productSalse;
	}
}
