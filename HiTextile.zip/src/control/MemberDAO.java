package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.MemberVO;

public class MemberDAO {
	public boolean memberRegistration(MemberVO input) throws Exception {
		
		String sql = "insert into member values "
				+ "(member_seq.nextval, ?,?,?,?,?,?)";
		Connection con = null;
		PreparedStatement pstmt = null;
		boolean joinSuccess = false;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1 , input.getId());
			pstmt.setString(2, input.getPassword());
			pstmt.setString(3, input.getMember_name());
			pstmt.setString(4, input.getMember_phone());
			pstmt.setString(5 , input.getDepartment());
			pstmt.setString(6, input.getPosition());
			
			int i = pstmt.executeUpdate();
			
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�������");
				alert.setHeaderText("������Ͽ� �����߽��ϴ�.");
				alert.setContentText("�Ϸ�");
				alert.showAndWait();
				
				joinSuccess = true;
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�������");
				alert.setHeaderText("������Ͽ� �����߽��ϴ�.");
				alert.setContentText("����");
				alert.showAndWait();
			}
			
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		} 
		
		return joinSuccess;
	}
	
	public boolean idOverlapCheck(String id) {
		String sql = "select id from member where id = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		boolean idOverlapResult = false;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				idOverlapResult = true;
				}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return idOverlapResult;
	}
	
	public boolean login(String id, String pw) {
		String sql = "select id, password from member where id = ? and password = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		boolean loginSuccess = false;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				loginSuccess = true;
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	 }
		}
		return loginSuccess;
	}
	public String callDepartment(String id) {
	      String department = "";
	      Connection con = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      String sql = "select department from member where id = ?";
	      
	      try {
	         con = DBUtil.getConnection();
	         pstmt = con.prepareStatement(sql);
	         pstmt.setString(1, id);
	         rs = pstmt.executeQuery();
	         if(rs.next()) {
	            department = rs.getString("department");
	         }
	      } catch (SQLException se) {
	         System.out.println(se);
	      } catch (Exception e){
	         System.out.println(e);
	      } finally {
	         try {
	            if (rs != null) rs.close();
	            if (pstmt !=  null) pstmt.close();
	            if (con != null) con.close();
	         } catch (Exception e) {   }
	      }
	      return department;
	   }
	
	public ObservableList<String> callMemberId(){
		ObservableList<String> memberId = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select id from member order by 1";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				memberId.addAll(rs.getString("id"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	 }
		}
		return memberId;
	}
	
	public MemberVO callMemberInformation(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from member where id = ?";
		MemberVO model = null;
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new MemberVO();
				model.setMamber_no(rs.getInt(1));
				model.setId(rs.getString(2));
				model.setPassword(rs.getString(3));
				model.setMember_name(rs.getString(4));
				model.setMember_phone(rs.getString(5));
				model.setDepartment(rs.getString(6));
				model.setPosition(rs.getString(7));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				 if (rs != null) rs.close();
				 if (pstmt != null) pstmt.close();
				 if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return model;
	}
	
	public MemberVO updateMemberInformation(MemberVO enter) {
		MemberVO information = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "update member set id =?, password =?, member_name =?, member_phone =?, department =?, position =?"
				+ " where member_no = ?";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, enter.getId());
			pstmt.setString(2, enter.getPassword());
			pstmt.setString(3, enter.getMember_name());
			pstmt.setString(4, enter.getMember_phone());
			pstmt.setString(5, enter.getDepartment());
			pstmt.setString(6, enter.getPosition());
			pstmt.setInt(7, enter.getMamber_no());
			int i = pstmt.executeUpdate();
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�������� ����");
				alert.setHeaderText("�������� ���濡 �����߽��ϴ�.");
				alert.setContentText("�������� ���� �Ϸ�");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�������� ����");
				alert.setHeaderText("�������� ���濡 �����߽��ϴ�.");
				alert.setContentText("�������� ���� ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return information;
	}
	
	public boolean deleteMember(int no) {
		boolean delete = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "delete from member where member_no = ?";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�������� ����");
				alert.setHeaderText("�������� ������ �����߽��ϴ�.");
				alert.setContentText("�������� ���� �Ϸ�");
				alert.showAndWait();
				
				delete = true;
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�������� ����");
				alert.setHeaderText("�������� ������ �����߽��ϴ�.");
				alert.setContentText("�������� ���� ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return delete;
	}
	
	public void log(String id, String department) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "insert into log values (?, ?, sysdate)";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, department);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				System.out.println("�α�");
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
	}
	
	public int callMemberNo(String id) {
		int memberNo = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select member_no from member where id = ?";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				memberNo = rs.getInt("member_no");
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return memberNo;
	}
	
	public ObservableList<String> callLoginShopMemberId() {
		String loginId = "";
		ObservableList<String> log = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select id from log where department = '����' "
				+ "order by log_date desc";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()){
				loginId = rs.getString("id");
				log.add(loginId);
			}
			
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return log;
	}
	
	public void clearLog() {
		Connection con = null;
		PreparedStatement pstmt = null;
	
		String sql = "delete from log";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�α� ����");
				alert.setHeaderText("�α� ������ �����߽��ϴ�");
				alert.setContentText("�α� ���� �Ϸ�");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�α� ����");
				alert.setHeaderText("�α� ������ �����߽��ϴ�");
				alert.setContentText("�α� ���� ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
	}
}
