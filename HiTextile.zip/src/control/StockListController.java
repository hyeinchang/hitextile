package control;

import java.net.URL;
import java.sql.SQLRecoverableException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.StockVO;

public class StockListController implements Initializable {
	@FXML
	private TableView<StockVO> stockTable;
	ObservableList<StockVO> stock = FXCollections.observableArrayList();
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		stockTable.setEditable(false);
		TableColumn colStock_no = new TableColumn("�����ȣ");
		colStock_no.setMinWidth(70);
		colStock_no.setMaxWidth(70);
		colStock_no.setStyle("-fx-alignment:CENTER");
		colStock_no.setCellValueFactory(new PropertyValueFactory<>("stock_no"));
		TableColumn colFabrick_name = new TableColumn("���ܸ�");
		colFabrick_name.setMinWidth(80);
		colFabrick_name.setMaxWidth(80);
		colFabrick_name.setStyle("-fx-alignment:CENTER");
		colFabrick_name.setCellValueFactory(new PropertyValueFactory<>("fabric_name"));
		TableColumn colFabrick_colour = new TableColumn("�÷�");
		colFabrick_colour.setMinWidth(60);
		colFabrick_colour.setMaxWidth(60);
		colFabrick_colour.setStyle("-fx-alignment:CENTER");
		colFabrick_colour.setCellValueFactory(new PropertyValueFactory<>("fabric_colour"));
		TableColumn colFabrick_cost = new TableColumn("�ܰ�");
		colFabrick_cost.setMinWidth(60);
		colFabrick_cost.setMaxWidth(60);
		colFabrick_cost.setStyle("-fx-alignment:CENTER");
		colFabrick_cost.setCellValueFactory(new PropertyValueFactory<>("fabric_cost"));
		TableColumn colFabrick_material = new TableColumn("����");
		colFabrick_material.setMinWidth(115);
		colFabrick_material.setMaxWidth(115);
		colFabrick_material.setStyle("-fx-alignment:CENTER");
		colFabrick_material.setCellValueFactory(new PropertyValueFactory<>("fabric_material"));
		TableColumn colStock = new TableColumn("���");
		colStock.setMinWidth(80);
		colStock.setMaxWidth(80);
		colStock.setStyle("-fx-alignment:CENTER");
		colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));
		TableColumn colStock_out = new TableColumn("���");
		colStock_out.setMinWidth(80);
		colStock_out.setMaxWidth(80);
		colStock_out.setStyle("-fx-alignment:CENTER");
		colStock_out.setCellValueFactory(new PropertyValueFactory<>("stock_out"));
		TableColumn colStock_in = new TableColumn("�԰�");
		colStock_in.setMinWidth(80);
		colStock_in.setMaxWidth(80);
		colStock_in.setStyle("-fx-alignment:CENTER");
		colStock_in.setCellValueFactory(new PropertyValueFactory<>("stock_in"));
		TableColumn colStock_holding = new TableColumn("Ȧ��");
		colStock_holding.setMinWidth(60);
		colStock_holding.setMaxWidth(60);
		colStock_holding.setStyle("-fx-alignment:CENTER");
		colStock_holding.setCellValueFactory(new PropertyValueFactory<>("stock_holding"));
		TableColumn colStock_return = new TableColumn("��ǰ");
		colStock_return.setMinWidth(60);
		colStock_return.setMaxWidth(60);
		colStock_return.setStyle("-fx-alignment:CENTER");
		colStock_return.setCellValueFactory(new PropertyValueFactory<>("stock_return"));
		TableColumn colStock_sample = new TableColumn("����");
		colStock_sample.setMinWidth(60);
		colStock_sample.setMaxWidth(60);
		colStock_sample.setStyle("-fx-alignment:CENTER");
		colStock_sample.setCellValueFactory(new PropertyValueFactory<>("stock_sample"));
		TableColumn colStock_defective = new TableColumn("�ҷ�");
		colStock_defective.setMinWidth(60);
		colStock_defective.setMaxWidth(60);
		colStock_defective.setStyle("-fx-alignment:CENTER");
		colStock_defective.setCellValueFactory(new PropertyValueFactory<>("stock_defective"));
		TableColumn colStock_service = new TableColumn("����");
		colStock_service.setMinWidth(60);
		colStock_service.setMaxWidth(60);
		colStock_service.setStyle("-fx-alignment:CENTER");
		colStock_service.setCellValueFactory(new PropertyValueFactory<>("stock_service"));
		TableColumn colStock_memo = new TableColumn("�޸�");
		colStock_memo.setMinWidth(123);
		colStock_memo.setMaxWidth(123);
		colStock_memo.setStyle("-fx-alignment:CENTER");
		colStock_memo.setCellValueFactory(new PropertyValueFactory<>("stock_memo"));
		TableColumn colStock_date = new TableColumn("�����");
		colStock_date.setMinWidth(100);
		colStock_date.setMaxWidth(100);
		colStock_date.setCellValueFactory(new PropertyValueFactory<>("stock_date"));
		stockTable.setItems(stock);
		stockTable.getColumns().addAll(colStock_no,colFabrick_name,colFabrick_colour,colFabrick_cost,colFabrick_material,
				colStock,colStock_out,colStock_in,colStock_holding,colStock_return,colStock_sample,colStock_defective,
				colStock_service,colStock_memo,colStock_date);
		stockList();
	}
	
	public void stockList() {
		Object[][] stockData;
		StockDAO dao = new StockDAO();
		StockVO model = new StockVO();
		ArrayList<String> title;
		ArrayList<StockVO> list;
		
		title = dao.getStockViewColumnName();
		int columnCount = title.size();
		
		list = dao.getStockViewInformation();
		int rowCount = list.size();
		
		stockData = new Object[rowCount][columnCount];
		for ( int i = 0; i < rowCount; i++) {
			model = list.get(i);
			stock.add(model);
		}
		
	}
}
