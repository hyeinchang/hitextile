package control;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.CustomerVO;
import model.MemberVO;
import model.SearchVO;
import model.TransactionVO;

public class MainOfficeController implements Initializable {
	@FXML
	private Button btnMemberSearch;
	@FXML
	private TextField txtMemberNo;
	@FXML
	private TextField txtMemberId;
	@FXML
	private TextField txtMemberPw;
	@FXML
	private TextField txtMemberCheckPw;
	@FXML
	private TextField txtMemberDepartment;
	@FXML
	private TextField txtMemberPosition;
	@FXML
	private TextField txtMemberName;
	@FXML
	private TextField txtMemberPhone;
	@FXML
	private Button btnMemberEdit;
	@FXML
	private Button btnMemberDelete;
	@FXML
	private Button btnCustomerEdit;
	@FXML
	private Button btnCustomerDelete;
	@FXML
	private Button btnCustomerSearch;
	@FXML
	private TextField txtCustomerNo;
	@FXML
	private TextField txtCustomerName;
	@FXML
	private TextField txtCustomerContact1;
	@FXML
	private TextField txtCustomerContact2;
	@FXML
	private TextField txtCustomerRegisteredNo;
	@FXML
	private TextField txtCustomerCompany;
	@FXML
	private TextField txtCustomerRepresentative;
	@FXML
	private Button btnCustomerLicense;
	@FXML
	private DatePicker dpTransactionDate;
	@FXML
	private TextField txtSearchTransactionNo;
	@FXML
	private TextField txtSearchCustomerName;
	@FXML
	private ComboBox<String> cbSearchProduct;
	@FXML
	private ComboBox<String> cbSearchColour;
	@FXML
	private ComboBox<String> cbSearchPayment;
	@FXML
	private Button btnSearchTransaction;
	@FXML
	private TableView<TransactionVO> transactionTable;
	@FXML
	private Button btnTransactionListSave;
	@FXML
	private Button btnCustomerInformation;
	@FXML
	private Button btnProductInformation;
	@FXML
	private Button btnLogin;
	@FXML
	private Button btnDepartment;
	@FXML
	private Button btnChart;
	@FXML
	private Button btnLog;
	@FXML
	private ListView<String> lvMember;
	@FXML
	private ListView<String> lvCustomer;
	@FXML
	private TextField txtSearchMemberName;
	@FXML
	private TextField txtSearchMemo;
	@FXML
	private TextField txtSearchPayment;

	StockDAO stock_dao = new StockDAO();
	MemberDAO member_dao = new MemberDAO();
	CustomerDAO customer_dao = new CustomerDAO();
	ObservableList<String> productNameList;
	ObservableList<String> memberIdList;
	ObservableList<String> customerNameList;
	ObservableList<TransactionVO> transaction = FXCollections.observableArrayList();
	ObservableList<MemberVO> memberInformation = FXCollections.observableArrayList();
	ObservableList<CustomerVO> customerInformation = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		MemberDAO dao = new MemberDAO();

		transactionTable.setEditable(false);
		TableColumn colTransaction_no = new TableColumn("�ŷ�no");
		colTransaction_no.setMaxWidth(70);
		colTransaction_no.setMinWidth(70);
		colTransaction_no.setStyle("-fx-alignment:CENTER");
		colTransaction_no.setCellValueFactory(new PropertyValueFactory<>("transaction_no"));
		TableColumn colMemberName = new TableColumn("������");
		colMemberName.setMaxWidth(70);
		colMemberName.setMinWidth(70);
		colMemberName.setStyle("-fx-alignment:CENTER");
		colMemberName.setCellValueFactory(new PropertyValueFactory<>("memberName"));
		TableColumn colCustomerName = new TableColumn("�ŷ�ó");
		colCustomerName.setMaxWidth(100);
		colCustomerName.setMinWidth(100);
		colCustomerName.setStyle("-fx-alignment:CENTER");
		colCustomerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
		TableColumn colOrder = new TableColumn("�ֹ�����");
		colOrder.setMaxWidth(240);
		colOrder.setMinWidth(240);
		colOrder.setStyle("-fx-alignment:CENTER");
		colOrder.setCellValueFactory(new PropertyValueFactory<>("orderList"));
		TableColumn colDiscount = new TableColumn("������");
		colDiscount.setMaxWidth(60);
		colDiscount.setMinWidth(60);
		colDiscount.setStyle("-fx-alignment:CENTER");
		colDiscount.setCellValueFactory(new PropertyValueFactory<>("discount"));
		TableColumn colPayment = new TableColumn("�����ݾ�");
		colPayment.setMaxWidth(100);
		colPayment.setMinWidth(100);
		colPayment.setStyle("-fx-alignment:CENTER");
		colPayment.setCellValueFactory(new PropertyValueFactory<>("payment"));
		TableColumn colCheck_payment = new TableColumn("��������");
		colCheck_payment.setMaxWidth(60);
		colCheck_payment.setMinWidth(60);
		colCheck_payment.setStyle("-fx-alignment:CENTER");
		colCheck_payment.setCellValueFactory(new PropertyValueFactory<>("check_payment"));
		TableColumn colMemo = new TableColumn("�޸�");
		colMemo.setMaxWidth(120);
		colMemo.setMinWidth(120);
		colMemo.setCellValueFactory(new PropertyValueFactory<>("memo"));
		TableColumn colTransaction_date = new TableColumn("�����");
		colTransaction_date.setMaxWidth(100);
		colTransaction_date.setMinWidth(100);
		colTransaction_date.setCellValueFactory(new PropertyValueFactory<>("transaction_date"));
		transactionTable.setItems(transaction);
		transactionTable.getColumns().addAll(colTransaction_no, colMemberName, colCustomerName, colOrder, colDiscount,
				colPayment, colCheck_payment, colMemo, colTransaction_date);
		transactionList();

		productNameList = stock_dao.callProductName();
		cbSearchProduct.setItems(FXCollections.observableArrayList(productNameList));
		cbSearchColour.setItems(FXCollections.observableArrayList("ȭ��Ʈ", "������", "��ũ", "����", "����"));
		cbSearchPayment.setItems(FXCollections.observableArrayList("û��", "����"));
		SearchDAO searchDao = new SearchDAO();
		cbSearchProduct.setItems(searchDao.callFabricName());

		memberIdList = member_dao.callMemberId();
		lvMember.setItems(memberIdList);
		customerNameList = customer_dao.callCustomerName();
		lvCustomer.setItems(customerNameList);

		txtCustomerNo.setEditable(false);
		txtMemberNo.setEditable(false);

		btnLogin.setOnAction(event -> handlerBtnLoginAction(event));
		btnDepartment.setOnAction(event -> handlerBtnDepartmentAction(event));
		lvCustomer.setOnMouseClicked(event -> handlerCustomerChoiceAction(event));
		lvMember.setOnMouseClicked(event -> handlerMemberChoiceAction(event));
		btnMemberEdit.setOnAction(event -> handlerBtnMemeberEditAction(event));
		btnMemberDelete.setOnAction(event -> handlerBtnMemberDeleteAction(event));
		btnCustomerEdit.setOnAction(event -> handlerBtnCustomerEditAction(event));
		btnCustomerDelete.setOnAction(event -> handlderBtnCustomerDeleteAction(event));
		transactionTable.setOnMouseClicked(event -> handlerViewReceiptAction(event));
		btnCustomerInformation.setOnAction(event -> handlerBtnCustomerInformation(event));
		btnProductInformation.setOnAction(event -> handelerBtnProductInformation(event));
		btnSearchTransaction.setOnAction(event -> handlerBtnSearchTransactionAction(event));
		btnChart.setOnAction(event -> handlerBtnChartAction(event));
		btnTransactionListSave.setOnAction(event -> handlerBtnTransactionListSaveAction(event));
		btnLog.setOnAction(event -> handlerBtnLogAction(event));
	}

	public void handlerBtnLogAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/log.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setScene(scene);
			mainMtage.setTitle("�α���ȸ");
			mainMtage.setResizable(false);
			mainMtage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}

	public void handlerBtnTransactionListSaveAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/file_save.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setScene(scene);
			mainMtage.setTitle("���� Ȯ���� ����");
			mainMtage.setResizable(false);
			mainMtage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}

	public void handlerBtnChartAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/chart_choice.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("��Ʈ ����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnSearchTransactionAction(ActionEvent event) {
		SearchDAO searchDao = null;
		SearchVO search = null;

		int transaction_no = 0;
		String customer_name = "";
		String fabric_name = "";
		String fabric_colour = "";
		int payment = 0;
		String check_payment = "";
		String memberName = "";
		String memo = "";
		String transaction_date = "";
		String colour_abb = "";
		ObservableList<TransactionVO> list = FXCollections.observableArrayList();
		try {
			searchDao = new SearchDAO();
			search = new SearchVO();
			SearchVO search2 = new SearchVO();
			SearchVO search3 = new SearchVO();
			transaction_no = Integer.parseInt(search2.nullToValue3(txtSearchTransactionNo.getText().trim()));
			memberName = search2.nullToValue(txtMemberName.getText().trim());
			customer_name = search2.nullToValue(txtSearchCustomerName.getText().trim());
			fabric_name = search2.nullToValue2(cbSearchProduct.getSelectionModel().getSelectedItem());
			payment = Integer.parseInt(search2.nullToValue3(txtSearchPayment.getText().trim()));
			check_payment = search2.nullToValue2(cbSearchPayment.getSelectionModel().getSelectedItem());
			memo = search2.nullToValue(txtSearchMemo.getText().trim());
			transaction_date = search2.nullToValue(dpTransactionDate.getValue() + "");
			colour_abb = search3.colourNameChange(cbSearchColour.getSelectionModel().getSelectedItem());
			String order = "x";

			if (fabric_name.equals(" ") && !colour_abb.equals(" ")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ����� �˻�");
				alert.setHeaderText("���ܸ��� �����Ͻʽÿ�");
				alert.setContentText("���ܸ� �Է� �� ����");
				alert.showAndWait();
				cbSearchProduct.requestFocus();
			} else if (!fabric_name.equals(" ") && colour_abb.equals(" ")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ����� �˻�");
				alert.setHeaderText("�÷��� �����Ͻʽÿ�");
				alert.setContentText("���ܸ� ���� �� ����");
				alert.showAndWait();
				cbSearchColour.requestFocus();
			} else if (transaction_no != 0) {
				search.setTransaction_no(transaction_no);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
				return;
			} else if (!customer_name.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memberName.equals(" ")) {
				search.setMember_name(memberName);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);

				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (payment != 0) {
				search.setPayment(payment);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_payment.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memo.equals(" ")) {
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!transaction_date.equals(" ")) {
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !memberName.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(memberName);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memberName.equals(" ") && !customer_name.equals(" ")) {
				search.setCustomer_name(memberName);
				search.setOrderList(order);
				search.setCustomer_name(customer_name);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memberName.equals(" ") && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ")) {
				search.setCustomer_name(memberName);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setCustomer_name(customer_name);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memberName.equals(" ") && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && payment != 0) {
				search.setCustomer_name(memberName);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setCustomer_name(customer_name);
				search.setPayment(payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memberName.equals(" ") && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ")) {
				search.setCustomer_name(memberName);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setCustomer_name(customer_name);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
			} else if (transaction_no != 0 && !customer_name.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && (payment != 0)) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ") && !memo.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setMemo(memo);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ") && !memo.equals(" ")
					&& !transaction_date.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ")
					&& payment != 0) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ") && !memo.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setMemo(memo);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ") && !memo.equals(" ") && !transaction_date.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ")
					&& !memo.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setMemo(memo);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ") && !memo.equals(" ") && !transaction_date.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (payment != 0 && !check_payment.equals(" ")) {
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (payment != 0 && !check_payment.equals(" ")) {
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (payment != 0 && !check_payment.equals(" ") && !memo.equals(" ")) {
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (payment != 0 && !check_payment.equals(" ") && !memo.equals(" ")
					&& !transaction_date.equals(" ")) {
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_payment.equals(" ") && !memo.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (check_payment.equals(" ") && !memo.equals(" ") && !transaction_date.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memo.equals(" ") && !transaction_date.equals(" ")) {
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ����� �˻�");
				alert.setHeaderText("�˻��� ���� �Է��Ͻʽÿ�.");
				alert.setContentText("���Է�");
				alert.showAndWait();
			}

		} catch (Exception e) {
			e.printStackTrace();
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�ŷ����� �˻�");
			alert.setHeaderText("�Է��� ���� Ȯ���Ͻʽÿ�.");
			alert.setContentText("���Է�");
			alert.showAndWait();
		}
	}

	public void handelerBtnProductInformation(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/product_information.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("��ǰ �� ����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnCustomerInformation(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/customer_list.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�ŷ�ó���");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerViewReceiptAction(MouseEvent event) {
		int transactionNo = 0;
		TransactionDAO dao = null;
		try {
			transactionNo = transactionTable.getSelectionModel().getSelectedItem().getTransaction_no();
			dao = new TransactionDAO();
			dao.saveTransactionNo(transactionNo);
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/receipt2.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setScene(scene);
			mainMtage.setTitle("������");
			mainMtage.setResizable(false);
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void transactionList() {
		Object[][] transactionData;
		TransactionDAO dao = new TransactionDAO();
		TransactionVO model;
		ArrayList<String> title = new ArrayList<>();
		ArrayList<TransactionVO> list = new ArrayList<>();
		title = dao.getShopMainTransactionColumnName();
		list = dao.getOfficeTransactionInformation();
		int rowCount = list.size();
		int columnCount = title.size();

		transactionData = new Object[rowCount][columnCount];
		for (int i = 0; i < rowCount; i++) {
			model = new TransactionVO();
			model = list.get(i);
			transaction.add(model);
		}
	}

	public void handlerMemberChoiceAction(MouseEvent event) {
		String id = "";
		MemberDAO dao = null;
		MemberVO model = null;
		try {
			id = lvMember.getSelectionModel().getSelectedItem();
			dao = new MemberDAO();
			model = new MemberVO();
			model = dao.callMemberInformation(id);
			txtMemberNo.setText(model.getMamber_no() + "");
			txtMemberId.setText(model.getId());
			txtMemberPw.setText(model.getPassword());
			txtMemberCheckPw.setText(model.getPassword());
			txtMemberDepartment.setText(model.getDepartment());
			txtMemberPosition.setText(model.getPosition());
			txtMemberName.setText(model.getMember_name());
			txtMemberPhone.setText(model.getMember_phone());

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerCustomerChoiceAction(MouseEvent event) {
		String name = "";
		CustomerDAO dao = null;
		CustomerVO model = null;
		try {
			dao = new CustomerDAO();
			model = new CustomerVO();
			name = lvCustomer.getSelectionModel().getSelectedItem();
			model = dao.callCustomerInformation(name);
			txtCustomerNo.setText(model.getCustomer_no() + "");
			txtCustomerName.setText(model.getCustomer_name());
			txtCustomerContact1.setText(model.getContact1());
			txtCustomerContact2.setText(model.getContact2());
			txtCustomerRegisteredNo.setText(model.getCorporate_registration_number());
			txtCustomerCompany.setText(model.getCompany_name());
			txtCustomerRepresentative.setText(model.getRepresentative());
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlderBtnCustomerDeleteAction(ActionEvent event) {
		CustomerDAO dao = null;
		String getNo = "";
		int no = 0;
		boolean deleted = false;
		try {
			dao = new CustomerDAO();
			getNo = txtCustomerNo.getText();
			if (getNo.equals("")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ�ó ����");
				alert.setHeaderText("�ŷ�ó ����Ʈ���� ������ �ŷ�ó�� �����Ͻʽÿ�");
				alert.setContentText("�ŷ�ó ���� �� ����");
				alert.showAndWait();
				lvCustomer.requestFocus();
			} else {
				no = Integer.parseInt(txtCustomerNo.getText());
				deleted = dao.deleteCustomerInformation(no);
				if (deleted) {
					customerNameList = dao.callCustomerName();
					lvCustomer.setItems(customerNameList);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnCustomerEditAction(ActionEvent event) {
		CustomerDAO dao = null;
		CustomerVO model = null;
		String getNo = "";
		int no = 0;
		String name = "";
		String contact1 = "";
		String contact2 = "";
		String registeredNo = "";
		String companyName = "";
		String representative = "";
		String license = "";
		try {
			if (event.getSource().equals(btnCustomerEdit)) {
				dao = new CustomerDAO();
				model = new CustomerVO();
				getNo = txtCustomerNo.getText();
				if (getNo.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�ŷ�ó ���� ����");
					alert.setHeaderText("�ŷ�ó ����Ʈ���� ������ �ŷ�ó ������ �����Ͻʽÿ�.");
					alert.setContentText("�ŷ�ó�� ���� �� ����");
					alert.showAndWait();
					lvCustomer.requestFocus();
				} else {
					no = Integer.parseInt(txtCustomerNo.getText());
					name = txtCustomerName.getText().trim();
					contact1 = txtCustomerContact1.getText().trim();
					contact2 = txtCustomerContact2.getText().trim();
					registeredNo = txtCustomerRegisteredNo.getText().trim();
					companyName = txtCustomerCompany.getText().trim();
					representative = txtCustomerRepresentative.getText().trim();
					license = "���� ������";

					if (name.equals("") || contact1.equals("")) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�ŷ�ó ���");
						alert.setHeaderText("�ŷ�ó ��ϸ��� �����̳� ����ó�� �ʼ��� �Է��ؾ��մϴ�.");
						alert.setContentText("�ŷ�ó��/����ó1 �Է�");
						alert.showAndWait();
					} else if (10 < name.length()) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�ŷ�ó ���");
						alert.setHeaderText("�ŷ�ó���� �ѱ�10�� ���Ϸ� �Է��ؾ��մϴ�.");
						alert.setContentText("�ŷ�ó�� ���Է�");
						alert.showAndWait();

						txtCustomerName.requestFocus();
					} else if (contact1.length() != 11) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�ŷ�ó ���");
						alert.setHeaderText("����ó�� ������� ���� 11�ڸ��� �Է��ؾ� �մϴ�");
						alert.setContentText("����ó1 ���Է�");
						alert.showAndWait();

						txtCustomerContact1.requestFocus();
					} else if (!contact2.equals("") && contact2.length() != 11) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�ŷ�ó ���");
						alert.setHeaderText("����ó�� ������� ���� 11�ڸ��� �Է��ؾ� �մϴ�");
						alert.setContentText("����ó2 ���Է�");
						alert.showAndWait();

						txtCustomerContact2.requestFocus();
					} else if (!registeredNo.equals("") && (companyName.equals("") || representative.equals(""))) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�ŷ�ó ���");
						alert.setHeaderText("���� ���� �Է½� ����ڵ�Ϲ�ȣ/��ȣ/��ǥ�� ��� �Է��ؾ��մϴ�.");
						alert.setContentText("���� ���� ���Է�");
						alert.showAndWait();
					} else if (!companyName.equals("") && (registeredNo.equals("") || representative.equals(""))) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�ŷ�ó ���");
						alert.setHeaderText("���� ���� �Է½� ����ڵ�Ϲ�ȣ/��ȣ/��ǥ�� ��� �Է��ؾ��մϴ�.");
						alert.setContentText("���� ���� ���Է�");
						alert.showAndWait();
					} else if (!representative.equals("") && (registeredNo.equals("") || companyName.equals(""))) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�ŷ�ó ���");
						alert.setHeaderText("���� ���� �Է½� ����ڵ�Ϲ�ȣ/��ȣ/��ǥ�� ��� �Է��ؾ��մϴ�.");
						alert.setContentText("���� ���� ���Է�");
						alert.showAndWait();
					} else if (!registeredNo.equals("") && registeredNo.length() != 10) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�ŷ�ó ���");
						alert.setHeaderText("����ڵ�Ϲ�ȣ�� ���� ���� ���� 10�ڸ��� �Է��ؾ��մϴ�.");
						alert.setContentText("����ڵ�Ϲ�ȣ ���Է�");
						alert.showAndWait();

						txtCustomerRegisteredNo.requestFocus();
					} else if (!companyName.equals("") && 10 < companyName.length()) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�ŷ�ó ���");
						alert.setHeaderText("��ȣ���� �ѱ� 10�ڸ�, ����/���� 20�ڸ� ���Ϸ� �Է��Ͻʽÿ�.");
						alert.setContentText("��ȣ�� ���Է�");
						alert.showAndWait();

						txtCustomerCompany.requestFocus();
					} else if (!representative.equals("") && 5 < representative.length()) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�ŷ�ó ���");
						alert.setHeaderText("��ǥ�ڸ��� �ѱ� 5�ڸ� ���Ϸ� �Է��Ͻʽÿ�.");
						alert.setContentText("��ǥ�ڸ� ���Է�");
						alert.showAndWait();

						txtCustomerRepresentative.requestFocus();
					} else {
						boolean customerNameCheckResult = false;
						customerNameCheckResult = dao.checkCustomerName(name);
						if (customerNameCheckResult) {
							Alert alert = new Alert(AlertType.WARNING);
							alert.setTitle("�ŷ�ó�� �ߺ�Ȯ��");
							alert.setHeaderText(name + "�� ����� �� �����ϴ�.");
							alert.setContentText("�ŷ�ó�� �ߺ�");
							alert.showAndWait();
							txtCustomerName.clear();
							txtCustomerName.requestFocus();
						} else {
							model.setCustomer_name(name);
							model.setContact1(contact1);
							model.setContact2(contact2);
							model.setCorporate_registration_number(registeredNo);
							model.setCompany_name(companyName);
							model.setRepresentative(representative);
							model.setBusiness_license(license);
							model.setCustomer_no(no);
							dao.updateCustomerInformation(model);
							customerNameList = dao.callCustomerName();
							lvCustomer.setItems(customerNameList);
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnMemberDeleteAction(ActionEvent event) {
		MemberDAO dao = null;
		String getNo = "";
		int no = 0;
		boolean deleted = false;
		try {
			if (event.getSource().equals(btnMemberDelete)) {
				dao = new MemberDAO();
				getNo = txtMemberNo.getText();
				if (!getNo.equals("")) {
					no = Integer.parseInt(txtMemberNo.getText());
					deleted = dao.deleteMember(no);
					if (deleted) {
						memberIdList = member_dao.callMemberId();
						lvMember.setItems(memberIdList);
					}
				} else {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�������� ����");
					alert.setHeaderText("������ ���� ������ �����Ͻʽÿ�");
					alert.setContentText("������ ���� ����");
					alert.showAndWait();
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnMemeberEditAction(ActionEvent event) {
		MemberDAO dao = null;
		MemberVO model = null;
		String getNo = "";
		int no = 0;
		String name = "";
		String id = "";
		String pw = "";
		String checkPw = "";
		String department = "";
		String position = "";
		String phone = "";
		try {
			if (event.getSource().equals(btnMemberEdit)) {
				getNo = txtMemberNo.getText();
				if (!getNo.equals("")) {
					dao = new MemberDAO();
					model = new MemberVO();
					no = Integer.parseInt(txtMemberNo.getText());
					id = txtMemberId.getText().trim();
					pw = txtMemberPw.getText().trim();
					checkPw = txtMemberCheckPw.getText().trim();
					department = txtMemberDepartment.getText().trim();
					position = txtMemberPosition.getText().trim();
					name = txtMemberName.getText().trim();
					phone = txtMemberPhone.getText().trim();

					if (id.length() < 5 || id.length() > 10) {
						txtMemberId.clear();
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("���̵� Ȯ��");
						alert.setHeaderText("���̵�� 5~10���� ���� �Ǵ� ����/���� �������� �Է��Ͻʽÿ�.");
						alert.setContentText("���̵� ���Է�");
						alert.showAndWait();
						txtMemberName.requestFocus();
					} else if (pw.length() < 10 || 15 < pw.length()) {
						txtMemberPw.clear();
						txtMemberCheckPw.clear();
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�н����� Ȯ��");
						alert.setHeaderText("�н������ 10~15���� ����/���� �������� �Է��Ͻʽÿ�.");
						alert.setContentText("�н����� ���Է�");
						alert.showAndWait();
						txtMemberPw.requestFocus();
					} else if (name.equals("")) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�̸� �Է�");
						alert.setHeaderText("�̸� �Է¶��� �̸��� �Է��Ͻʽÿ�.");
						alert.setContentText("�̸� �Է� �� ����");
						alert.showAndWait();
						txtMemberName.requestFocus();
					} else if (position.equals("")) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("���� �Է�");
						alert.setHeaderText("���� �Է¶��� ������ �Է��Ͻʽÿ�.");
						alert.setContentText("���� �Է� �� ����");
						alert.showAndWait();
						txtMemberPosition.requestFocus();
					} else if (phone.length() != 11) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("��ȭ��ȣ �Է�");
						alert.setHeaderText("��ȭ��ȣ�� ���� ���� ��Ȯ�� �Է��Ͻʽÿ�.");
						alert.setContentText("��ȭ ��ȣ �Է� �� ����");
						alert.showAndWait();
						txtMemberPhone.requestFocus();
					} else if (checkPw.equals("")) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�н����� Ȯ��");
						alert.setHeaderText("�н����� Ȯ��â�� ������ �н����带 �� �� �� �Է��Ͻʽÿ�.");
						alert.setContentText("�н����� Ȯ�� �Է� �� ����");
						alert.showAndWait();
						txtMemberCheckPw.requestFocus();
					} else if (!checkPw.equals(pw)) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�н����� Ȯ��");
						alert.setHeaderText("�н����� Ȯ�� ���� �н������ �����ϰ� �Է��Ͻʽÿ�.");
						alert.setContentText("�н����� ���� �н����� Ȯ�� ���� ����ġ");
						alert.showAndWait();
						txtMemberPw.clear();
						txtMemberCheckPw.requestFocus();
					} else if (!department.equals("����") && !department.equals("â��") && !department.equals("�繫��")) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�������� ����");
						alert.setHeaderText("�μ��� '����', 'â��', '�繫��'�߿� �ϳ��� ��Ȯ�� �Է��Ͻʽÿ�.");
						alert.setContentText("�μ� ���Է�");
						alert.showAndWait();
						txtMemberDepartment.clear();
						txtMemberDepartment.requestFocus();
					} else if (!position.equals("���") && !position.equals("�븮") && !position.equals("����")
							&& !position.endsWith("����") && !position.equals("����")) {
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�������� ����");
						alert.setHeaderText("���޴� '���', '�븮', '����', '����', '����'�߿� �ϳ��� ��Ȯ�� �Է��Ͻʽÿ�.");
						alert.setContentText("���� ���Է�");
						alert.showAndWait();
						txtMemberPosition.clear();
						txtMemberPosition.requestFocus();
					} else {
						boolean idCheckResult = false;
						idCheckResult = dao.idOverlapCheck(id);
						if (idCheckResult) {
							Alert alert = new Alert(AlertType.WARNING);
							alert.setTitle("���̵� �ߺ�Ȯ��");
							alert.setHeaderText(id + "�� ����� �� �����ϴ�.");
							alert.setContentText("���̵� �ߺ�");
							alert.showAndWait();
							txtMemberId.clear();
							txtMemberId.requestFocus();
						} else {
							model.setMamber_no(no);
							model.setId(id);
							model.setPassword(pw);
							model.setMember_name(name);
							model.setMember_phone(phone);
							model.setDepartment(department);
							model.setPosition(position);

							dao.updateMemberInformation(model);
							memberIdList = dao.callMemberId();
							lvMember.setItems(memberIdList);
						}
					}
				} else {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�������� ����");
					alert.setHeaderText("������ ���� ������ �����Ͻʽÿ�");
					alert.setContentText("������ ���� ����");
					alert.showAndWait();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnMemberSearchAction(ActionEvent event) {
		String id = "";
		MemberDAO dao = null;
		MemberVO model = null;
		try {
			if (event.getSource().equals(btnMemberSearch)) {
				if (lvMember.getSelectionModel().getSelectedItem() == null) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("���� ���� ��ȸ");
					alert.setHeaderText("���� ����Ʈ���� ������ ���̵� �����Ͻʽÿ�.");
					alert.setContentText("���� ���̵� ���� �� ����");
					alert.show();
					lvMember.requestFocus();
				} else {
					id = lvMember.getSelectionModel().getSelectedItem();
					dao = new MemberDAO();
					model = new MemberVO();
					model = dao.callMemberInformation(id);
					txtMemberNo.setText(model.getMamber_no() + "");
					txtMemberId.setText(model.getId());
					txtMemberPw.setText(model.getPassword());
					txtMemberCheckPw.setText(model.getPassword());
					txtMemberDepartment.setText(model.getDepartment());
					txtMemberPosition.setText(model.getPosition());
					txtMemberName.setText(model.getMember_name());
					txtMemberPhone.setText(model.getMember_phone());
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public boolean handlerBtnCustomerSearchAction(ActionEvent event) {
		boolean callCustomer = false;
		String name = "";
		CustomerDAO dao = null;
		CustomerVO model = null;
		try {
			if (event.getSource().equals(btnCustomerSearch)) {
				if (lvCustomer.getSelectionModel().getSelectedItem() == null) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�ŷ�ó ���� ��ȸ");
					alert.setHeaderText("�ŷ�ó ����Ʈ���� �ŷ�ó�̸��� �����Ͻʽÿ�.");
					alert.setContentText("�ŷ�ó�̸� ���� �� ����");
					alert.show();
					lvCustomer.requestFocus();
				} else {
					dao = new CustomerDAO();
					model = new CustomerVO();
					name = lvCustomer.getSelectionModel().getSelectedItem();
					model = dao.callCustomerInformation(name);
					txtCustomerNo.setText(model.getCustomer_no() + "");
					txtCustomerName.setText(model.getCustomer_name());
					txtCustomerContact1.setText(model.getContact1());
					txtCustomerContact2.setText(model.getContact2());
					txtCustomerRegisteredNo.setText(model.getCorporate_registration_number());
					txtCustomerCompany.setText(model.getCompany_name());
					txtCustomerRepresentative.setText(model.getRepresentative());
					callCustomer = true;
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return callCustomer;
	}

	public void handlerBtnLoginAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/login_office.fxml"));
			Parent login_office = (Parent) loader.load();
			Scene scene = new Scene(login_office);
			Stage mainStage = new Stage();
			mainStage.setScene(scene);
			mainStage.setResizable(false);
			mainStage.setTitle("Login");
			Stage oldStage = (Stage) btnLogin.getScene().getWindow();
			oldStage.close();
			mainStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnDepartmentAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/department.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�μ�����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnDepartment.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
