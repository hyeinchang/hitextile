package control;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import model.MemberVO;

public class MemberController implements Initializable {
	@FXML
	TableView<MemberVO> tableView = new TableView<>();
	ObservableList<MemberVO> data = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		tableView.setEditable(false);
		
		TableColumn colNo = new TableColumn("������ȣ");
		colNo.setMaxWidth(40);
		colNo.setStyle("-fx-alignment:CENTER");
		//colNo.setCellFactory(new PropertyValueFactory<>("no"));

		TableColumn colName = new TableColumn("�̸�");
		colName.setMaxWidth(60);
		colName.setStyle("-fx-alignment:CENTER");
		//colName.setCellFactory(new PropertyValueFactory<>("name"));

		TableColumn colDepartment = new TableColumn("�Ҽ�");
		colDepartment.setMaxWidth(40);
		//colDepartment.setCellFactory(new PropertyValueFactory<>("year"));

		TableColumn colPostion = new TableColumn("����");
		colPostion.setMaxWidth(40);
		//colPostion.setCellFactory(new PropertyValueFactory<>("ban"));

		TableColumn colID = new TableColumn("ID");
		colID.setMaxWidth(40);
		//colID.setCellFactory(new PropertyValueFactory<>("gender"));


		tableView.setItems(data);
		
		tableView.getColumns().addAll(colNo, colName, colDepartment, colPostion, colID);
		
	}
}
