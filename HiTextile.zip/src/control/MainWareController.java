package control;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.text.TabableView;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.SearchVO;
import model.StockVO;
import model.TransactionVO;

public class MainWareController implements Initializable {
	@FXML
	private TextField txtProductName;
	@FXML
	private Button btnProductSearch;
	@FXML
	private ComboBox<String> cbColour;
	@FXML
	private TextField txtRollStock;
	@FXML
	private TextField txtYardStock;
	@FXML
	private Button btnRenew;
	@FXML
	private TextField txtIn;
	@FXML
	private TextField txtHolding;
	@FXML
	private TextField txtSample;
	@FXML
	private TextField txtOut;
	@FXML
	private TextField txtReturn;
	@FXML
	private TextField txtDefective;
	@FXML
	private TextField txtService;
	@FXML
	private TextField txtStockMemo;
	@FXML
	private Button btnStockOk;
	@FXML
	private Button btnStockDelete;
	@FXML
	private Button btnProductInformation;
	@FXML
	private Button btnProductUpload;
	@FXML
	private TextField txtSearchStockNo;
	@FXML
	private TextField txtSearchStockName;
	@FXML
	private TextField txtSearchStockMaterial;
	@FXML
	private ComboBox<String> cbSearchStockColour;
	@FXML
	private DatePicker dpStockDate;
	@FXML
	private Button btnStockSearch;
	@FXML
	private TableView<StockVO> stockTable;
	@FXML
	private TextField txtCustomerName;
	@FXML
	private Button btnDeliveryUpload;
	@FXML
	private TextField txtProduct1;
	@FXML
	private TextField txtColour1;
	@FXML
	private TextField txtYard1;
	@FXML
	private TextField txtProduct2;
	@FXML
	private TextField txtColour2;
	@FXML
	private TextField txtYard2;
	@FXML
	private TextField txtProduct3;
	@FXML
	private TextField txtColour3;
	@FXML
	private TextField txtYard3;
	@FXML
	private TextField txtContact1;
	@FXML
	private TextField txtContact2;
	@FXML
	private TextField txtAddress;
	@FXML
	private ToggleGroup paymentGroup;
	@FXML
	private RadioButton rbBeforePayment;
	@FXML
	private RadioButton rbAfterPayment;
	@FXML
	private ToggleGroup deliveryGroup;
	@FXML
	private RadioButton rbStock;
	@FXML
	private RadioButton rbHolding;
	@FXML
	private RadioButton rbComplete;
	@FXML
	private TextField txtDeliverMemo;
	@FXML
	private Button btnCutomer;
	@FXML
	private Button btnLogin;
	@FXML
	private Button btnDepartment;
	@FXML
	private Button btnChart;
	@FXML
	private TextField txtSearchCustomer;
	@FXML
	private TextField txtSearchFabric;
	@FXML
	private ComboBox<String> cbSearchPayment;
	@FXML
	private ComboBox<String> cbSearchDelivery;
	@FXML
	private DatePicker dpSearchTransaction;
	@FXML
	private TextField txtSearchTransactionNo;
	@FXML
	private ComboBox<String> cbSearchTransactionColour;
	@FXML
	private TextField txtSearchAddress;
	@FXML
	private TextField txtSearchMemo;
	@FXML
	private Button btnSearchTransaction;
	@FXML
	private ImageView btnCustomerReceipt;
	@FXML
	private TextField txtTransactionNo2;
	// TableView
	@FXML
	private TableView<TransactionVO> transactionTable;
	ObservableList<StockVO> stock = FXCollections.observableArrayList();
	ObservableList<TransactionVO> transaction = FXCollections.observableArrayList();
	int stockNo = 0;
	int transactionNo = 0;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		MemberDAO dao = new MemberDAO();
		
		cbColour.setItems(FXCollections.observableArrayList("ȭ��Ʈ", "������", "��ũ", "����", "����"));
		txtRollStock.setText("0");
		txtYardStock.setText("0");
		txtIn.setText("0");
		txtOut.setText("0");
		txtHolding.setText("0");
		txtReturn.setText("0");
		txtSample.setText("0");
		txtDefective.setText("0");
		txtService.setText("0");
		// ����� �԰� ����� ������ ���ؼ��� ���氡��
		txtRollStock.setEditable(false);
		txtYardStock.setEditable(false);
		
		btnStockOk.setDisable(true);
		btnStockDelete.setDisable(true);
		btnRenew.setDisable(true);

		cbSearchStockColour.setItems(FXCollections.observableArrayList("ȭ��Ʈ", "������", "��ũ", "����", "����"));

		stockTable.setEditable(false);
		TableColumn colStock_no = new TableColumn("���no");
		colStock_no.setMinWidth(70);
		colStock_no.setMaxWidth(70);
		colStock_no.setStyle("-fx-alignment:CENTER");
		colStock_no.setCellValueFactory(new PropertyValueFactory<>("stock_no"));
		TableColumn colFabric_name = new TableColumn("���ܸ�");
		colFabric_name.setMinWidth(100);
		colFabric_name.setMaxWidth(100);
		colFabric_name.setStyle("-fx-alignment:CENTER");
		colFabric_name.setCellValueFactory(new PropertyValueFactory<>("fabric_name"));
		TableColumn colFabric_colour = new TableColumn("�÷�");
		colFabric_colour.setMinWidth(80);
		colFabric_colour.setMaxWidth(80);
		//colFabric_colour.setStyle("-fx-alignment:CENTER");
		colFabric_colour.setCellValueFactory(new PropertyValueFactory<>("fabric_colour"));
		TableColumn colStock = new TableColumn("���");
		colStock.setMinWidth(100);
		colStock.setMaxWidth(100);
		colStock.setStyle("-fx-alignment:CENTER");
		colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));
		TableColumn colStock_in = new TableColumn("�԰�");
		colStock_in.setMinWidth(100);
		colStock_in.setMaxWidth(100);
		colStock_in.setStyle("-fx-alignment:CENTER");
		colStock_in.setCellValueFactory(new PropertyValueFactory<>("stock_in"));
		TableColumn colStock_out = new TableColumn("���");
		colStock_out.setMinWidth(100);
		colStock_out.setMaxWidth(100);
		colStock_out.setStyle("-fx-alignment:CENTER");
		colStock_out.setCellValueFactory(new PropertyValueFactory<>("stock_out"));
		TableColumn colStock_holding = new TableColumn("Ȧ��");
		colStock_holding.setMinWidth(80);
		colStock_holding.setMaxWidth(80);
		colStock_holding.setStyle("-fx-alignment:CENTER");
		colStock_holding.setCellValueFactory(new PropertyValueFactory<>("stock_holding"));
		TableColumn colStock_Loss = new TableColumn("�ս�");
		colStock_Loss.setMinWidth(80);
		colStock_Loss.setMaxWidth(80);
		colStock_Loss.setStyle("-fx-alignment:CENTER");
		colStock_Loss.setCellValueFactory(new PropertyValueFactory<>("stock_loss"));
		TableColumn colStock_return = new TableColumn("��ǰ");
		colStock_return.setMinWidth(80);
		colStock_return.setMaxWidth(80);
		colStock_return.setStyle("-fx-alignment:CENTER");
		colStock_return.setCellValueFactory(new PropertyValueFactory<>("stock_return"));
		TableColumn colStock_date = new TableColumn("�����");
		colStock_date.setMinWidth(120);
		colStock_date.setMaxWidth(120);
		colStock_date.setCellValueFactory(new PropertyValueFactory<>("stock_date"));

		stockTable.setItems(stock);
		stockTable.getColumns().addAll(colStock_no, colFabric_name, colFabric_colour, colStock, colStock_in,
				colStock_out, colStock_holding, colStock_Loss, colStock_return, colStock_date);
		stockList();
		
		btnRenew.setOnAction(event -> handlerBtnRenewConditionAction(event));
		btnRenew.setOnAction(event -> handlerBtnRenewAction(event));
		btnCutomer.setOnAction(event -> handlerBtnCustomerAction(event));
		btnLogin.setOnAction(event -> handlerBtnLoginAction(event));
		btnDepartment.setOnAction(event -> handlerBtnDepartmentAction(event));
		btnProductUpload.setOnAction(event -> handlerBtnProductUploadAction(event));
		btnProductSearch.setOnAction(event -> handlerBtnProductSearchAction(event));
		stockTable.setOnMouseClicked(event -> handlerCallStockInformationAction(event));
		btnProductInformation.setOnAction(event -> handlerBtnProductInformationAction(event));
		btnStockOk.setOnAction(event -> handlerBtnStockUploadAction(event));
		btnStockDelete.setOnAction(event -> handlerBtnStockDeleteAction(event));
		btnStockSearch.setOnAction(event -> handelrBtnStockSearchAction(event));
		
		transactionTable.setEditable(false);
		TableColumn colTransaction_no = new TableColumn("�ŷ�no");
		colTransaction_no.setMaxWidth(70);
		colTransaction_no.setMinWidth(70);
		colTransaction_no.setStyle("-fx-alignment:CENTER");
		colTransaction_no.setCellValueFactory(new PropertyValueFactory<>("transaction_no"));
		TableColumn colCustomerName = new TableColumn("�ŷ�ó");
		colCustomerName.setMaxWidth(100);
		colCustomerName.setMinWidth(100);
		colCustomerName.setStyle("-fx-alignment:CENTER");
		colCustomerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
		TableColumn colOrder = new TableColumn("�ֹ�����");
		colOrder.setMaxWidth(240);
		colOrder.setMinWidth(240);
		colOrder.setStyle("-fx-alignment:CENTER");
		colOrder.setCellValueFactory(new PropertyValueFactory<>("orderList"));
		TableColumn colCheck_payment = new TableColumn("��������");
		colCheck_payment.setMaxWidth(60);
		colCheck_payment.setMinWidth(60);
		colCheck_payment.setStyle("-fx-alignment:CENTER");
		colCheck_payment.setCellValueFactory(new PropertyValueFactory<>("check_payment"));
		TableColumn colCheck_delivery = new TableColumn("��ۿ���");
		colCheck_delivery.setMaxWidth(60);
		colCheck_delivery.setMinWidth(60);
		colCheck_delivery.setStyle("-fx-alignment:CENTER");
		colCheck_delivery.setCellValueFactory(new PropertyValueFactory<>("check_delivery"));
		TableColumn colAddress = new TableColumn("�����");
		colAddress.setMaxWidth(148);
		colAddress.setMinWidth(148);
		colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
		TableColumn colMemo = new TableColumn("�޸�");
		colMemo.setMaxWidth(120);
		colMemo.setMinWidth(120);
		colMemo.setCellValueFactory(new PropertyValueFactory<>("memo"));
		TableColumn colTransaction_date = new TableColumn("�����");
		colTransaction_date.setMaxWidth(100);
		colTransaction_date.setMinWidth(100);
		colTransaction_date.setCellValueFactory(new PropertyValueFactory<>("transaction_date"));
		transactionTable.setItems(transaction);
		transactionTable.getColumns().addAll(colTransaction_no, colCustomerName, colOrder, 
				colCheck_payment, colCheck_delivery, colAddress, colMemo,
				colTransaction_date);
		transactionList();
		
		cbSearchTransactionColour.setItems(FXCollections.observableArrayList("ȭ��Ʈ", "������", "��ũ", "����", "����"));
		cbSearchPayment.setItems(FXCollections.observableArrayList("û��", "����"));
		cbSearchDelivery.setItems(FXCollections.observableArrayList("���", "Ȧ��", "�Ϸ�"));
		
		transactionTable.setOnMouseClicked(event -> handlerSelectTransactionInformation(event));
		btnCustomerReceipt.setOnMouseClicked(event -> handlerCustomerRecieptViewAction(event));
		
		txtProduct1.setEditable(false);
		txtColour1.setEditable(false);
		txtYard1.setEditable(false);
		txtProduct2.setEditable(false);
		txtColour2.setEditable(false);
		txtYard1.setEditable(false);
		txtProduct3.setEditable(false);
		txtColour3.setEditable(false);
		txtYard3.setEditable(false);
		txtContact1.setEditable(false);
		
		btnDeliveryUpload.setOnAction(event -> handlerBtnDeliveryUploadAction(event));
		btnSearchTransaction.setOnAction(event -> handlerBtnTransactionAction(event));
		btnChart.setOnAction(event -> handlerBtnChartAction(event));
	}

	public void handlerBtnChartAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/chart_choice.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("��Ʈ ����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnTransactionAction(ActionEvent event) {
		SearchDAO searchDao = null;
		SearchVO search = null;

		int transaction_no = 0;
		String customer_name = "";
		String fabric_name = "";
		String fabric_colour = "";
		String address = "";
		String check_payment = "";
		String check_delivery = "";
		String memo = "";
		String transaction_date = "";
		String colour_abb = "";
		ObservableList<TransactionVO> list = FXCollections.observableArrayList();
		try {
			searchDao = new SearchDAO();
			search = new SearchVO();
			SearchVO search2 = new SearchVO();
			SearchVO search3 = new SearchVO();
			transaction_no = Integer.parseInt(search2.nullToValue3(txtSearchTransactionNo.getText().trim()));
			customer_name = search2.nullToValue(txtSearchCustomer.getText().trim());
			fabric_name = search2.nullToValue(txtSearchFabric.getText().trim());
			address = search2.nullToValue(txtSearchAddress.getText().trim());
			check_payment = search2.nullToValue2(cbSearchPayment.getSelectionModel().getSelectedItem());
			check_delivery = search2.nullToValue2(cbSearchDelivery.getSelectionModel().getSelectedItem());
			memo = search2.nullToValue(txtSearchMemo.getText().trim());
			transaction_date = search2.nullToValue(dpSearchTransaction.getValue() + "");
			colour_abb = search3.colourNameChange(cbSearchTransactionColour.getSelectionModel().getSelectedItem());
			String order = "x";

			if (fabric_name.equals(" ") && !colour_abb.equals(" ")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ����� �˻�");
				alert.setHeaderText("���ܸ��� �Է��Ͻʽÿ�");
				alert.setContentText("���ܸ� �Է� �� ����");
				alert.showAndWait();
				txtSearchFabric.requestFocus();
			} else if (!fabric_name.equals(" ") && colour_abb.equals(" ")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ����� �˻�");
				alert.setHeaderText("�÷��� �����Ͻʽÿ�");
				alert.setContentText("���ܸ� ���� �� ����");
				alert.showAndWait();
				txtSearchFabric.requestFocus();
			} else if (transaction_no != 0) {
				search.setTransaction_no(transaction_no);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
				return;
			} else if (!customer_name.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
		
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!address.equals(" ")) {
				search.setAddress(address);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_payment.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_delivery.equals(" ")) {
				search.setCheck_delivery(check_delivery);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memo.equals(" ")) {
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!transaction_date.equals(" ")) {
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && (!address.equals(" "))) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && !address.equals(" ") && !check_payment.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && !address.equals(" ") && !check_payment.equals(" ")
					&& !check_delivery.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && !address.equals(" ") && !check_payment.equals(" ")
					&& !check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && !address.equals(" ") && !check_payment.equals(" ")
					&& !check_delivery.equals(" ") && !memo.equals(" ") && !transaction_date.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ")
					&& !address.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && !address.equals(" ")
					&& !check_payment.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && !address.equals(" ")
					&& !check_payment.equals(" ") && !check_delivery.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && !address.equals(" ")
					&& !check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") &&!address.equals(" ")
					&& !check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")
					&& !transaction_date.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && !address.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && !address.equals(" ")
					&& !check_payment.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && !address.equals(" ") && !check_payment.equals(" ")
					&& !check_delivery.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && !address.equals(" ") && !check_payment.equals(" ")
					&& !check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && !address.equals(" ")
					&& !check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")
					&& !transaction_date.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!address.equals(" ") && !check_payment.equals(" ")) {
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!address.equals(" ") && !check_payment.equals(" ") && !check_delivery.equals(" ")) {
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!address.equals(" ") && !check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!address.equals(" ") && !check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")
					&& !transaction_date.equals(" ")) {
				search.setAddress(address);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_payment.equals(" ") && !check_delivery.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")
					&& !transaction_date.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_delivery.equals(" ") && !memo.equals(" ") && !transaction_date.equals(" ")) {
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memo.equals(" ") && !transaction_date.equals(" ")) {
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ����� �˻�");
				alert.setHeaderText("�˻��� ���� �Է��Ͻʽÿ�.");
				alert.setContentText("���Է�");
				alert.showAndWait();
			}

		} catch (Exception e) {
			e.printStackTrace();
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�ŷ����� �˻�");
			alert.setHeaderText("�Է��� ���� Ȯ���Ͻʽÿ�.");
			alert.setContentText("���Է�");
			alert.showAndWait();
		}
	}

	public void handlerBtnDeliveryUploadAction(ActionEvent event) {
		TransactionDAO dao = null;
		TransactionVO model = null;
		String memo = "";
		String delivery = "";
		
		try {
			dao = new TransactionDAO();
			model = new TransactionVO();
			
			memo = txtDeliverMemo.getText();
			delivery = deliveryGroup.getSelectedToggle().getUserData().toString();
			
			model.setTransaction_no(transactionNo);
			model.setCheck_delivery(delivery);
			model.setMemo(memo);
			
			dao.updateTransactionInformation2(model);
			
			txtAddress.clear();
			txtColour1.clear();
			txtColour2.clear();
			txtColour3.clear();
			txtContact1.clear();
			txtContact2.clear();
			txtCustomerName.clear();
			txtDeliverMemo.clear();
			txtProduct1.clear();
			txtProduct2.clear();
			txtProduct3.clear();
			txtYard1.clear();
			txtYard2.clear();
			txtYard3.clear();
			txtTransactionNo2.clear();
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public int nullToValue(String name, String colour) {
		int stockNo = 0;
		TransactionDAO dao = new TransactionDAO();

		if (name.equals("") && colour.equals("")) {
			stockNo = 0;
		} else {
			stockNo = dao.returnStockNo(name, colour);
		}
		return stockNo;
	}

	public void handelrBtnStockSearchAction(ActionEvent event) {
		stockTableRenew();
	}

	public void handlerBtnStockDeleteAction(ActionEvent event) {
		String name = "";
		String colour = "";
		StockDAO dao = null;
		int stockNo = 0;
		boolean deleted = false;
		
		try {
			dao = new StockDAO();
			name = txtProductName.getText();
			colour = cbColour.getSelectionModel().getSelectedItem();
			stockNo = dao.callStockNo(name, colour);
			deleted = dao.deleteStockRecord(stockNo);
			
			if (deleted) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��� ���� �Ϸ�");
				alert.setHeaderText("'�˻�'��ư�� ���� �������� �����Ͻʽÿ�");
				alert.setContentText("�������");
				alert.showAndWait();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerCustomerRecieptViewAction(MouseEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/enter_transaction_no.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�ŷ���ȣ �Է�");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerSelectTransactionInformation(MouseEvent event) {
		transactionNo = transactionTable.getSelectionModel().getSelectedItem().getTransaction_no();
		TransactionDAO dao = null;
		TransactionVO model = null;
		StockDAO stockDao = null;
		StockVO fabric1 = null;
		StockVO fabric2 = null;
		StockVO fabric3 = null;
		String customer = "";
		String product1 = "";
		String colour1 = "";
		double yard1 = 0;
		String contact1 = "";
		String contact2 = "";
		String address = "";
		String pay = "";
		String delivery = "";
		String memo = "";
		String product2 = "";
		String colour2 = "";
		double yard2 = 0;
		String product3 = "";
		String colour3 = "";
		double yard3 = 0;
		int stock1 = 0;
		int stock2 = 0;
		int stock3 = 0;
		
		try {
			dao = new TransactionDAO();
			model = new TransactionVO();
			model = dao.callReceiptInformation2(transactionNo);
			stockDao = new StockDAO();
			
			stock1 = model.getStock_no1();
			stock2 = model.getStock_no2();
			stock3 = model.getStock_no3();
			
			fabric1 = new StockVO();
			fabric1 = stockDao.callNameAndColourAndCost(stock1);
			product1 = fabric1.getFabric_name();
			colour1 = fabric1.getFabric_colour();
			
			fabric2 = new StockVO();
			fabric2 = stockDao.callNameAndColourAndCost(stock2);
			product2 = fabric2.getFabric_name();
			colour2 = fabric2.getFabric_colour();
			
			fabric3 = new StockVO();
			fabric3 = stockDao.callNameAndColourAndCost(stock3);
			product3 = fabric3.getFabric_name();
			colour3 = fabric3.getFabric_colour();
			
			customer = model.getCustomerName();
			contact1 = model.getContact1();
			contact2 = model.getContact2();
			address = model.getAddress();
			pay = model.getCheck_payment();
			delivery = model.getCheck_delivery();
			memo = model.getMemo();
			
			yard1 = model.getYard1();
			yard2 = model.getYard2();
			yard3 = model.getYard3();
			
			txtTransactionNo2.setText(transactionNo + "");
			txtCustomerName.setText(customer);
			txtProduct1.setText(product1);
			txtColour1.setText(colour1);
			txtYard1.setText(yard1 + "");
			txtProduct2.setText(product2);
			txtColour2.setText(colour2);
			txtYard2.setText(yard2 + "");
			txtProduct3.setText(product3);
			txtColour3.setText(colour3);
			txtYard3.setText(yard3 + "");
			txtContact1.setText(contact1);
			txtContact2.setText(contact2);
			txtAddress.setText(address);
			txtDeliverMemo.setText(memo);
		
			if (pay.equals("û��")) {
				rbBeforePayment.setSelected(true);
				rbAfterPayment.setDisable(true);
			} else if (pay.equals("����")) {
				rbAfterPayment.setSelected(true);
				rbBeforePayment.setDisable(true);
			}
			
			if (delivery.equals("���")) {
				rbStock.setSelected(true);
			} else if(delivery.equals("Ȧ��")) {
				rbHolding.setSelected(true);
			} else if (delivery.equals("�Ϸ�")) {
				rbComplete.setSelected(true);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnStockUploadAction(ActionEvent event) {
		try {
			if (event.getSource().equals(btnStockOk)) {
				txtProductName.clear();
				cbColour.getSelectionModel().clearSelection();
				stockTableRenew();	
				btnStockOk.setDisable(true);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerCallStockInformationAction(MouseEvent event) {
		stockNo = stockTable.getSelectionModel().getSelectedItem().getStock_no();
		StockDAO dao = null;
		StockVO model = null;
		String name = "";
		ObservableList<String> colour = FXCollections.observableArrayList();
		double stock = 0;
		double in = 0;
		double out = 0;
		double holding = 0;
		double stockReturn = 0;
		double sample = 0;
		double defective = 0;
		double service = 0;
		String memo = "";
		int roll = 0;
		double yard = 0;
		
		txtProductName.setEditable(false);
		cbColour.setEditable(false);
		try {
			dao = new StockDAO();
			model = dao.callStockInfomation(stockNo);
			name = model.getFabric_name();
			colour = dao.callColour(stockNo);
			stock = model.getStock();
			in = model.getStock_in();
			out = model.getStock_out();
			holding = model.getStock_holding();
			stockReturn = model.getStock_return();
			sample = model.getStock_sample();
			defective = model.getStock_defective();
			service = model.getStock_service();
			memo = model.getStock_memo();
			
			roll = (int) (stock/50);
			yard = stock % 50;
			
			txtProductName.setText(name);
			cbColour.setItems(colour);
			cbColour.selectionModelProperty().get().selectFirst();
			txtRollStock.setText(roll + "");
			txtYardStock.setText(yard + "");
			txtIn.setText(in + "");
			txtOut.setText(out + "");
			txtHolding.setText(holding + "");
			txtReturn.setText(stockReturn + "");
			txtSample.setText(sample +"");
			txtDefective.setText(defective + "");
			txtService.setText(service + "");
			txtStockMemo.setText(memo);
			if (name.equals(" ")) {
				btnRenew.setDisable(true);
				btnStockDelete.setDisable(true);
			} else {
				btnRenew.setDisable(false);
				btnStockDelete.setDisable(false);
			}		
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}

	public void stockTableRenew() {
		StockDAO dao = new StockDAO();
		ObservableList<StockVO> stockRenewList = FXCollections.observableArrayList();
		stockRenewList = dao.getStockMainRenewInformation();
		stockTable.setItems(stockRenewList);
	}

	public void stockList() {
		Object[][] stockData;

		StockDAO dao = new StockDAO();
		StockVO model = null;
		ArrayList<String> title;
		ArrayList<StockVO> mainList;

		title = dao.getStockMainColumnName();
		int columnCount = title.size();

		mainList = dao.getStockMainInformation();
		int rowCount = mainList.size();

		stockData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			model = mainList.get(index);
			stock.add(model);
		}
	}
	
	public void transactionList() {
		Object[][] transactionData;

		TransactionDAO dao = new TransactionDAO();
		TransactionVO model = null;
		ArrayList<String> title;
		ArrayList<TransactionVO> list;

		title = dao.getWareTranasactionColumnName();
		int columnCount = title.size();

		list = dao.getWareTranasactionList();
		int rowCount = list.size();

		transactionData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			model = list.get(index);
			transaction.add(model);
		}
	}


	public void handlerBtnProductInformationAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/product_information.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("��ǰ �� ����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private void handlerBtnProductSearchAction(ActionEvent event) {
		StockDAO dao = null;
		String searchName = "";
		String searchColour = "";
		double stock = 0;
		double in = 0;
		double out = 0;
		double holding = 0;
		double stockReturn = 0;
		double sample = 0;
		double defective = 0;
		double service = 0;
		String memo = "";
		int roll;
		double yard;
		StockVO model = null;
		
		try {
			if (event.getSource().equals(btnProductSearch)) {
				searchName = txtProductName.getText().trim();
				searchColour = cbColour.getSelectionModel().getSelectedItem();
				if (searchName.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("��� �˻�");
					alert.setHeaderText("ǰ���� �Է��Ͻʽÿ�");
					alert.setContentText("ǰ�� �Է� �� ����");
					alert.showAndWait();
					txtProductName.requestFocus();
				} else if (searchColour == null) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("��� �˻�");
					alert.setHeaderText("�÷��� �����Ͻʽÿ�");
					alert.setContentText("�÷� �Է� �� ����");
					alert.showAndWait();
					cbColour.requestFocus();
				} else {
					dao = new StockDAO();
					model = dao.callStock(searchName, searchColour);
					stock = model.getStock();
					in = model.getStock_in();
					out = model.getStock_out();
					holding = model.getStock_holding();
					stockReturn = model.getStock_return();
					sample = model.getStock_sample();
					defective = model.getStock_defective();
					service = model.getStock_service();
					memo = model.getStock_memo();

					roll = (int) (stock / 50);
					yard = stock % 50;
					
					txtRollStock.setText(roll + "");
					txtYardStock.setText(yard + "");
					txtIn.setText(in + "");
					txtOut.setText(out + "");
					txtHolding.setText(holding + "");
					txtReturn.setText(stockReturn + "");
					txtSample.setText(sample +"");
					txtDefective.setText(defective + "");
					txtService.setText(service + "");
					txtStockMemo.setText(memo);
					
					btnRenew.setDisable(false);
					btnStockDelete.setDisable(true);
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnProductUploadAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/stock_registration.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("��ǰ���");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public boolean handlerBtnRenewConditionAction(ActionEvent event) {
		boolean renewSuccess = true;
		int rollStock = 0;
		double yardStock = 0;
		double in = 0;
		double out = 0;
		double holding = 0;
		double returnProduct = 0;
		double sample = 0;
		double defective = 0;
		double service = 0;
		try {
			rollStock = Integer.parseInt(txtRollStock.getText());
			yardStock = Double.parseDouble(txtYardStock.getText());
			in = Double.parseDouble(txtIn.getText());

			if (event.getSource().equals(btnRenew)) {
				if (rollStock * 50 + yardStock < out) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�������");
					alert.setHeaderText("����� ���� ������� Ŭ �� �����ϴ�.");
					alert.setContentText("��� ���Է�");
					alert.showAndWait();
					
					txtRollStock.clear();
					txtYardStock.clear();
					txtOut.requestFocus();
				} else if (in < 0) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�������");
					alert.setHeaderText("����� ��ǰ�� �԰� ���� ���� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("��ǰ �԰� ���Է�");
					alert.showAndWait();
					
					txtIn.clear();
					txtIn.requestFocus();
				} else if (out < 0) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�������");
					alert.setHeaderText("����� ��ǰ�� ��� ���� ���� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("��ǰ ��� ���Է�");
					alert.showAndWait();
					
					txtOut.clear();
					txtOut.requestFocus();
				} else if (holding < 0) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�������");
					alert.setHeaderText("����� ��ǰ�� Ȧ�� ���� ���� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("��ǰ Ȧ�� ���Է�");
					alert.showAndWait();
					
					txtHolding.clear();
					txtHolding.requestFocus();
				} else if (returnProduct < 0) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�������");
					alert.setHeaderText("����� ��ǰ�� ��ǰ ���� ���� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("��ǰ ��ǰ ���Է�");
					alert.showAndWait();
					
					txtReturn.clear();
					txtReturn.requestFocus();
				} else if (sample < 0) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�������");
					alert.setHeaderText("����� ��ǰ�� ���� ���� ���� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("��ǰ ���� ���Է�");
					alert.showAndWait();
					
					txtSample.clear();
					txtSample.requestFocus();
				} else if (defective < 0) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�������");
					alert.setHeaderText("����� ��ǰ�� �ҷ� ���� ���� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("��ǰ �ҷ� ���Է�");
					alert.showAndWait();
					
					txtDefective.clear();
					txtDefective.requestFocus();
				} else if (service < 0) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�������");
					alert.setHeaderText("����� ��ǰ�� ���� ���� ���� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("��ǰ ���� ���Է�");
					alert.showAndWait();
					
					txtService.clear();
					txtService.requestFocus();
				} else {
					renewSuccess = true;
				}
			}
		} catch (Exception e) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�������");
			alert.setHeaderText("����� ��ǰ�� ��� ������ Ȯ���Ͻʽÿ�.");
			alert.setContentText("���Է�");
			alert.showAndWait();
		}
		return renewSuccess;
	}

	public void handlerBtnRenewAction(ActionEvent event) {
		boolean renewSuccess = handlerBtnRenewConditionAction(event);
		int rollStock = Integer.parseInt(txtRollStock.getText());
		double yardStock = Double.parseDouble(txtYardStock.getText());
		double in = 0;
		double out = 0;
		double holding = 0;
		double returnProduct = 0;
		double sample = 0;
		double defective = 0;
		double service = 0;
		double sum = 0;
		StockDAO dao = null;
		StockVO model = null;
		int no = 0;
		String name = "";
		String colour = "";
		String memo = "";

		if (renewSuccess) {
			try {
				if (event.getSource().equals(btnRenew)) {
					renewSuccess = handlerBtnRenewConditionAction(event);
					rollStock = Integer.parseInt(txtRollStock.getText().trim());
					yardStock = Double.parseDouble(txtYardStock.getText().trim());
					in = Double.parseDouble(txtIn.getText().trim());
					out = Double.parseDouble(txtOut.getText().trim());
					holding = Double.parseDouble(txtHolding.getText().trim());
					returnProduct = Double.parseDouble(txtReturn.getText().trim());
					defective = Double.parseDouble(txtDefective.getText().trim());
					service = Double.parseDouble(txtService.getText().trim());
				
					sum = (rollStock * 50 + yardStock) + (in + returnProduct)
							- (out + holding + sample + defective + service);
					
					txtRollStock.setText((int) (sum / 50) + "");
					txtYardStock.setText(sum % 50 + "");
					
					rollStock = Integer.parseInt(txtRollStock.getText());
					yardStock = Double.parseDouble(txtYardStock.getText());
					
					
					dao = new StockDAO();
					model = new StockVO();
					double stock = rollStock * 50 + yardStock % 50;
					
					name = txtProductName.getText();
					colour = cbColour.getSelectionModel().getSelectedItem();
					no = dao.callStockNo(name, colour);
					memo = txtStockMemo.getText();
					model.setStock(stock);
					model.setStock_in(in);
					model.setStock_out(out);
					model.setStock_holding(holding);
					model.setStock_return(returnProduct);
					model.setStock_sample(sample);
					model.setStock_defective(defective);
					model.setStock_service(service);
					model.setStock_memo(memo);
					model.setStock_no(no);
					dao.updateStockInformation(model);
					
					txtRollStock.setText("0");
					txtYardStock.setText("0");
					txtIn.setText("0");
					txtOut.setText("0");
					txtHolding.setText("0");
					txtReturn.setText("0");
					txtSample.setText("0");
					txtDefective.setText("0");
					txtService.setText("0");
					
					btnStockOk.setDisable(false);
					RecordDAO record = new RecordDAO();
					int i = record.callNewStockNo();
					record.recordStock(i);
				}

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	public void handlerBtnDepartmentAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/department.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�μ�����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnDepartment.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnLoginAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/login_warehouse.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("â�� �α���");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnDepartment.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnCustomerAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/customer_view.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�ŷ�ó ����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
