package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.SingleSelectionModel;
import model.StockVO;

public class StockDAO {
	public ArrayList<String> getStockMainColumnName() {
		ArrayList<String> stockColumnName = new ArrayList<>();
		String sql = "select stock_no, fabric_name, fabric_colour, stock, stock_in, stock_out, stock_holding, "
				+ "(stock_sample + stock_defective + stock_service) as stock_loss, stock_return, stock_date from stock order by stock_no";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				stockColumnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return stockColumnName;
	}

	public ArrayList<StockVO> getStockMainInformation() {
		ArrayList<StockVO> information = new ArrayList<>();
		String sql = "select stock_no, fabric_name, fabric_colour, stock, stock_in, stock_out, stock_holding, "
				+ "(stock_sample + stock_defective + stock_service) as stock_loss, stock_return, stock_date from stock order by stock_no desc";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StockVO model = null;

		try { 
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				model = new StockVO();
				model.setStock_no(rs.getInt("stock_no"));
				model.setFabric_name(rs.getString("fabric_name"));
				model.setFabric_colour(rs.getString("fabric_colour"));

				model.setStock(rs.getDouble("stock"));
				model.setStock_in(rs.getDouble("stock_in"));
				model.setStock_out(rs.getDouble("stock_out"));
				model.setStock_holding(rs.getDouble("stock_holding"));

				model.setStock_loss(rs.getDouble("stock_loss"));

				model.setStock_return(rs.getDouble("stock_return"));
				model.setStock_date(rs.getString("stock_date"));

				information.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return information;
	}

	public ObservableList<StockVO> getStockMainRenewInformation() {
		ObservableList<StockVO> information = FXCollections.observableArrayList();
		String sql = "select stock_no, fabric_name, fabric_colour, stock, stock_in, stock_out, stock_holding, "
				+ "(stock_sample + stock_defective + stock_service) as stock_loss, stock_return, stock_date from stock order by stock_no desc";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StockVO model = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				model = new StockVO();
				model.setStock_no(rs.getInt("stock_no"));
				model.setFabric_name(rs.getString("fabric_name"));
				model.setFabric_colour(rs.getString("fabric_colour"));

				model.setStock(rs.getDouble("stock"));
				model.setStock_in(rs.getDouble("stock_in"));
				model.setStock_out(rs.getDouble("stock_out"));
				model.setStock_holding(rs.getDouble("stock_holding"));

				model.setStock_loss(rs.getDouble("stock_loss"));

				model.setStock_return(rs.getDouble("stock_return"));
				model.setStock_date(rs.getString("stock_date"));

				information.addAll(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return information;
	}

	public boolean enterProductInformation(StockVO enter) {
		boolean enterSuccess = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String date = "sysdate";
		String sql = "insert into stock (stock_no, fabric_name, fabric_colour,"
				+ "fabric_cost, fabric_material, stock, stock_in, stock_memo, stock_date) values"
				+ "(stock_seq.nextval, ?,?,?,?,?,?,?, " + date + ")";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, enter.getFabric_name());
			pstmt.setString(2, enter.getFabric_colour());
			pstmt.setInt(3, enter.getFabric_cost());
			pstmt.setString(4, enter.getFabric_material());
			pstmt.setDouble(5, enter.getStock());
			pstmt.setDouble(6, enter.getStock_in());
			pstmt.setString(7, enter.getStock_memo());

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("������");
				alert.setHeaderText("��� ���� ��Ͽ� �����߽��ϴ�.");
				alert.setContentText("������ �Ϸ�");
				alert.showAndWait();

				enterSuccess = true;
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("������");
				alert.setHeaderText("��� ���� ��Ͽ� �����߽��ϴ�.");
				alert.setContentText("�����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}

		return enterSuccess;
	}

	public StockVO callStockInfomation(int no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select fabric_name, fabric_colour, stock, stock_memo from stock where stock_no = ?";
		StockVO model = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				model = new StockVO();
				model.setFabric_name(rs.getString("fabric_name"));
				model.setFabric_colour(rs.getString("fabric_colour"));
				model.setStock(rs.getDouble("stock"));
				model.setStock_memo(rs.getString("stock_memo"));

			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("��ǰ ����");
				alert.setHeaderText("��ǰ�� ã�� ���� �����ϴ�.");
				alert.setContentText("�����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return model;
	}

	public boolean updateStockInformation(StockVO model) {
		boolean updateSuccess = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String date = "sysdate";
		String sql = "update stock set stock = ?, stock_out = stock_out + ?, stock_in = stock_in + ?, stock_holding = stock_holding + ?,"
				+ "stock_return = stock_return + ?, stock_sample = stock_sample + ?, stock_defective = stock_defective +?, stock_service = stock_service + ?,"
				+ "stock_memo = ?, stock_date = " + date + " where stock_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);

			pstmt.setDouble(1, model.getStock());
			pstmt.setDouble(2, model.getStock_out());
			pstmt.setDouble(3, model.getStock_in());
			pstmt.setDouble(4, model.getStock_holding());
			pstmt.setDouble(5, model.getStock_return());
			pstmt.setDouble(6, model.getStock_sample());
			pstmt.setDouble(7, model.getStock_defective());
			pstmt.setDouble(8, model.getStock_service());
			pstmt.setString(9, model.getStock_memo());
			pstmt.setInt(10, model.getStock_no());

			int i = pstmt.executeUpdate();

			if (i == 1) {
				updateSuccess = true;
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�������");
				alert.setHeaderText("������ſ� �����߽��ϴ�.");
				alert.setContentText("'������'��ư�� ������ �������� �Ϸ��Ͻʽÿ�.");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�������");
				alert.setHeaderText("��� �۽ſ� �����߽��ϴ�.");
				alert.setContentText("������� ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}

		return updateSuccess;
	}

	public StockVO callProductInformation(int no) {
		StockVO product = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select stock_no, fabric_name, fabric_cost, fabric_material, stock_memo"
				+ " from stock where stock_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				product = new StockVO();
				product.setStock_no(rs.getInt("stock_no"));
				product.setFabric_name(rs.getString("fabric_name"));
				product.setFabric_cost(rs.getInt("stock_cost"));
				product.setFabric_material(rs.getString("fabric_material"));
				product.setStock_memo(rs.getString("stock_memo"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					pstmt.close();
			} catch (Exception e) {
			}
		}
		return product;
	}

	public ObservableList<String> callColour(int no) {
		ObservableList<String> colour = FXCollections.observableArrayList();
		String strColour = "";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select fabric_colour from stock where stock_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				strColour = rs.getString("fabric_colour");
				colour.addAll(strColour);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return colour;
	}

	public int callStockNo(String productName, String productColour) {
		int stockNo = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select stock_no from stock where fabric_name = ? and fabric_colour = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, productName);
			pstmt.setString(2, productColour);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				stockNo = rs.getInt("stock_no");
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return stockNo;
	}

	public StockVO callStock(String productName, String productColour) {
		StockVO stock = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select stock, stock_in, stock_out, stock_holding, "
				+ "stock_return, stock_sample, stock_defective, stock_service, stock_memo "
				+ " from stock where fabric_name = ? and fabric_colour = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, productName);
			pstmt.setString(2, productColour);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				stock = new StockVO();
				stock.setStock(rs.getDouble("stock"));
				stock.setStock_in(rs.getDouble("stock_in"));
				stock.setStock_out(rs.getDouble("stock_out"));
				stock.setStock_holding(rs.getDouble("stock_holding"));
				stock.setStock_return(rs.getDouble("stock_return"));
				stock.setStock_sample(rs.getDouble("stock_sample"));
				stock.setStock_defective(rs.getDouble("stock_defective"));
				stock.setStock_service(rs.getDouble("stock_service"));
				stock.setStock_memo(rs.getString("stock_memo"));
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("��ǰ �˻�");
				alert.setHeaderText("�Է��� ǰ���� �÷��� �ش�Ǵ� ��ǰ�� �����ϴ�.");
				alert.setContentText("��ǰ ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return stock;
	}

	public boolean checkNameAndColour(String name, String colour) {
		boolean impassable = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select fabric_material, fabric_cost from stock where fabric_name = ? and fabric_colour = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, colour);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				impassable = true;
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return impassable;
	}

	public StockVO checkNameAndInformation(String name) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select distinct fabric_name, fabric_material, fabric_cost from stock where fabric_name = ?";
		String material;
		int cost;
		StockVO model = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				material = rs.getString("fabric_material");
				cost = rs.getInt("fabric_cost");

				model = new StockVO();
				model.setFabric_material(material);
				model.setFabric_cost(cost);
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return model;
	}

	public ObservableList<String> callColourBox(String name) {
		ObservableList<String> list = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select fabric_colour from stock where fabric_name = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				list.addAll(rs.getString("fabric_colour"));
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return list;
	}

	public ArrayList<String> getProductColoumnName() {
		ArrayList<String> productColumnName = new ArrayList<>();
		String sql = "select stock_no, fabric_name, fabric_colour, fabric_material, fabric_cost, "
				+ "stock, stock_memo from stock order by fabric_name,3";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();

			for (int i = 1; i < cols; i++) {
				productColumnName.add(rsmd.getColumnName(i));
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return productColumnName;
	}

	public ArrayList<StockVO> getProductInformation() {
		ArrayList<StockVO> information = new ArrayList<>();
		String sql = "select stock_no, fabric_name, fabric_colour, fabric_material, fabric_cost, "
				+ "stock, stock_memo from stock order by fabric_name,3";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		StockVO model = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				model = new StockVO();
				model.setStock_no(rs.getInt("stock_no"));
				model.setFabric_name(rs.getString("fabric_name"));
				model.setFabric_colour(rs.getString("fabric_colour"));
				model.setFabric_material(rs.getString("fabric_material"));
				model.setFabric_cost(rs.getInt("fabric_cost"));
				model.setStock(rs.getDouble("stock"));
				model.setStock_memo(rs.getString("stock_memo"));

				information.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return information;
	}

	public ObservableList<String> callMaterial() {
		ObservableList<String> materialList = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select distinct fabric_material from stock order by 1";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				materialList.addAll(rs.getString("fabric_material"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return materialList;
	}

	public ObservableList<String> callProductName() {
		ObservableList<String> productNameList = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select distinct fabric_name from stock order by 1";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				productNameList.addAll(rs.getString("fabric_name"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return productNameList;
	}

	public ArrayList<String> getStockViewColumnName() {
		ArrayList<String> stockViewColumnName = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from stock";
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i < cols; i++) {
				stockViewColumnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return stockViewColumnName;
	}

	public ArrayList<StockVO> getStockViewInformation() {
		ArrayList<StockVO> stockViewInformation = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from stock order by stock_no";
		StockVO model = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				model = new StockVO();
				model.setStock_no(rs.getInt("stock_no"));
				model.setFabric_name(rs.getString("fabric_name"));
				model.setFabric_colour(rs.getString("fabric_colour"));
				model.setFabric_cost(rs.getInt("fabric_cost"));
				model.setFabric_material(rs.getString("fabric_material"));
				model.setStock(rs.getDouble("stock"));
				model.setStock_out(rs.getDouble("stock_out"));
				model.setStock_in(rs.getDouble("stock_in"));
				model.setStock_holding(rs.getDouble("stock_holding"));
				model.setStock_return(rs.getDouble("stock_return"));
				model.setStock_sample(rs.getDouble("stock_sample"));
				model.setStock_defective(rs.getDouble("stock_defective"));
				model.setStock_service(rs.getDouble("stock_service"));
				model.setStock_memo(rs.getString("stock_memo"));
				model.setStock_date(rs.getString("stock_date"));

				stockViewInformation.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return stockViewInformation;
	}

	public StockVO callNameAndColourAndCost(int no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select fabric_name, fabric_colour, fabric_cost from stock where stock_no =?";
		StockVO model = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				model = new StockVO();
				model.setFabric_name(rs.getString("fabric_name"));
				model.setFabric_colour(rs.getString("fabric_colour"));
				model.setFabric_cost(rs.getInt("fabric_cost"));

			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return model;
	}

	public boolean deleteStockRecord(int no) {
		boolean deleteSuccess = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "delete from stock_record where stock_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			int i = pstmt.executeUpdate();

			if (i == 1) {
				deleteSuccess = true;
				deleteStock(no);
			}
			
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return deleteSuccess;
	}

	public void deleteStock(int no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "delete from stock where stock_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�������");
				alert.setHeaderText("��������� �����߽��ϴ�.");
				alert.setContentText("������� �Ϸ�");
				alert.showAndWait();

			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�������");
				alert.setHeaderText("��������� �����߽��ϴ�.");
				alert.setContentText("������� ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
	}
}
