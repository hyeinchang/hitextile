package model;

public class StockVO {
	private int stock_no;
	private String fabric_name;
	private String fabric_colour;
	private int fabric_cost;
	private String fabric_material;
	private double stock;
	private double stock_out;
	private double stock_in;
	private double stock_holding;
	private double stock_return;
	private double stock_sample;
	private double stock_defective;
	private double stock_service;
	private String stock_memo;
	private String stock_date;
	private double stock_loss;
	
	private String fabric_name2;
	private String fabric_name3;
	private String fabric_colour2;
	private String fabric_colour3;

	public String getFabric_name2() {
		return fabric_name2;
	}

	public void setFabric_name2(String fabric_name2) {
		this.fabric_name2 = fabric_name2;
	}

	public String getFabric_name3() {
		return fabric_name3;
	}

	public void setFabric_name3(String fabric_name3) {
		this.fabric_name3 = fabric_name3;
	}

	public String getFabric_colour2() {
		return fabric_colour2;
	}

	public void setFabric_colour2(String fabric_colour2) {
		this.fabric_colour2 = fabric_colour2;
	}

	public String getFabric_colour3() {
		return fabric_colour3;
	}

	public void setFabric_colour3(String fabric_colour3) {
		this.fabric_colour3 = fabric_colour3;
	}

	public double getStock_loss() {
		return stock_loss;
	}

	public void setStock_loss(double stock_loss) {
		this.stock_loss = stock_loss;
	}

	public StockVO() {
		super();
	}
	
	// ��ǰ ���
	public StockVO(String fabric_name, String fabric_colour, int fabric_cost, String fabric_material, double stock,
			double stock_in, String stock_memo) {
		super();
		this.fabric_name = fabric_name;
		this.fabric_colour = fabric_colour;
		this.fabric_cost = fabric_cost;
		this.fabric_material = fabric_material;
		this.stock = stock;
		this.stock_in = stock_in;
		this.stock_memo = stock_memo;
	}
	
	// ��� ���
	public StockVO(double stock, double stock_out, double stock_in, double stock_holding, double stock_return,
			double stock_sample, double stock_defective, double stock_service) {
		super();
		this.stock = stock;
		this.stock_out = stock_out;
		this.stock_in = stock_in;
		this.stock_holding = stock_holding;
		this.stock_return = stock_return;
		this.stock_sample = stock_sample;
		this.stock_defective = stock_defective;
		this.stock_service = stock_service;
	}
	
	public StockVO(String fabric_name, String fabric_colour, int fabric_cost, String fabric_material, double stock,
			double stock_out, double stock_in, double stock_holding, double stock_return, double stock_sample,
			double stock_defective, double stock_service, String stock_memo, String stock_date) {
		super();
		this.fabric_name = fabric_name;
		this.fabric_colour = fabric_colour;
		this.fabric_cost = fabric_cost;
		this.fabric_material = fabric_material;
		this.stock = stock;
		this.stock_out = stock_out;
		this.stock_in = stock_in;
		this.stock_holding = stock_holding;
		this.stock_return = stock_return;
		this.stock_sample = stock_sample;
		this.stock_defective = stock_defective;
		this.stock_service = stock_service;
		this.stock_memo = stock_memo;
		this.stock_date = stock_date;
	}

	public StockVO(String fabric_name, String fabric_colour, int fabric_cost, String fabric_material, double stock,
			double stock_out, double stock_in, double stock_holding, double stock_return, double stock_sample,
			double stock_defective, double stock_service, String stock_memo) {
		super();
		this.fabric_name = fabric_name;
		this.fabric_colour = fabric_colour;
		this.fabric_cost = fabric_cost;
		this.fabric_material = fabric_material;
		this.stock = stock;
		this.stock_out = stock_out;
		this.stock_in = stock_in;
		this.stock_holding = stock_holding;
		this.stock_return = stock_return;
		this.stock_sample = stock_sample;
		this.stock_defective = stock_defective;
		this.stock_service = stock_service;
		this.stock_memo = stock_memo;
	}

	public StockVO(int stock_no, String fabric_name, String fabric_colour, int fabric_cost, String fabric_material,
			double stock, double stock_out, double stock_in, double stock_holding, double stock_return,
			double stock_sample, double stock_defective, double stock_service, String stock_memo,
			String stock_date) {
		super();
		this.stock_no = stock_no;
		this.fabric_name = fabric_name;
		this.fabric_colour = fabric_colour;
		this.fabric_cost = fabric_cost;
		this.fabric_material = fabric_material;
		this.stock = stock;
		this.stock_out = stock_out;
		this.stock_in = stock_in;
		this.stock_holding = stock_holding;
		this.stock_return = stock_return;
		this.stock_sample = stock_sample;
		this.stock_defective = stock_defective;
		this.stock_service = stock_service;
		this.stock_memo = stock_memo;
		this.stock_date = stock_date;
	}

	public int getStock_no() {
		return stock_no;
	}

	public void setStock_no(int stock_no) {
		this.stock_no = stock_no;
	}

	public String getFabric_name() {
		return fabric_name;
	}

	public void setFabric_name(String fabric_name) {
		this.fabric_name = fabric_name;
	}

	public String getFabric_colour() {
		return fabric_colour;
	}

	public void setFabric_colour(String fabric_colour) {
		this.fabric_colour = fabric_colour;
	}

	public int getFabric_cost() {
		return fabric_cost;
	}

	public void setFabric_cost(int fabric_cost) {
		this.fabric_cost = fabric_cost;
	}

	public String getFabric_material() {
		return fabric_material;
	}

	public void setFabric_material(String fabric_material) {
		this.fabric_material = fabric_material;
	}

	public double getStock() {
		return stock;
	}

	public void setStock(double stock) {
		this.stock = stock;
	}

	public double getStock_out() {
		return stock_out;
	}

	public void setStock_out(double stock_out) {
		this.stock_out = stock_out;
	}

	public double getStock_in() {
		return stock_in;
	}

	public void setStock_in(double stock_in) {
		this.stock_in = stock_in;
	}

	public double getStock_holding() {
		return stock_holding;
	}

	public void setStock_holding(double stock_holding) {
		this.stock_holding = stock_holding;
	}

	public double getStock_return() {
		return stock_return;
	}

	public void setStock_return(double stock_return) {
		this.stock_return = stock_return;
	}

	public double getStock_sample() {
		return stock_sample;
	}

	public void setStock_sample(double stock_sample) {
		this.stock_sample = stock_sample;
	}

	public double getStock_defective() {
		return stock_defective;
	}

	public void setStock_defective(double stock_defective) {
		this.stock_defective = stock_defective;
	}

	public double getStock_service() {
		return stock_service;
	}

	public void setStock_service(double stock_service) {
		this.stock_service = stock_service;
	}

	public String getStock_memo() {
		return stock_memo;
	}

	public void setStock_memo(String stock_memo) {
		this.stock_memo = stock_memo;
	}

	public String getStock_date() {
		return stock_date;
	}

	public void setStock_date(String stock_date) {
		this.stock_date = stock_date;
	}
}
