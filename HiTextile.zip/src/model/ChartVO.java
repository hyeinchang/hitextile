package model;

public class ChartVO {
	private int January;
	private int Febuary;
	private int March;
	private int April;
	private int May;
	private int June;
	private int July;
	private int August;
	private int September;
	private int October;
	private int November;
	private int December;
	private String fabric_name;
	private double sum;
	
	public ChartVO() {
		super();
	}

	public String getFabric_name() {
		return fabric_name;
	}

	public void setFabric_name(String fabric_name) {
		this.fabric_name = fabric_name;
	}

	public double getSum() {
		return sum;
	}

	public void setSum(double sum) {
		this.sum = sum;
	}

	public int getJanuary() {
		return January;
	}

	public void setJanuary(int january) {
		January = january;
	}

	public int getFebuary() {
		return Febuary;
	}

	public void setFebuary(int febuary) {
		Febuary = febuary;
	}

	public int getMarch() {
		return March;
	}

	public void setMarch(int march) {
		March = march;
	}

	public int getApril() {
		return April;
	}

	public void setApril(int april) {
		April = april;
	}

	public int getMay() {
		return May;
	}

	public void setMay(int may) {
		May = may;
	}

	public int getJune() {
		return June;
	}

	public void setJune(int june) {
		June = june;
	}

	public int getJuly() {
		return July;
	}

	public void setJuly(int july) {
		July = july;
	}

	public int getAugust() {
		return August;
	}

	public void setAugust(int august) {
		August = august;
	}

	public int getSeptember() {
		return September;
	}

	public void setSeptember(int september) {
		September = september;
	}

	public int getOctober() {
		return October;
	}

	public void setOctober(int october) {
		October = october;
	}

	public int getNovember() {
		return November;
	}

	public void setNovember(int november) {
		November = november;
	}

	public int getDecember() {
		return December;
	}

	public void setDecember(int december) {
		December = december;
	}
}
