package model;

public class LogVO {
	private String id;
	private String department;
	private String log_date;
	
	public LogVO() {
		super();
	}

	public LogVO(String id, String department, String log_date) {
		super();
		this.id = id;
		this.department = department;
		this.log_date = log_date;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getLog_date() {
		return log_date;
	}

	public void setLog_date(String log_date) {
		this.log_date = log_date;
	}
}
