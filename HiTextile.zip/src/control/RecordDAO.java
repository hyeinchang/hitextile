package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.StockRecordVO;
import model.StockVO;

public class RecordDAO {
	public void recordStock(int no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "insert into record_stock select stock_no, stock, stock_out, stock_in, stock_holding, " +
				"stock_return, stock_sample, stock_defective, stock_service, stock_memo, stock_date from stock " +
				"where stock_no = ?";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			int i = pstmt.executeUpdate();
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
	}
	
	public int callNewStockNo() {
		int no = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select stock_no from stock order by stock_date desc";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				no = rs.getInt("stock_no");
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return no;
	}
	
	public void recordStockList(int no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = " insert into record_stock (stock_no, stock, stock_in, stock_out, stock_holding, "+
				"stock_return, stock_sample, stock_defective, stock_service, stock_memo, record_date) " +
				"select stock_no, stock as ���, stock_in as �԰�, stock_out as ���, stock_holding as Ȧ��, " +
				"stock_return as ��ǰ, stock_sample as ����, stock_defective as �ҷ�, stock_service as ����, stock_memo as �޸�, stock_date  " +
				"from stock where stock_no = (select stock_no1 from transaction where transaction_no= "+no+") or " +
				"stock_no = (select stock_no2 from transaction where transaction_no= "+no+") or " +
				"stock_no = (select stock_no3 from transaction where transaction_no= "+no+")";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			int i = pstmt.executeUpdate();
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
	}
	
	public StockRecordVO callNewStockInformation() {
		StockRecordVO stock = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
	
		String sql = "select stock_no, stock as ���, stock_in as �԰�, stock_out as ���, stock_holding as Ȧ��, "
				+ "stock_return as ��ǰ, stock_sample as ����, stock_defective as �ҷ�, stock_service as ����, stock_memo as �޸�  " + 
				"from record_stock order by stock_date desc";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				stock = new StockRecordVO();
				stock.setStock_no(rs.getInt("stock_no"));
				stock.set���(rs.getDouble("���"));
				stock.set�԰�(rs.getDouble("�԰�"));
				stock.set���(rs.getDouble("���"));
				stock.setȦ��(rs.getDouble("Ȧ��"));
				stock.set��ǰ(rs.getDouble("��ǰ"));
				stock.set����(rs.getDouble("����"));
				stock.set�ҷ�(rs.getDouble("�ҷ�"));
				stock.set����(rs.getDouble("����"));
				stock.set�޸�(rs.getString("�޸�"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return stock;
	}
	
	public ArrayList<String> getStockRecordColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		String sql = "select record_date, stock as ���, stock_in as �԰�, stock_out as ���, stock_holding as Ȧ��, "
				+ "stock_return as ��ǰ, stock_sample as ����, stock_defective as �ҷ�, stock_service as ����, stock_memo as �޸�  " + 
				"from record_stock";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			
			for (int i = 1; i < cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return columnName;
	}
	
	public ArrayList<StockRecordVO> getStockRecordList(){
		ArrayList<StockRecordVO> list = new ArrayList<>();
		StockRecordVO model = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select record_date, stock as ���, stock_in as �԰�, stock_out as ���, stock_holding as Ȧ��, "
				+ "stock_return as ��ǰ, stock_sample as ����, stock_defective as �ҷ�, stock_service as ����, stock_memo as �޸�  " + 
				"from record_stock order by 1 desc";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new StockRecordVO();
				model.setRecord_date(rs.getString("record_date"));
				model.set���(rs.getDouble("���"));
				model.set�԰�(rs.getDouble("�԰�"));
				model.set���(rs.getDouble("���"));
				model.setȦ��(rs.getDouble("Ȧ��"));
				model.set��ǰ(rs.getDouble("��ǰ"));
				model.set����(rs.getDouble("����"));
				model.set�ҷ�(rs.getDouble("�ҷ�"));
				model.set����(rs.getDouble("����"));
				model.set�޸�(rs.getString("�޸�"));
				
				list.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return list;
	}
	
	public ObservableList<StockRecordVO> getProductRecordList(int no){
		ObservableList<StockRecordVO> list = FXCollections.observableArrayList();
		StockRecordVO model = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select record_date, stock as ���, stock_in as �԰�, stock_out as ���, stock_holding as Ȧ��, "
				+ "stock_return as ��ǰ, stock_sample as ����, stock_defective as �ҷ�, stock_service as ����, stock_memo as �޸�  " + 
				"from record_stock where stock_no = ? order by 1 desc";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				model = new StockRecordVO();
				model.setRecord_date(rs.getString("record_date"));
				model.set���(rs.getDouble("���"));
				model.set�԰�(rs.getDouble("�԰�"));
				model.set���(rs.getDouble("���"));
				model.setȦ��(rs.getDouble("Ȧ��"));
				model.set��ǰ(rs.getDouble("��ǰ"));
				model.set����(rs.getDouble("����"));
				model.set�ҷ�(rs.getDouble("�ҷ�"));
				model.set����(rs.getDouble("����"));
				model.set�޸�(rs.getString("�޸�"));
				
				list.addAll(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return list;
	}
	
	public void insertNo(int no){
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "insert into record_no values(?,sysdate)";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			int i = pstmt.executeUpdate();
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
	}
	
	public void clearNo(){
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "delete from record_no";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			int i = pstmt.executeUpdate();
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
	}
	
	public ObservableList<Integer> getNo(){
		ObservableList<Integer> noList = FXCollections.observableArrayList();
		int no = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from record_no order by 2 desc";
		
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				no = rs.getInt("stock_no");
				noList.add(no);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return noList;
	}
}
