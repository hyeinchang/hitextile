package control;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.animation.FadeTransitionBuilder;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.CustomerVO;
import model.SearchVO;
import model.StockVO;
import model.TransactionVO;

public class MainShopController implements Initializable {
	@FXML
	private Button btnStockView;
	@FXML
	private TextField txtCustomerName;
	@FXML
	private Button btnCustomerSearch;
	@FXML
	private Button btnCustomerRegistration;
	@FXML
	private TextField txtProduct1;
	@FXML
	private Button btnProduct1;
	@FXML
	private TextField txtCost1;
	@FXML
	private ComboBox<String> cbColour1;
	@FXML
	private TextField txtYard1;
	@FXML
	private TextField txtProduct2;
	@FXML
	private Button btnProduct2;
	@FXML
	private TextField txtCost2;
	@FXML
	private ComboBox<String> cbColour2;
	@FXML
	private TextField txtYard2;
	@FXML
	private TextField txtProduct3;
	@FXML
	private Button btnProduct3;
	@FXML
	private TextField txtCost3;
	@FXML
	private ComboBox<String> cbColour3;
	@FXML
	private TextField txtYard3;
	@FXML
	private TextField txtDiscount;
	@FXML
	private Button btnCal;
	@FXML
	private TextField txtPrice;
	@FXML
	private TextField txtContact1;
	@FXML
	private TextField txtContact2;
	@FXML
	private TextField txtAddress;
	@FXML
	private RadioButton rbBeforePayment;
	@FXML
	private RadioButton rbAfterPayment;
	@FXML
	private RadioButton rbStock;
	@FXML
	private RadioButton rbHolding;
	@FXML
	private RadioButton rbComplete;
	@FXML
	private TextField txtMemo;
	@FXML
	private Button btnOk;
	@FXML
	private Button btnClear;
	@FXML
	private Button btnSave;
	@FXML
	private TableView<TransactionVO> transactionTable;
	@FXML
	private TextField txtSearchCustomer;
	@FXML
	private TextField txtSearchFabric;
	@FXML
	private ToggleGroup paymentGroup;
	@FXML
	private ComboBox<String> cbSearchPayment;
	@FXML
	private ToggleGroup deliveryGroup;
	@FXML
	private ComboBox<String> cbSearchDelivery;
	@FXML
	private DatePicker dpSearch;
	@FXML
	private TextField txtSearchTransaction_no;
	@FXML
	private ComboBox<String> cbSearchColour;
	@FXML
	private TextField txtSearchPrice;
	@FXML
	private TextField txtSearchMemo;
	@FXML
	private Button btnConditionSearch;
	@FXML
	private Button btnCustomerList;
	@FXML
	private Button btnSaveList;
	@FXML
	private Button btnLogin;
	@FXML
	private Button btnDepartment;
	@FXML
	private Button btnChart;
	@FXML
	private TextField txtMemberNo;

	ObservableList<TransactionVO> transaction = FXCollections.observableArrayList();
	int transactionNo = 0;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		MemberDAO dao = new MemberDAO();
		ObservableList<String> log = FXCollections.observableArrayList();
		log = dao.callLoginShopMemberId();
		String memberId = log.get(0);
		System.out.println(log);
		int memberNo = dao.callMemberNo(memberId);
		txtMemberNo.setText(memberNo + "");
		txtMemberNo.setEditable(false);

		transactionTable.setEditable(false);
		TableColumn colTransaction_no = new TableColumn("�ŷ�no");
		colTransaction_no.setMaxWidth(67);
		colTransaction_no.setMinWidth(67);
		colTransaction_no.setStyle("-fx-alignment:CENTER");
		colTransaction_no.setCellValueFactory(new PropertyValueFactory<>("transaction_no"));
		TableColumn colCustomerName = new TableColumn("�ŷ�ó");
		colCustomerName.setMaxWidth(80);
		colCustomerName.setMinWidth(80);
		colCustomerName.setStyle("-fx-alignment:CENTER");
		colCustomerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
		TableColumn colOrderList = new TableColumn("�ֹ���ǰ");
		colOrderList.setMaxWidth(250);
		colOrderList.setMinWidth(250);
		colOrderList.setCellValueFactory(new PropertyValueFactory<>("orderList"));
		TableColumn colPayment = new TableColumn("�����ݾ�");
		colPayment.setMaxWidth(80);
		colPayment.setMinWidth(80);
		colPayment.setStyle("-fx-alignment:CENTER");
		colPayment.setCellValueFactory(new PropertyValueFactory<>("payment"));
		TableColumn colAddress = new TableColumn("�����");
		colAddress.setMaxWidth(121);
		colAddress.setMinWidth(121);
		colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
		TableColumn colCheck_payment = new TableColumn("��������");
		colCheck_payment.setMaxWidth(60);
		colCheck_payment.setMinWidth(60);
		colCheck_payment.setStyle("-fx-alignment:CENTER");
		colCheck_payment.setCellValueFactory(new PropertyValueFactory<>("check_payment"));
		TableColumn colCheck_delivery = new TableColumn("��ۿ���");
		colCheck_delivery.setMaxWidth(60);
		colCheck_delivery.setMinWidth(60);
		colCheck_delivery.setStyle("-fx-alignment:CENTER");
		colCheck_delivery.setCellValueFactory(new PropertyValueFactory<>("check_delivery"));
		TableColumn colMemo = new TableColumn("�޸�");
		colMemo.setMaxWidth(100);
		colMemo.setMinWidth(100);
		colMemo.setCellValueFactory(new PropertyValueFactory<>("memo"));
		TableColumn colTransaction_date = new TableColumn("�����");
		colTransaction_date.setMaxWidth(100);
		colTransaction_date.setMinWidth(100);
		colTransaction_date.setCellValueFactory(new PropertyValueFactory<>("transaction_date"));
		transactionTable.setItems(transaction);
		transactionTable.getColumns().addAll(colTransaction_no, colCustomerName, colOrderList, colPayment, colAddress,
				colCheck_payment, colCheck_delivery, colMemo, colTransaction_date);
		transactionList();

		cbSearchColour.setItems(FXCollections.observableArrayList("ȭ��Ʈ", "������", "��ũ", "����", "����"));
		cbSearchPayment.setItems(FXCollections.observableArrayList("û��", "����"));
		cbSearchDelivery.setItems(FXCollections.observableArrayList("���", "Ȧ��", "�Ϸ�"));
		// �ݾ��� ��ǰ���� �ҷ������� ���ٲٰ� ����
		txtCost1.setEditable(false);
		txtCost2.setEditable(false);
		txtCost3.setEditable(false);
		txtPrice.setEditable(false);

		// �ݾ� ��갪 �ʱ�ȭ
		txtCost1.setText("0");
		txtCost2.setText("0");
		txtCost3.setText("0");
		txtYard1.setText("0");
		txtYard2.setText("0");
		txtYard3.setText("0");
		txtDiscount.setText("0");

		cbColour1.setItems(FXCollections.observableArrayList(""));
		cbColour2.setItems(FXCollections.observableArrayList(""));
		cbColour3.setItems(FXCollections.observableArrayList(""));
		cbColour1.getSelectionModel().select(0);
		cbColour2.getSelectionModel().select(0);
		cbColour3.getSelectionModel().select(0);
		txtContact2.setText(" ");
		txtAddress.setText(" ");
		txtMemo.setText(" ");

		// �ݾ� ����ư(����/����)
		btnCal.setOnAction(event -> handlerBtnCalculateConditionAction(event));
		btnCal.setOnAction(event -> handlerBtnCalculateAction(event));

		btnOk.setDisable(true);
		btnProduct1.setDisable(true);
		btnProduct2.setDisable(true);
		btnProduct3.setDisable(true);
		btnCal.setDisable(true);

		btnLogin.setOnAction(event -> handlerBtnLoginAction(event));
		btnDepartment.setOnAction(event -> handlerBtnDepartmentAction(event));
		btnChart.setOnAction(event -> handlerBtnChartAction(event));

		btnOk.setOnAction(event -> handlerBtnOkAction(event));

		btnClear.setOnAction(event -> handlerBtnClearAction(event));
		btnCustomerRegistration.setOnAction(event -> handlerBtnCustomerRegistrationAction(event));
		btnCustomerSearch.setOnAction(event -> handlerBtnCustomerSearchAction(event));
		btnCustomerList.setOnAction(event -> handlerBtnCustomerListAction(event));
		btnProduct1.setOnAction(event -> handlerBtnProduct1Action(event));
		btnProduct2.setOnAction(event -> handlerBtnProduct2Action(event));
		btnProduct3.setOnAction(event -> handlerBtnProduct3Action(event));
		btnStockView.setOnAction(event -> handlerBtnStockViewAction(event));
		transactionTable.setOnMouseClicked(event -> handlerEditTransactionInformationAction(event));
		btnSave.setOnAction(event -> handlerBtnUpdateAction(event));
		btnConditionSearch.setOnAction(event -> handlerBtnConditionSearchAction(event));
		btnSaveList.setOnAction(event -> handlerBtnSaveListAction(event));
	}

	public void handlerBtnSaveListAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/file_save2.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setScene(scene);
			mainMtage.setTitle("���� Ȯ���� ����");
			mainMtage.setResizable(false);
			mainMtage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnUpdateAction(ActionEvent event) {
		TransactionDAO dao = new TransactionDAO();
		transaction = dao.renewShopMainTransactionList();
		transactionTable.setItems(transaction);
	}

	public void handlerEditTransactionInformationAction(MouseEvent event) {
		TransactionDAO dao = null;
		try {
			dao = new TransactionDAO();
			transactionNo = transactionTable.getSelectionModel().getSelectedItem().getTransaction_no();
			dao.saveTransactionNo(transactionNo);
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/receipt.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setScene(scene);
			mainMtage.setResizable(false);
			mainMtage.setTitle("������");
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnConditionSearchAction(ActionEvent event) {
		SearchDAO searchDao = null;
		SearchVO search = null;

		int transaction_no = 0;
		String customer_name = "";
		String fabric_name = "";
		String fabric_colour = "";
		int payment = 0;
		String check_payment = "";
		String check_delivery = "";
		String memo = "";
		String transaction_date = "";
		String colour_abb = "";
		ObservableList<TransactionVO> list = FXCollections.observableArrayList();
		try {
			searchDao = new SearchDAO();
			search = new SearchVO();
			SearchVO search2 = new SearchVO();
			SearchVO search3 = new SearchVO();
			transaction_no = Integer.parseInt(search2.nullToValue3(txtSearchTransaction_no.getText().trim()));
			customer_name = search2.nullToValue(txtSearchCustomer.getText().trim());
			fabric_name = search2.nullToValue(txtSearchFabric.getText().trim());
			payment = Integer.parseInt(search2.nullToValue3(txtSearchPrice.getText().trim()));
			check_payment = search2.nullToValue2(cbSearchPayment.getSelectionModel().getSelectedItem());
			check_delivery = search2.nullToValue2(cbSearchDelivery.getSelectionModel().getSelectedItem());
			memo = search2.nullToValue(txtSearchMemo.getText().trim());
			transaction_date = search2.nullToValue(dpSearch.getValue() + "");
			colour_abb = search3.colourNameChange(cbSearchColour.getSelectionModel().getSelectedItem());
			String order = "x";

			if (fabric_name.equals(" ") && !colour_abb.equals(" ")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ����� �˻�");
				alert.setHeaderText("���ܸ��� �Է��Ͻʽÿ�");
				alert.setContentText("���ܸ� �Է� �� ����");
				alert.showAndWait();
				txtSearchFabric.requestFocus();
			} else if (!fabric_name.equals(" ") && colour_abb.equals(" ")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ����� �˻�");
				alert.setHeaderText("�÷��� �����Ͻʽÿ�");
				alert.setContentText("���ܸ� ���� �� ����");
				alert.showAndWait();
				txtSearchFabric.requestFocus();
			} else if (transaction_no != 0) {
				search.setTransaction_no(transaction_no);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
				return;
			} else if (!customer_name.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
		
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (payment != 0) {
				search.setPayment(payment);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_payment.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_delivery.equals(" ")) {
				search.setCheck_delivery(check_delivery);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memo.equals(" ")) {
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!transaction_date.equals(" ")) {
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && (payment != 0)) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ")
					&& !check_delivery.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ")
					&& !check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (transaction_no != 0 && !customer_name.equals(" ") && !fabric_name.equals(" ")
					&& !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ")
					&& !check_delivery.equals(" ") && !memo.equals(" ") && !transaction_date.equals(" ")) {
				search.setTransaction_no(transaction_no);
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ")
					&& payment != 0) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ") && !check_delivery.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")
					&& !transaction_date.equals(" ")) {
				search.setCustomer_name(customer_name);
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ")
					&& !check_delivery.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0 && !check_payment.equals(" ")
					&& !check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!customer_name.equals(" ") && !fabric_name.equals(" ") && !colour_abb.equals(" ") && payment != 0
					&& !check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")
					&& !transaction_date.equals(" ")) {
				search.setOrderList(fabric_name + "/" + colour_abb);
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (payment != 0 && !check_payment.equals(" ")) {
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (payment != 0 && !check_payment.equals(" ") && !check_delivery.equals(" ")) {
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (payment != 0 && !check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (payment != 0 && !check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")
					&& !transaction_date.equals(" ")) {
				search.setPayment(payment);
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_payment.equals(" ") && !check_delivery.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (check_payment.equals(" ") && !check_delivery.equals(" ") && !memo.equals(" ")
					&& !transaction_date.equals(" ")) {
				search.setCheck_payment(check_payment);
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_delivery.equals(" ") && !memo.equals(" ")) {
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!check_delivery.equals(" ") && !memo.equals(" ") && !transaction_date.equals(" ")) {
				search.setCheck_delivery(check_delivery);
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else if (!memo.equals(" ") && !transaction_date.equals(" ")) {
				search.setMemo(memo);
				search.setTransaction_date(transaction_date);
				search.setOrderList(order);
				list = searchDao.searchShopMainTransactionTableOne(search);
				transactionTable.setItems(list);
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ����� �˻�");
				alert.setHeaderText("�˻��� ���� �Է��Ͻʽÿ�.");
				alert.setContentText("���Է�");
				alert.showAndWait();
			}

		} catch (Exception e) {
			e.printStackTrace();
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�ŷ����� �˻�");
			alert.setHeaderText("�Է��� ���� Ȯ���Ͻʽÿ�.");
			alert.setContentText("���Է�");
			alert.showAndWait();
		}
	}

	public void transactionList() {
		Object[][] transactionData;
		TransactionDAO dao = new TransactionDAO();
		TransactionVO model = null;
		ArrayList<String> title;
		ArrayList<TransactionVO> list;

		title = dao.getShopMainTransactionColumnName();
		int columnCount = title.size();
		list = dao.getShopMainTransactionInformation();
		int rowCount = list.size();
		transactionData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			model = list.get(index);
			transaction.add(model);
		}
	}

	public void handlerBtnStockViewAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/stock_view.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("��� ����Ʈ");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnProduct3Action(ActionEvent event) {
		String product3 = "";
		int cost3 = 0;
		ObservableList<String> setColour = FXCollections.observableArrayList();
		StockDAO dao = null;
		StockVO model = null;

		try {
			if (event.getSource().equals(btnProduct3)) {
				product3 = txtProduct3.getText().trim();
				dao = new StockDAO();

				if (product3.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��3 �˻�");
					alert.setHeaderText("ǰ��3�� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("ǰ��3 �Է� �� ����");
					alert.showAndWait();
					txtProduct3.requestFocus();
				} else if (dao.checkNameAndInformation(product3) == null) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��3 �˻�");
					alert.setHeaderText("�Էµ� ǰ��3�� �ش�Ǵ� ��ǰ�� �����ϴ�.");
					alert.setContentText("ǰ��3 �Է� �� Ȯ��");
					alert.showAndWait();
					txtProduct3.requestFocus();
				} else {
					model = new StockVO();

					model = dao.checkNameAndInformation(product3);
					cost3 = model.getFabric_cost();
					setColour = dao.callColourBox(product3);
					txtCost3.setText(cost3 + "");
					cbColour3.setItems(setColour);
					cbColour3.setPromptText("����");

					// �ŷ�ó�� ��ǰ���� �˻����� �ҷ������� ���ٲٰ� ����
					txtProduct3.setEditable(false);
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnProduct2Action(ActionEvent event) {
		String product2 = "";
		int cost2 = 0;
		ObservableList<String> setColour = FXCollections.observableArrayList();
		StockDAO dao = null;
		StockVO model = null;

		try {
			if (event.getSource().equals(btnProduct2)) {
				product2 = txtProduct2.getText().trim();
				dao = new StockDAO();

				if (product2.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��2 �˻�");
					alert.setHeaderText("ǰ��2�� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("ǰ��2 �Է� �� ����");
					alert.showAndWait();
					txtProduct2.requestFocus();
				} else if (dao.checkNameAndInformation(product2) == null) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��2 �˻�");
					alert.setHeaderText("�Էµ� ǰ��2�� �ش�Ǵ� ��ǰ�� �����ϴ�.");
					alert.setContentText("ǰ��2 �Է� �� Ȯ��");
					alert.showAndWait();
					txtProduct2.requestFocus();
				} else {
					model = new StockVO();

					model = dao.checkNameAndInformation(product2);
					cost2 = model.getFabric_cost();
					setColour = dao.callColourBox(product2);
					txtCost2.setText(cost2 + "");
					cbColour2.setItems(setColour);
					cbColour2.setPromptText("����");

					txtProduct3.setEditable(true);
					btnProduct3.setDisable(false);

					// �ŷ�ó�� ��ǰ���� �˻����� �ҷ������� ���ٲٰ� ����
					txtProduct2.setEditable(false);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnProduct1Action(ActionEvent event) {
		String product1 = "";
		int cost1 = 0;
		ObservableList<String> setColour = FXCollections.observableArrayList();
		StockDAO dao = null;
		StockVO model = null;

		try {
			if (event.getSource().equals(btnProduct1)) {
				product1 = txtProduct1.getText().trim();
				dao = new StockDAO();

				if (product1.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��1 �˻�");
					alert.setHeaderText("ǰ��1�� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("ǰ��1 �Է� �� ����");
					alert.showAndWait();
					txtProduct1.requestFocus();
				} else if (dao.checkNameAndInformation(product1) == null) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��1 �˻�");
					alert.setHeaderText("�Էµ� ǰ��1�� �ش�Ǵ� ��ǰ�� �����ϴ�.");
					alert.setContentText("ǰ��1 �Է� �� Ȯ��");
					alert.showAndWait();
					txtProduct1.requestFocus();
				} else {
					model = new StockVO();

					model = dao.checkNameAndInformation(product1);
					cost1 = model.getFabric_cost();
					setColour = dao.callColourBox(product1);
					txtCost1.setText(cost1 + "");
					cbColour1.setItems(setColour);
					cbColour1.setPromptText("����");

					txtProduct2.setEditable(true);
					btnProduct2.setDisable(false);
					btnCal.setDisable(false);

					// �ŷ�ó�� ��ǰ���� �˻����� �ҷ������� ���ٲٰ� ����
					txtProduct1.setEditable(false);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnCustomerListAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/customer_list.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�ŷ�ó���");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnCustomerSearchAction(ActionEvent event) {
		String searchName = "";
		CustomerDAO dao = null;
		CustomerVO result = null;

		try {
			dao = new CustomerDAO();
			result = new CustomerVO();
			searchName = txtCustomerName.getText().trim();
			result = dao.mainSearchCustomerName(searchName);

			if (searchName.equals("")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ�ó��ȸ");
				alert.setHeaderText("�ŷ�ó �̸��� �Է��Ͻʽÿ�.");
				alert.setContentText("�ŷ�ó �̸� �Է� �� ����");
				alert.showAndWait();
			} else if (result == null) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ�ó��ȸ");
				alert.setHeaderText("�˻��� �ŷ�ó ������ �����ϴ�.");
				alert.setContentText("�ŷ�ó�̸� Ȯ��");
				alert.showAndWait();
			} else {
				txtCustomerName.setText(result.getCustomer_name());
				txtContact1.setText(result.getContact1());
				txtContact2.setText(result.getContact2());

				btnProduct1.setDisable(false);

				// �ŷ�ó�� ��ǰ���� �˻����� �ҷ������� ���ٲٰ� ����
				txtCustomerName.setEditable(false);
			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�ŷ�ó�� �˻�");
			alert.setHeaderText("�˻��� �ŷ�ó���� �Է��Ͻʽÿ�.");
			alert.setContentText("�ŷ�ó�� �Է� �� ����");
			alert.showAndWait();

			txtCustomerName.requestFocus();
		}
	}

	public void handlerBtnCustomerRegistrationAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/customer_registration.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�ŷ�ó ���");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnSaveAction(ActionEvent event) {
		TransactionDAO dao = new TransactionDAO();
		transaction = dao.renewShopMainTransactionList();
		transactionTable.setItems(transaction);
	}

	public void handlerBtnClearAction(ActionEvent event) {
		txtCustomerName.clear();
		txtDiscount.setText("0");
		txtPrice.clear();
		txtContact1.clear();
		cbColour1.getSelectionModel().clearSelection();
		cbColour2.getSelectionModel().clearSelection();
		cbColour3.getSelectionModel().clearSelection();
		cbColour1.setPromptText("");
		cbColour2.setPromptText("");
		cbColour3.setPromptText("");
		paymentGroup.selectToggle(null);
		deliveryGroup.selectToggle(null);

		// �ݾ��� ��ǰ���� �ҷ������� ���ٲٰ� ����
		txtCost1.setEditable(false);
		txtCost2.setEditable(false);
		txtCost3.setEditable(false);
		txtPrice.setEditable(false);

		// �ݾ� ��갪 �ʱ�ȭ
		txtCost1.setText("0");
		txtCost2.setText("0");
		txtCost3.setText("0");
		txtYard1.setText("0");
		txtYard2.setText("0");
		txtYard3.setText("0");
		txtDiscount.setText("0");

		cbColour1.setItems(FXCollections.observableArrayList(""));
		cbColour2.setItems(FXCollections.observableArrayList(""));
		cbColour3.setItems(FXCollections.observableArrayList(""));
		cbColour1.getSelectionModel().select(0);
		cbColour2.getSelectionModel().select(0);
		cbColour3.getSelectionModel().select(0);
		txtContact2.setText(" ");
		txtAddress.setText(" ");
		txtMemo.setText(" ");
		txtProduct1.clear();
		txtProduct2.clear();
		txtProduct3.clear();

		btnOk.setDisable(true);
		btnProduct1.setDisable(true);
		btnProduct2.setDisable(true);
		btnProduct3.setDisable(true);
		btnCal.setDisable(true);

		txtCustomerName.setEditable(true);
		txtProduct1.setEditable(true);
	}

	public boolean handlerBtnOkAction(ActionEvent event) {
		boolean enter1 = false;
		TransactionDAO dao = null;
		TransactionVO model = null;
		int memberNo = 0;
		String customer = "";
		String product1 = "";
		String colour1 = "";
		double yard1 = 0;
		String product2 = "";
		String colour2 = "";
		double yard2 = 0;
		String product3 = "";
		String colour3 = "";
		double yard3 = 0;
		int discount = 0;
		int price = 0;
		String address = "";
		String check_payment = "";
		String check_delivery = "";
		String memo = "";
		String orderList = "";

		try {
			if (event.getSource().equals(btnOk)) {
				product1 = txtProduct1.getText();
				check_payment = paymentGroup.getSelectedToggle().getUserData().toString();
				check_delivery = deliveryGroup.getSelectedToggle().getUserData().toString();

				if (product1.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�ŷ����");
					alert.setHeaderText("ù��° ǰ���� �Է��ؾ��մϴ�.");
					alert.setContentText("ù��° ǰ�� �Է� �� ����");
					alert.showAndWait();

					txtProduct1.requestFocus();
				} else if (check_payment.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�ŷ����");
					alert.setHeaderText("�������θ� �����Ͻʽÿ�.");
					alert.setContentText("�������� �Է� �� ����");
					alert.showAndWait();

					rbBeforePayment.requestFocus();
				} else if (check_delivery.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�ŷ����");
					alert.setHeaderText("��ۿ��θ� �����Ͻʽÿ�.");
					alert.setContentText("��ۿ��� �Է� �� ����");
					alert.showAndWait();

					rbStock.requestFocus();
				} else {
					dao = new TransactionDAO();
					model = new TransactionVO();

					customer = txtCustomerName.getText();
					memberNo = Integer.parseInt(txtMemberNo.getText());

					product1 = txtProduct1.getText();
					colour1 = cbColour1.getSelectionModel().getSelectedItem();
					yard1 = Double.parseDouble(txtYard1.getText().trim());
					product2 = txtProduct2.getText();
					colour2 = cbColour2.getSelectionModel().getSelectedItem();
					yard2 = Double.parseDouble(txtYard2.getText().trim());
					product3 = txtProduct3.getText();
					colour3 = cbColour3.getSelectionModel().getSelectedItem();
					yard3 = Double.parseDouble(txtYard3.getText().trim());
					discount = Integer.parseInt(txtDiscount.getText().trim());
					price = Integer.parseInt(txtPrice.getText());
					address = txtAddress.getText();
					check_delivery = deliveryGroup.getSelectedToggle().getUserData().toString();
					check_payment = paymentGroup.getSelectedToggle().getUserData().toString();
					memo = txtMemo.getText();

					int customerNo = dao.callCustomerNo(customer);
					model.setCustomer_no(customerNo);
					model.setMember_no(memberNo);
					model.setStock_no1(0);
					model.setStock_no2(0);
					model.setStock_no3(0);
					model.setYard1(yard1);
					model.setYard2(yard2);
					model.setYard3(yard3);
					model.setDiscount(discount);
					model.setPayment(price);
					model.setAddress(address);
					model.setCheck_payment(check_payment);
					model.setCheck_delivery(check_delivery);
					model.setMemo(memo);

					String abb1 = model.colourNameChange(colour1);
					String abb2 = model.colourNameChange(colour2);
					String abb3 = model.colourNameChange(colour3);

					orderList = product1 + "/" + abb1 + "/" + yard1 + " " + product2 + "/" + abb2 + "/" + yard2 + " "
							+ product3 + "/" + abb3 + "/" + yard3;
					model.setOrderList(orderList);

					model.setStock_no1(nullToValue(product1, colour1));
					model.setStock_no2(nullToValue(product2, colour2));
					model.setStock_no3(nullToValue(product3, colour3));

					enter1 = dao.enterTransactionInfromation(model);

					if (enter1) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("�ŷ����");
						alert.setHeaderText("'������Ʈ'��ư�� ������ �ŷ������ �����Ͻʽÿ�.");
						alert.setContentText("�ŷ���� �Ϸ�");
						alert.showAndWait();

						btnSave.requestFocus();
						handlerBtnClearAction(event);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return enter1;
	}

	public int nullToValue(String name, String colour) {
		int stockNo = 0;
		TransactionDAO dao = new TransactionDAO();

		if (name.equals("") && colour.equals("")) {
			stockNo = 0;
		} else {
			stockNo = dao.returnStockNo(name, colour);
		}
		return stockNo;
	}

	public void handlerBtnChartAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/chart_choice.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("��Ʈ����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnDepartmentAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/department.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�μ�����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnLogin.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnLoginAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/login_shop.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("���� �α���");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnLogin.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean handlerBtnCalculateConditionAction(ActionEvent event) {
		boolean condition = false;
		int cost1 = 0;
		int cost2 = 0;
		int cost3 = 0;
		double yard1 = 0.0;
		double yard2 = 0.0;
		double yard3 = 0.0;
		double discount = 0.0; // ���η��� 0 % ~ 20 %

		try {
			cost1 = Integer.parseInt(txtCost1.getText().trim());
			cost2 = Integer.parseInt(txtCost2.getText().trim());
			cost3 = Integer.parseInt(txtCost3.getText().trim());
			yard1 = Double.parseDouble(txtYard1.getText().trim());
			yard2 = Double.parseDouble(txtYard2.getText().trim());
			yard3 = Double.parseDouble(txtYard3.getText().trim());

			discount = Double.parseDouble(txtDiscount.getText().trim()) / 100;

			if (cost1 != 0 && yard1 == 0) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �� �Է�");
				alert.setHeaderText("ǰ��1�� �ߵ���� �Է��Ͻʽÿ�.");
				alert.setContentText("ǰ��1�� ���� �� ����");
				alert.showAndWait();
			} else if (cost2 != 0 && yard2 == 2) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �� �Է�");
				alert.setHeaderText("ǰ��2�� �ߵ���� �Է��Ͻʽÿ�.");
				alert.setContentText("ǰ��2�� ���� �� ����");
				alert.showAndWait();
			} else if (cost3 != 0 && yard3 == 2) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �� �Է�");
				alert.setHeaderText("ǰ��3�� �ߵ���� �Է��Ͻʽÿ�.");
				alert.setContentText("ǰ��3�� ���� �� ����");
				alert.showAndWait();
			}

			if (yard1 < 0 || yard2 < 0 || yard3 < 0) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ߵ�� �Է� ����");
				alert.setHeaderText("�ߵ���� ���� ������ �Է��Ͻʽÿ�.");
				alert.setContentText("�ߵ�� ���Է�");
				alert.showAndWait();
			} else if (discount < 0 || 20 < discount) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���η� �Է� ����");
				alert.setHeaderText("�������� 0% �̻� 20% �̸��� ������ �Է��Ͻʽÿ�.");
				alert.setContentText("������ ���Է�");
				alert.showAndWait();
				txtDiscount.requestFocus();
			} else {
				condition = true;
			}
		} catch (NumberFormatException e) {
			System.out.println(e);
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� �Է� ����");
			alert.setHeaderText("���ڸ� ��Ȯ�� �Է��Ͻʽÿ�.");
			alert.setContentText("���Է�");
			alert.showAndWait();
		}

		return condition;
	}

	public void handlerBtnCalculateAction(ActionEvent event) {
		boolean condition = handlerBtnCalculateConditionAction(event);
		int cost1 = 0;
		int cost2 = 0;
		int cost3 = 0;
		double yard1 = 0.0;
		double yard2 = 0.0;
		double yard3 = 0.0;
		double discount = 0.0; // ���η��� 0 % ~ 20 %
		double excludeVat = 0;
		int vat = 0;
		int price = 0;

		try {
			if (condition && event.getSource().equals(btnCal)) {
				cost1 = Integer.parseInt(txtCost1.getText().trim());
				cost2 = Integer.parseInt(txtCost2.getText().trim());
				cost3 = Integer.parseInt(txtCost3.getText().trim());

				yard1 = Double.parseDouble(txtYard1.getText().trim());
				yard2 = Double.parseDouble(txtYard2.getText().trim());
				yard3 = Double.parseDouble(txtYard3.getText().trim());

				discount = Double.parseDouble(txtDiscount.getText().trim()) / 100;
				excludeVat = (cost1 * yard1 + cost2 * yard2 + cost3 * yard3)
						- (cost1 * yard1 + cost2 * yard2 + cost3 * yard3) * discount;
				vat = (int) (excludeVat * 0.1);
				price = (int) (excludeVat) + vat;
				txtPrice.setText(price + "");

				btnOk.setDisable(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
