package control;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.ChartVO;

public class ChartController implements Initializable {
	@FXML
	private Button btnMonthlySales;
	@FXML
	private Button btnProductSales;
	@FXML
	private Button btnOk;
	ObservableList<ChartVO> monthlySalse = FXCollections.observableArrayList();
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnMonthlySales.setOnAction(event -> handlerBtnMonthlySalesAction(event));
		btnProductSales.setOnAction(event -> handlerBtnProductSalseAction(event));
		btnOk.setOnAction(event -> handlerBtnOkAction(event));
	}
	
	public void handlerBtnOkAction(ActionEvent event) {
		try {
			Stage stage = (Stage) btnOk.getScene().getWindow();
			stage.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnProductSalseAction(ActionEvent event) {
		ChartDAO dao = null;
		ObservableList<ChartVO> list = FXCollections.observableArrayList();
		try {
			dao = new ChartDAO();
			list = dao.getProductSalse();
			
			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnMonthlySales.getScene().getWindow());
			dialog.setTitle("��ǰ�� �����Ǹŷ�");
			
			Parent parent = FXMLLoader.load(getClass().getResource("/view/barchart.fxml"));
			parent.setStyle("-fx-background-color:WHITE");
			
			BarChart barChart = (BarChart) parent.lookup("#barChart");
			
			XYChart.Series seriesApril = new XYChart.Series();
			seriesApril.setName("April");
			ObservableList aprilList = FXCollections.observableArrayList();
			aprilList.add(new XYChart.Data("April", list.get(0).getSum()));
			seriesApril.setData(aprilList);
			barChart.getData().add(seriesApril);
			
			XYChart.Series seriesAugust = new XYChart.Series();
			seriesAugust.setName("August");
			ObservableList augustList = FXCollections.observableArrayList();
			augustList.add(new XYChart.Data("August", list.get(1).getSum()));
			seriesAugust.setData(augustList);
			barChart.getData().add(seriesAugust);
			
			XYChart.Series seriesFebuary = new XYChart.Series();
			seriesFebuary.setName("Febuary");
			ObservableList febuaryList = FXCollections.observableArrayList();
			febuaryList.add(new XYChart.Data("Febuary", list.get(2).getSum()));	
			seriesFebuary.setData(febuaryList);
			barChart.getData().add(seriesFebuary);
			
			XYChart.Series seriesJanuary = new XYChart.Series();
			seriesJanuary.setName("January");
			ObservableList JanuaryList = FXCollections.observableArrayList();
			JanuaryList.add(new XYChart.Data("January" , list.get(3).getSum()));
			seriesJanuary.setData(JanuaryList);
			barChart.getData().add(seriesJanuary);
			

			XYChart.Series seriesJuly = new XYChart.Series();
			seriesJuly.setName("July");
			ObservableList julyList = FXCollections.observableArrayList();
			julyList.add(new XYChart.Data("July", list.get(4).getSum()));
			seriesJuly.setData(julyList);
			barChart.getData().add(seriesJuly);
			
			XYChart.Series seriesJune = new XYChart.Series();
			seriesJune.setName("June");
			ObservableList juneList = FXCollections.observableArrayList();
			juneList.add(new XYChart.Data("June", list.get(5).getSum()));
			seriesJune.setData(juneList);
			barChart.getData().add(seriesJune);
			
			XYChart.Series seriesMarch = new XYChart.Series();
			seriesMarch.setName("March");
			ObservableList marchList = FXCollections.observableArrayList();
			marchList.add(new XYChart.Data("March", list.get(6).getSum()));
			seriesMarch.setData(marchList);
			barChart.getData().add(seriesMarch);
			
			XYChart.Series seriesMay = new XYChart.Series();
			seriesMay.setName("May");
			ObservableList mayList = FXCollections.observableArrayList();
			mayList.add(new XYChart.Data("May", list.get(7).getSum()));
			seriesMay.setData(mayList);
			barChart.getData().add(seriesMay);			
			
			XYChart.Series seriesNovember = new XYChart.Series();
			seriesNovember.setName("November");
			ObservableList novemberList = FXCollections.observableArrayList();
			novemberList.add(new XYChart.Data("November", list.get(8).getSum()));
			seriesNovember.setData(novemberList);
			barChart.getData().add(seriesNovember);
			
			XYChart.Series seriesOctober = new XYChart.Series();
			seriesOctober.setName("October");
			ObservableList octoberList = FXCollections.observableArrayList();
			octoberList.add(new XYChart.Data("October", list.get(9).getSum()));
			seriesOctober.setData(octoberList);
			barChart.getData().add(seriesOctober);
				
			XYChart.Series seriesSeptember = new XYChart.Series();
			seriesSeptember.setName("September");
			ObservableList septemberList = FXCollections.observableArrayList();
			septemberList.add(new XYChart.Data("September", list.get(10).getSum()));
			seriesSeptember.setData(septemberList);
			barChart.getData().add(seriesSeptember);
			
			
			
			
			
			/*XYChart.Series seriesDecember = new XYChart.Series();
			seriesDecember.setName("December");
			ObservableList decemberList = FXCollections.observableArrayList();
			decemberList.add(new XYChart.Data("12��", list.get(0).getSum()));
			seriesDecember.setData(decemberList);
			barChart.getData().add(seriesDecember);*/
			
			Button btnClose = (Button) parent.lookup("#btnClose");
			btnClose.setPrefWidth(70);
			btnClose.setStyle("-fx-background-color:rgb(90,120,220)");
			btnClose.setTextFill(Color.WHITE);
			btnClose.setOnAction(e -> dialog.close());
			
			Scene scene = new Scene(parent);
			dialog.setResizable(false);
			dialog.setHeight(380);
			dialog.setScene(scene);
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void monthlySalse() {
		Object[][] salseData;
		ChartDAO dao = new ChartDAO();
		ChartVO model = null;
		ArrayList<String> title = new ArrayList<>();
		ArrayList<ChartVO> list = new ArrayList<>();
		title = dao.getMonthlySalseColumnName();
		int columnCount = title.size();
		list = dao.getMonthlySalseList();
		int rowCount = list.size();
		salseData = new Object[rowCount][columnCount];
		for (int i = 0; i < rowCount; i ++) {
			model = new ChartVO();
			model = list.get(i);
			monthlySalse.add(model);
		}
	}
	
	public void handlerBtnMonthlySalesAction(ActionEvent event) {
		
		try {
			ChartDAO dao = new ChartDAO();
			ObservableList<ChartVO> list = FXCollections.observableArrayList();
			list = dao.getMonthlySalseList2();
			
			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnMonthlySales.getScene().getWindow());
			dialog.setTitle("���� ����");
			
			Parent parent = FXMLLoader.load(getClass().getResource("/view/barchart.fxml"));
			parent.setStyle("-fx-background-color:WHITE");
			
			BarChart barChart = (BarChart) parent.lookup("#barChart");
			
			XYChart.Series seriesJanuary = new XYChart.Series();
			seriesJanuary.setName("January");
			ObservableList JanuaryList = FXCollections.observableArrayList();
			JanuaryList.add(new XYChart.Data("1��" , list.get(0).getJanuary()));
			seriesJanuary.setData(JanuaryList);
			barChart.getData().add(seriesJanuary);
			
			XYChart.Series seriesFebuary = new XYChart.Series();
			seriesFebuary.setName("Febuary");
			ObservableList febuaryList = FXCollections.observableArrayList();
			febuaryList.add(new XYChart.Data("2��", list.get(0).getFebuary()));	
			seriesFebuary.setData(febuaryList);
			barChart.getData().add(seriesFebuary);
			
			XYChart.Series seriesMarch = new XYChart.Series();
			seriesMarch.setName("March");
			ObservableList marchList = FXCollections.observableArrayList();
			marchList.add(new XYChart.Data("3��", list.get(0).getMarch()));
			seriesMarch.setData(marchList);
			barChart.getData().add(seriesMarch);
			
			XYChart.Series seriesApril = new XYChart.Series();
			seriesApril.setName("April");
			ObservableList aprilList = FXCollections.observableArrayList();
			aprilList.add(new XYChart.Data("4��", list.get(0).getApril()));
			seriesApril.setData(aprilList);
			barChart.getData().add(seriesApril);
			
			XYChart.Series seriesMay = new XYChart.Series();
			seriesMay.setName("May");
			ObservableList mayList = FXCollections.observableArrayList();
			mayList.add(new XYChart.Data("5��", list.get(0).getMay()));
			seriesMay.setData(mayList);
			barChart.getData().add(seriesMay);
			
			XYChart.Series seriesJune = new XYChart.Series();
			seriesJune.setName("June");
			ObservableList juneList = FXCollections.observableArrayList();
			juneList.add(new XYChart.Data("6��", list.get(0).getJune()));
			seriesJune.setData(juneList);
			barChart.getData().add(seriesJune);
			
			
			XYChart.Series seriesJuly = new XYChart.Series();
			seriesJuly.setName("July");
			ObservableList julyList = FXCollections.observableArrayList();
			julyList.add(new XYChart.Data("7��", list.get(0).getJuly()));
			seriesJuly.setData(julyList);
			barChart.getData().add(seriesJuly);
			
			XYChart.Series seriesAugust = new XYChart.Series();
			seriesAugust.setName("August");
			ObservableList augustList = FXCollections.observableArrayList();
			augustList.add(new XYChart.Data("8��", list.get(0).getAugust()));
			seriesAugust.setData(augustList);
			barChart.getData().add(seriesAugust);
			
			XYChart.Series seriesSeptember = new XYChart.Series();
			seriesSeptember.setName("September");
			ObservableList septemberList = FXCollections.observableArrayList();
			septemberList.add(new XYChart.Data("9��", list.get(0).getMay()));
			seriesSeptember.setData(septemberList);
			barChart.getData().add(seriesSeptember);
			
			XYChart.Series seriesOctober = new XYChart.Series();
			seriesOctober.setName("October");
			ObservableList octoberList = FXCollections.observableArrayList();
			octoberList.add(new XYChart.Data("10��", list.get(0).getSeptember()));
			seriesOctober.setData(octoberList);
			barChart.getData().add(seriesOctober);
			
			XYChart.Series seriesNovember = new XYChart.Series();
			seriesNovember.setName("November");
			ObservableList novemberList = FXCollections.observableArrayList();
			novemberList.add(new XYChart.Data("11��", list.get(0).getNovember()));
			seriesNovember.setData(novemberList);
			barChart.getData().add(seriesNovember);
			
			XYChart.Series seriesDecember = new XYChart.Series();
			seriesDecember.setName("December");
			ObservableList decemberList = FXCollections.observableArrayList();
			decemberList.add(new XYChart.Data("12��", list.get(0).getDecember()));
			seriesDecember.setData(decemberList);
			barChart.getData().add(seriesDecember);
			
			Button btnClose = (Button) parent.lookup("#btnClose");
			btnClose.setPrefWidth(70);
			btnClose.setStyle("-fx-background-color:rgb(90,120,220)");
			btnClose.setTextFill(Color.WHITE);
			btnClose.setOnAction(e -> dialog.close());
			
			Scene scene = new Scene(parent);
			dialog.setResizable(false);
			dialog.setHeight(380);
			dialog.setScene(scene);
			dialog.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
