package control;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class LoginWareController implements Initializable {
	@FXML
	private Button btnWareRegistration;
	@FXML
	private TextField txtWareId;
	@FXML
	private TextField txtWarePw;
	@FXML
	private Button btnWareOk;
	@FXML
	private Button btnWareClear;
	@FXML
	private Button btnWareCancel;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnWareRegistration.setOnAction(event -> handlerBtnWareRegistrationAction(event));
		btnWareOk.setOnAction(event -> handlerBtnWareOkAction(event));
		btnWareOk.setOnAction(event -> handlerBtnWareOkLoginAction(event));
		btnWareClear.setOnAction(event -> handlerBtnWareClearAction(event));
		btnWareCancel.setOnAction(event -> handlerBtnWareCancelAction(event));
	}

	public void handlerBtnWareOkLoginAction(ActionEvent event) {
		boolean loginSuccess = handlerBtnWareOkAction(event);
		MemberDAO dao = null;
		String enteredId = "";
		String department = "";
		
		if (loginSuccess) {
			try {
				dao = new MemberDAO();
				enteredId = txtWareId.getText();
				department = "â��";
				dao.log(enteredId, department);
				
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/main_warehouse.fxml"));
				Parent mainView = (Parent) loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("â������ ����");
				mainMtage.setScene(scene);
				mainMtage.setResizable(false);
				Stage oldStage = (Stage) btnWareOk.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�α��� ����");
			alert.setHeaderText("�α��ο� �����߽��ϴ�.");
			alert.setContentText("�����");
			alert.showAndWait();
		}
	}

	public void handlerBtnWareCancelAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/department.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�μ�����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnWareCancel.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnWareClearAction(ActionEvent event) {
		txtWareId.clear();
		txtWarePw.clear();
	}

	public boolean handlerBtnWareOkAction(ActionEvent event) {
		MemberDAO dao = null;
		String enteredId = "";
		String enteredPw = "";
		boolean result;
		boolean loginSuccess = false;
		String department = "";

		try {
			dao = new MemberDAO();
			enteredId = txtWareId.getText().trim();
			enteredPw = txtWarePw.getText().trim();
			result = dao.login(enteredId, enteredPw);
			department = dao.callDepartment(enteredId);

			if (result && !enteredId.equals("") && !enteredPw.equals("") && department.equals("â��")) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�α���");
				alert.setHeaderText("�α��ο� �����߽��ϴ�.");
				alert.setContentText("�α��� ����");
				alert.showAndWait();

				loginSuccess = true;
			} else if (enteredId.equals("") || enteredPw.equals("")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�α���");
				alert.setHeaderText("���̵�/�н����带 �Է��Ͻʽÿ�.");
				alert.setContentText("�Է� �� ����");
				alert.showAndWait();
			
				txtWareId.requestFocus();
			} else if (!department.equals("â��")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�α���");
				alert.setHeaderText("â�� ���� ID�� �ƴմϴ�.");
				alert.setContentText("�μ� Ȯ��");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�α���");
				alert.setHeaderText("���̵�� �н����带 Ȯ���Ͻʽÿ�.");
				alert.setContentText("���� ���� ����");
				alert.showAndWait();

				txtWareId.requestFocus();
			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("�α��� ����");
			alert.setHeaderText("�α��� ������ ������ �߻��߽��ϴ�.");
			alert.setContentText("�����");
			alert.show();
		}
		return loginSuccess;
	}

	public void handlerBtnWareRegistrationAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/join_warehouse.fxml"));
			Parent mainView;
			mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("â�� ���� ���");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnWareRegistration.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
