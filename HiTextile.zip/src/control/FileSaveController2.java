package control;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import model.StockVO;

public class FileSaveController2 implements Initializable{
	@FXML
	private TextField txtSave;
	@FXML
	private Button btnExcel;
	@FXML
	private Button btnSave;
	@FXML
	private Button btnOk;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		btnOk.setOnAction(event -> handlerBtnOkAction(event));
		btnExcel.setOnAction(event -> handlerBtnExcelAction(event));
		btnSave.setOnAction(event -> handlerBtnSaveAction(event));
	}
	
	public void handlerBtnSaveAction(ActionEvent event) {
		Stage primaryStage = new Stage();
		final DirectoryChooser directoryChooser = new DirectoryChooser();
		final File selectedDiretory = directoryChooser.showDialog(primaryStage);
		
		if (selectedDiretory != null) {
			txtSave.setText(selectedDiretory.getAbsolutePath());
			btnExcel.setDisable(false);
		}
	}
	
	public void handlerBtnExcelAction(ActionEvent event) {
		StockDAO dao = new StockDAO();
		boolean saveSuccess;
		ArrayList<StockVO> list;
		list = dao.getStockViewInformation();
		
		saveSuccess = xlsxWriter(list, txtSave.getText());
		if (saveSuccess) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("���� ���� ����");
			alert.setHeaderText("������ ���� ���� ������ �����߽��ϴ�.");
			alert.setContentText("������ ���� ���� ���� �Ϸ�");
			alert.showAndWait();
		}
		txtSave.clear();
		btnExcel.setDisable(true);
	}
	
	public void handlerBtnOkAction(ActionEvent event) {
		try {
			Stage stage = (Stage) btnOk.getScene().getWindow();
			stage.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean xlsxWriter(List<StockVO> list, String saveDir) {
		boolean saveSuccess = false;
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet();
		XSSFRow row = sheet.createRow(0);
		XSSFCell cell;
		cell = row.createCell(0);
		cell.setCellValue("�����ȣ");
		cell = row.createCell(1);
		cell.setCellValue("���ܸ�");
		cell = row.createCell(2);
		cell.setCellValue("�÷�");
		cell = row.createCell(3);
		cell.setCellValue("�ܰ�");
		cell = row.createCell(4);
		cell.setCellValue("����");
		cell = row.createCell(5);
		cell.setCellValue("���");
		cell = row.createCell(6);
		cell.setCellValue("���");
		cell = row.createCell(7);
		cell.setCellValue("�԰�");
		cell = row.createCell(8);
		cell.setCellValue("Ȧ��");
		cell = row.createCell(9);
		cell.setCellValue("����");
		cell = row.createCell(10);
		cell.setCellValue("�ҷ�");
		cell = row.createCell(11);
		cell.setCellValue("����");
		cell = row.createCell(12);
		cell.setCellValue("�޸�");
		cell = row.createCell(13);
		cell.setCellValue("�����");
		
		StockVO model;
		for (int rowIndex = 0; rowIndex < list.size(); rowIndex++) {
			model = list.get(rowIndex);
			
			row = sheet.createRow(rowIndex + 1); 
			cell = row.createCell(0);
			cell.setCellValue(model.getStock_no());
			cell = row.createCell(1);
			cell.setCellValue(model.getFabric_name());
			cell = row.createCell(2);
			cell.setCellValue(model.getFabric_colour());
			cell = row.createCell(3);
			cell.setCellValue(model.getFabric_cost());
			cell = row.createCell(4);
			cell.setCellValue(model.getFabric_material());
			cell = row.createCell(5);
			cell.setCellValue(model.getStock());
			cell = row.createCell(6);
			cell.setCellValue(model.getStock_out());
			cell = row.createCell(7);
			cell.setCellValue(model.getStock_in());
			cell = row.createCell(8);
			cell.setCellValue(model.getStock_holding());
			cell = row.createCell(9);
			cell.setCellValue(model.getStock_sample());
			cell = row.createCell(10);
			cell.setCellValue(model.getStock_defective());
			cell = row.createCell(11);
			cell.setCellValue(model.getStock_service());
			cell = row.createCell(12);
			cell.setCellValue(model.getStock_memo());
			cell = row.createCell(13);
			cell.setCellValue(model.getStock_date());
		}
		
		String strReportPDFName = "stock_" +System.currentTimeMillis() + ".xlsx";
		File file = new File(saveDir + "\\" + strReportPDFName);
		FileOutputStream fos = null;
		
		try {
			fos = new FileOutputStream(file);
			if (fos != null) {
				workbook.write(fos);
				saveSuccess = true;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (workbook != null)
					workbook.close();
				if (fos != null)
					fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return saveSuccess;
	}

}
