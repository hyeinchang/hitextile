package control;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class LoginOfficeController implements Initializable {
	@FXML
	private Button btnOfficeRegistration;
	@FXML
	private TextField txtOfficeId;
	@FXML
	private TextField txtOfficePw;
	@FXML
	private Button btnOfficeOk;
	@FXML
	private Button btnOfficeClear;
	@FXML
	private Button btnOfficeCancel;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		btnOfficeRegistration.setOnAction(event -> handlerBtnOfficeRegistrationAction(event));
		btnOfficeOk.setOnAction(event -> handlerBtnOfficeOkAction(event));
		btnOfficeOk.setOnAction(event -> handlerBtnOfficeOkLoginAction(event));
		btnOfficeClear.setOnAction(event -> handlerBtnOfficeClearAction(event));
		btnOfficeCancel.setOnAction(event -> hanlderBtnOfficeCancelAction(event));
	}

	public void handlerBtnOfficeOkLoginAction(ActionEvent event) {
		boolean loginSuccess = handlerBtnOfficeOkAction(event);
		MemberDAO dao = null;
		String enteredId = "";
		String department = "";
		
		if (loginSuccess) {
			try {
				dao = new MemberDAO();
				enteredId = txtOfficeId.getText();
				department = "�繫��";
				dao.log(enteredId, department);
				
				FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/main_office.fxml"));
				Parent mainView = (Parent) loader.load();
				Scene scene = new Scene(mainView);
				Stage mainMtage = new Stage();
				mainMtage.setTitle("�繫�Ǿ��� ����");
				mainMtage.setResizable(false);
				mainMtage.setScene(scene);
				Stage oldStage = (Stage) btnOfficeOk.getScene().getWindow();
				oldStage.close();
				mainMtage.show();
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�α��� ����");
			alert.setHeaderText("�α��ο� �����߽��ϴ�.");
			alert.setContentText("�����");
			alert.showAndWait();
		}
	}

	public void hanlderBtnOfficeCancelAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/department.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�μ�����");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnOfficeCancel.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnOfficeClearAction(ActionEvent event) {
		txtOfficeId.clear();
		txtOfficePw.clear();
	}

	public boolean handlerBtnOfficeOkAction(ActionEvent event) {
		MemberDAO dao = null;
		String enteredId = "";
		String enteredPw = "";
		boolean result;
		boolean loginSuccess = false;
		String department = "";

		try {
			dao = new MemberDAO();
			enteredId = txtOfficeId.getText().trim();
			enteredPw = txtOfficePw.getText().trim();
			result = dao.login(enteredId, enteredPw);
			department = dao.callDepartment(enteredId);

			if (result && !enteredId.equals("") && !enteredPw.equals("") && department.equals("�繫��")) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�α���");
				alert.setHeaderText("�α��ο� �����߽��ϴ�.");
				alert.setContentText("�α��� ����");
				alert.showAndWait();

				loginSuccess = true;
			} else if (enteredId.equals("") || enteredPw.equals("")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�α���");
				alert.setHeaderText("���̵�/�н����带 �Է��Ͻʽÿ�.");
				alert.setContentText("�Է� �� ����");
				alert.showAndWait();
		
				txtOfficeId.requestFocus();
			} else if (!department.equals("�繫��")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�α���");
				alert.setHeaderText("�繫�� ���� ID�� �ƴմϴ�.");
				alert.setContentText("�μ� Ȯ��");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�α���");
				alert.setHeaderText("���̵�� �н����带 Ȯ���Ͻʽÿ�.");
				alert.setContentText("���� ���� ����");
				alert.showAndWait();

				txtOfficeId.requestFocus();
			}
		} catch (Exception e) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("�α��� ����");
			alert.setHeaderText("�α��� ������ ������ �߻��߽��ϴ�.");
			alert.setContentText("�����");
			alert.show();
		}
		return loginSuccess;
	}

	public void handlerBtnOfficeRegistrationAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/join_office.fxml"));
			Parent mainView;
			mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�繫�� ���� ���");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			Stage oldStage = (Stage) btnOfficeRegistration.getScene().getWindow();
			oldStage.close();
			mainMtage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
