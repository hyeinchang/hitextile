package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Dialog;
import model.TransactionVO;

public class TransactionDAO {
	public boolean enterTransactionInfromation(TransactionVO enter) {
		boolean enter1 = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "insert into transaction (transaction_no, member_no, customer_no, "
				+ "stock_no1, stock_no2, stock_no3, yard1, yard2, yard3, "
				+ "discount, payment, check_payment, address, check_delivery, memo, orderList, transaction_date) "
				+ "values (transaction_seq.nextval, ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, sysdate)";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, enter.getMember_no());
			pstmt.setInt(2, enter.getCustomer_no());
			pstmt.setInt(3, enter.getStock_no1());
			pstmt.setInt(4, enter.getStock_no2());
			pstmt.setInt(5, enter.getStock_no3());
			pstmt.setDouble(6, enter.getYard1());
			pstmt.setDouble(7, enter.getYard2());
			pstmt.setDouble(8, enter.getYard3());
			pstmt.setDouble(9, enter.getDiscount());
			pstmt.setInt(10, enter.getPayment());
			pstmt.setString(11, enter.getCheck_payment());
			pstmt.setString(12, enter.getAddress());
			pstmt.setString(13, enter.getCheck_delivery());
			pstmt.setString(14, enter.getMemo());
			pstmt.setString(15, enter.getOrderList());

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ŷ����");
				alert.setHeaderText("�ŷ���Ͽ� �����߽��ϴ�.");
				alert.setContentText("����� ���ŵ˴ϴ�.");
				alert.showAndWait();
				
				renewStock();
				
				enter1 = true;
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ����");
				alert.setHeaderText("�ŷ���Ͽ� �����߽��ϴ�.");
				alert.setContentText("�ŷ���� ����");
				alert.showAndWait();
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return enter1;
	}
	
	public boolean renewStock() {
		boolean renewSuccess = false;
		boolean renew1 = false;
		boolean renew2 = false;
		boolean renew3 = false;
		int transactionNo = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select transaction_no from transaction order by transaction_date desc";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				transactionNo = rs.getInt("transaction_no");
				
				renew1 = renewStock1(transactionNo);
				renew2 = renewStock2(transactionNo);
				renew3 = renewStock3(transactionNo);
				
				RecordDAO record = new RecordDAO();
				record.recordStockList(transactionNo);
			}
			if (renew1 && renew2 && renew3) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��� ����");
				alert.setHeaderText("��� ���ſ� �����߽��ϴ�.");
				alert.setContentText("��� ���� �Ϸ�");
				alert.showAndWait();
				
				renewSuccess = true;
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return renewSuccess;
	}

	public int returnNewTransactionNo() {
		int transactionNo = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select transaction_no from transaction order by transaction_date desc";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				transactionNo = rs.getInt("transaction_no");
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return transactionNo;
	}
	
	public boolean renewStock1(int no) {
		boolean renew = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "update stock set stock = stock - " +
				"(select t.yard1 from transaction t inner join stock s on t.stock_no1 = s.stock_no where transaction_no = "+no+""
						+ " and not yard1 = 0), " + 
				"stock_out = + " +
				"(select t.yard1 from transaction t inner join stock s on t.stock_no1 = s.stock_no where transaction_no = "+no+""
						+ " and not yard1 = 0),"
						+ " stock_date = sysdate " + 
				"where stock_no = (select stock_no1 from transaction where transaction_no = "+no+")";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				renew = true;
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return renew;
	}
	
	public boolean renewStock2(int no) {
		boolean renew = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "update stock set stock = stock - " +
				"(select t.yard2 from transaction t inner join stock s on t.stock_no2 = s.stock_no where transaction_no = "+no+""
						+ " and not yard2 = 0), " + 
				"stock_out = + " +
				"(select t.yard2 from transaction t inner join stock s on t.stock_no2 = s.stock_no where transaction_no = "+no+""
						+ " and not yard2 = 0),"
						+ " stock_date = sysdate " + 
				"where stock_no = (select stock_no2 from transaction where transaction_no = "+no+")";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				renew = true;
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return renew;
	}
	
	public boolean renewStock3(int no) {
		boolean renew = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "update stock set stock = stock - " +
				"(select t.yard3 from transaction t inner join stock s on t.stock_no3 = s.stock_no where transaction_no = "+no+""
						+ " and not yard3 = 0), " + 
				"stock_out = + " +
				"(select t.yard3 from transaction t inner join stock s on t.stock_no3 = s.stock_no where transaction_no = +"+no+""
						+ " and not yard3 = 0),"
						+ " stock_date = sysdate " + 
				"where stock_no = (select stock_no3 from transaction where transaction_no = "+no+")";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				renew = true;
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return renew;
	}
	public ArrayList<String> getShopMainTransactionColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		String sql = "select t.transaction_no as transaction_no, c.customer_name as customerName, t.orderList as orderList, "
				+ "t.payment as payment, t.address as address, t.check_payment as check_payment, t.check_delivery as check_delivery, "
				+ "t.memo as memo, t.transaction_date as transaction_date "
				+ "from transaction t, customer c, stock s where t.customer_no = c.customer_no and t.stock_no1 = s.stock_no";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i < columnCount; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return columnName;
	}

	public ArrayList<TransactionVO> getShopMainTransactionInformation() {
		ArrayList<TransactionVO> transaction = new ArrayList<>();
		TransactionVO tm = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select t.transaction_no as transaction_no, c.customer_name as customerName, t.orderList as orderList, "
				+ "t.payment as payment, t.address as address, t.check_payment as check_payment, t.check_delivery as check_delivery, "
				+ "t.memo as memo, t.transaction_date as transaction_date "
				+ "from transaction t, customer c, stock s where t.customer_no = c.customer_no and t.stock_no1 = s.stock_no order by 1 desc";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				tm = new TransactionVO();
				tm.setTransaction_no(rs.getInt("transaction_no"));
				tm.setCustomerName(rs.getString("customerName"));
				tm.setOrderList(rs.getString("orderList"));
				tm.setPayment(rs.getInt("payment"));
				tm.setAddress(rs.getString("address"));
				tm.setCheck_payment(rs.getString("check_payment"));
				tm.setCheck_delivery(rs.getString("check_delivery"));
				tm.setMemo(rs.getString("memo"));
				tm.setTransaction_date(rs.getString("transaction_date"));

				transaction.add(tm);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return transaction;
	}

	public ObservableList<TransactionVO> renewShopMainTransactionList() {
		ObservableList<TransactionVO> newList = FXCollections.observableArrayList();
		TransactionVO tm;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select t.transaction_no as transaction_no, c.customer_name as customerName, t.orderList as orderList, "
				+ "t.payment as payment, t.address as address, t.check_payment as check_payment, t.check_delivery as check_delivery, "
				+ "t.memo as memo, t.transaction_date as transaction_date "
				+ "from transaction t, customer c, stock s where t.customer_no = c.customer_no and t.stock_no1 = s.stock_no order by 1 desc";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				tm = new TransactionVO();
				tm.setTransaction_no(rs.getInt("transaction_no"));
				tm.setCustomerName(rs.getString("customerName"));
				tm.setOrderList(rs.getString("orderList"));
				tm.setPayment(rs.getInt("payment"));
				tm.setAddress(rs.getString("address"));
				tm.setCheck_payment(rs.getString("check_payment"));
				tm.setCheck_delivery(rs.getString("check_delivery"));
				tm.setMemo(rs.getString("memo"));
				tm.setTransaction_date(rs.getString("transaction_date"));

				newList.addAll(tm);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return newList;
	}

	public int callCustomerNo(String name) {
		int customerNo = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select customer_no from customer where customer_name = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				customerNo = rs.getInt("customer_no");
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return customerNo;
	}

	public int returnStockNo(String name, String colour) {
		int stock_no = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select stock_no from stock where fabric_name = ? and fabric_colour = ? ";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, colour);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				stock_no = rs.getInt("stock_no");
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return stock_no;
	}

	public String callCustomerName(int no) {
		String CustomerName = "";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select customer_name from customer where customer_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				CustomerName = rs.getString("customer_name");
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return CustomerName;
	}

	public TransactionVO callFabricNameAndColour(int no) {
		TransactionVO model = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select fabric_name, fabric_colour from stock where stock_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new TransactionVO();
				model.setProduct3(rs.getString("fabric_name"));
				model.setColour3(rs.getString("fabric_colour"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return model;
	}

	public ObservableList<String> callFabricColour(int no) {
		String colour = "";
		ObservableList<String> fabricColour = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select fabric_colour from stock where stock_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				colour = rs.getString("fabric_colour");
				fabricColour.add(colour);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return fabricColour;
	}

	public int callFabricCost(int no) {
		int fabricCost = 0;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select fabric_cost from stock where stock_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				fabricCost = rs.getInt("fabric_cost");
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return fabricCost;
	}

	public ArrayList<String> getWareTranasactionColumnName() {
		ArrayList<String> columnName = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		String sql = "select t.transaction_no as transaction_no, c.customer_name as customerName, t.orderList as orderList, "
				+ "t.check_payment as check_payment, t.check_delivery as check_delivery, t.address as address, t.memo as memo, "
				+ "t.transaction_date as transaction_date " + "from transaction t, customer c, stock s "
				+ "where t.customer_no = c.customer_no and t.stock_no1 = s.stock_no";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i < cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return columnName;
	}

	public ArrayList<TransactionVO> getWareTranasactionList() {
		ArrayList<TransactionVO> list = new ArrayList<>();
		TransactionVO model;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select t.transaction_no as transaction_no, c.customer_name as customerName, t.orderList as orderList, "
				+ "t.check_payment as check_payment, t.check_delivery as check_delivery, t.address as address, t.memo as memo, "
				+ "t.transaction_date as transaction_date " + "from transaction t, customer c, stock s "
				+ "where t.customer_no = c.customer_no and t.stock_no1 = s.stock_no order by 1 desc";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new TransactionVO();
				model.setTransaction_no(rs.getInt("transaction_no"));
				model.setCustomerName(rs.getString("customerName"));
				model.setOrderList(rs.getString("orderList"));
				model.setCheck_payment(rs.getString("check_payment"));
				model.setCheck_delivery(rs.getString("check_delivery"));
				model.setAddress(rs.getString("address"));
				model.setMemo(rs.getString("memo"));
				model.setTransaction_date(rs.getString("transaction_date"));

				list.add(model);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return list;
	}

	public TransactionVO callShopMainTransactionInformation(int no) {
		TransactionVO information = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select c.customer_name as customerName, s.fabric_name as product1, "
				+ "s.fabric_colour as colour1, t.yard1 as yard1, "
				+ "c.contact1 as contact1, c.contact2 as contact2, t.address as address, " + "t.stock_no1 as stock_no1,"
				+ "t.check_payment as check_payment, t.check_delivery as check_delivery, "
				+ "t.memo as memo from transaction t inner join customer c on t.customer_no = c.customer_no "
				+ "inner join stock s on t.stock_no1 = s.stock_no where transaction_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				information = new TransactionVO();
				information.setCustomerName(rs.getString("customerName"));
				information.setProduct1(rs.getString("product1"));
				information.setYard1(rs.getDouble("yard1"));
				information.setContact1(rs.getString("contact1"));
				information.setContact2(rs.getString("contact2"));
				information.setAddress(rs.getString("address"));

				information.setCheck_payment(rs.getString("check_payment"));
				information.setCheck_delivery(rs.getString("check_delivery"));
				information.setMemo(rs.getString("memo"));
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return information;
	}

	public void saveTransactionNo(int no) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "insert into transaction_no values (?, sysdate)";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			int i = pstmt.executeUpdate();
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
	}

	public int returnTransactionNo() {
		int no = 0;
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "select transaction_no from transaction_no order by save_date desc";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				no = rs.getInt("transaction_no");
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return no;
	}

	public void clearTransactionNo() {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "delete from transaction_no";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			int i = pstmt.executeUpdate();
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
	}

	public TransactionVO callReceiptInformation() {
		int no = returnTransactionNo();
		TransactionVO model = null;
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "select t.transaction_no as transaction_no, t.member_no as member_no, "
				+ "c.customer_name as customerName, t.stock_no1 as stock_no1, t.yard1 as yard1, t.stock_no2 as stock_no2, t.yard2 as yard2, "
				+ "t.stock_no3 as stock_no3, t.yard3 as yard3, t.discount as discount, t.payment as payment, t.check_payment as check_payment, "
				+ "c.contact1 as contact1, c.contact2 as contact2,"
				+ "t.address as address, t.check_delivery as check_delivery, t.memo as memo from transaction t, customer c "
				+ "where t.customer_no = c.customer_no and transaction_no = " + no + "";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new TransactionVO();
				model.setTransaction_no(rs.getInt("transaction_no"));
				model.setMember_no(rs.getInt("member_no"));
				model.setCustomerName(rs.getString("customerName"));
				model.setStock_no1(rs.getInt("stock_no1"));
				model.setYard1(rs.getDouble("yard1"));
				model.setStock_no2(rs.getInt("stock_no2"));
				model.setYard2(rs.getDouble("yard2"));
				model.setStock_no3(rs.getInt("stock_no3"));
				model.setYard3(rs.getDouble("yard3"));
				model.setDiscount(rs.getInt("discount"));
				model.setPayment(rs.getInt("payment"));
				model.setCheck_payment(rs.getString("check_payment"));
				model.setAddress(rs.getString("address"));
				model.setContact1(rs.getString("contact1"));
				model.setContact2(rs.getString("contact2"));
				model.setCheck_delivery(rs.getString("check_delivery"));
				model.setMemo(rs.getString("memo"));
			}
			clearTransactionNo();
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return model;
	}
	
	public TransactionVO callReceiptInformation2(int no) {
		TransactionVO model = null;
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "select t.transaction_no as transaction_no, t.member_no as member_no, "
				+ "c.customer_name as customerName, t.stock_no1 as stock_no1, t.yard1 as yard1, t.stock_no2 as stock_no2, t.yard2 as yard2, "
				+ "t.stock_no3 as stock_no3, t.yard3 as yard3, t.discount as discount, t.payment as payment, t.check_payment as check_payment, "
				+ "c.contact1 as contact1, c.contact2 as contact2,"
				+ "t.address as address, t.check_delivery as check_delivery, t.memo as memo from transaction t, customer c "
				+ "where t.customer_no = c.customer_no and transaction_no = " + no + "";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new TransactionVO();
				model.setTransaction_no(rs.getInt("transaction_no"));
				model.setMember_no(rs.getInt("member_no"));
				model.setCustomerName(rs.getString("customerName"));
				model.setStock_no1(rs.getInt("stock_no1"));
				model.setYard1(rs.getDouble("yard1"));
				model.setStock_no2(rs.getInt("stock_no2"));
				model.setYard2(rs.getDouble("yard2"));
				model.setStock_no3(rs.getInt("stock_no3"));
				model.setYard3(rs.getDouble("yard3"));
				model.setDiscount(rs.getInt("discount"));
				model.setPayment(rs.getInt("payment"));
				model.setCheck_payment(rs.getString("check_payment"));
				model.setAddress(rs.getString("address"));
				model.setContact1(rs.getString("contact1"));
				model.setContact2(rs.getString("contact2"));
				model.setCheck_delivery(rs.getString("check_delivery"));
				model.setMemo(rs.getString("memo"));
			}

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return model;
	}

	public boolean updateTransactionInformation(TransactionVO enter) {
		boolean editSuccess = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "update transaction set customer_no = ?, " + 
				"stock_no1 = ?, stock_no2 = ?, stock_no3 = ?, "+
				"yard1 = ?, yard2 = ?, yard3 = ?, " + 
				"discount = ?, payment = ?, check_payment = ?, address = ?, check_delivery = ?, " +
				"memo = ?, orderList = ?, transaction_date = sysdate where transaction_no = ? ";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, enter.getCustomer_no());
			pstmt.setInt(2, enter.getStock_no1());
			pstmt.setInt(3, enter.getStock_no2());
			pstmt.setInt(4, enter.getStock_no3());
			pstmt.setDouble(5, enter.getYard1());
			pstmt.setDouble(6, enter.getYard2());
			pstmt.setDouble(7, enter.getYard3());
			pstmt.setDouble(8, enter.getDiscount());
			pstmt.setInt(9, enter.getPayment());
			pstmt.setString(10, enter.getCheck_payment());
			pstmt.setString(11, enter.getAddress());
			pstmt.setString(12, enter.getCheck_delivery());
			pstmt.setString(13, enter.getMemo());
			pstmt.setString(14, enter.getOrderList());
			pstmt.setInt(15, enter.getTransaction_no());

			int i = pstmt.executeUpdate();

			if (i == 1) {
				editSuccess = true;
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ŷ� ����");
				alert.setHeaderText("�ŷ� ������ �����߽��ϴ�.");
				alert.setContentText("�ŷ� ���� �Ϸ�");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ� ����");
				alert.setHeaderText("�ŷ� ������ �����߽��ϴ�.");
				alert.setContentText("�ŷ� ���� ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return editSuccess;
	}
	
	public boolean updateTransactionInformation2(TransactionVO enter) {
		boolean editSuccess = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "update transaction set " + 
				"check_delivery = ?, " +
				"memo = ?, transaction_date = sysdate where transaction_no = ? ";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, enter.getCheck_delivery());
			pstmt.setString(2, enter.getMemo());
			pstmt.setInt(3, enter.getTransaction_no());

			int i = pstmt.executeUpdate();

			if (i == 1) {
				editSuccess = true;
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("��ۻ��� ����");
				alert.setHeaderText("��ۻ��� ���濡 �����߽��ϴ�.");
				alert.setContentText("��ۻ��� ���� �Ϸ�");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("��ۻ��� ����");
				alert.setHeaderText("��ۻ��� ���濡 �����߽��ϴ�.");
				alert.setContentText("��ۻ��� ���� ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return editSuccess;
	}
	
	public boolean deleteTransactionInformation(int no) {
		boolean deleteSuccess = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "delete from transaction where transaction_no = ? ";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			
			int i = pstmt.executeUpdate();
			
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ŷ�����");
				alert.setHeaderText("�ŷ������� �����߽��ϴ�.");
				alert.setContentText("�ŷ����� �Ϸ�");
				alert.showAndWait();

				deleteSuccess = true;
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ�����");
				alert.setHeaderText("�ŷ������� �����߽��ϴ�.");
				alert.setContentText("�ŷ����� ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return deleteSuccess;
	}
	
	public ArrayList<String> getOfficeMainColumnName(){
		ArrayList<String> columnName = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		String sql = "select t.transaction_no as transaction_no, m.member_name as memberName, c.customer_name as customerName, t.orderList as orderList, " + 
				"t.discount as discount, t.payment as payment, t.check_payment as check_payment, t.memo as memo, t.transaction_date as transaction_date " + 
				"from transaction t, member m, customer c where t.member_no = m.member_no and t.customer_no = c.customer_no";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i < cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return columnName;
	}
	
	public ArrayList<TransactionVO> getOfficeTransactionInformation() {
		TransactionVO model = null;
		ArrayList<TransactionVO> information = new ArrayList<>();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql ="select t.transaction_no as transaction_no, m.member_name as memberName, c.customer_name as customerName, t.orderList as orderList, " + 
				"t.discount as discount, t.payment as payment, t.check_payment as check_payment, t.memo as memo, t.transaction_date as transaction_date " + 
				"from transaction t, member m, customer c where t.member_no = m.member_no and t.customer_no = c.customer_no";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new TransactionVO();
				model.setTransaction_no(rs.getInt("transaction_no"));
				model.setMemberName(rs.getString("memberName"));
				model.setCustomerName(rs.getString("customerName"));
				model.setOrderList(rs.getString("orderList"));
				model.setDiscount(rs.getInt("discount"));
				model.setPayment(rs.getInt("payment"));
				model.setCheck_payment(rs.getString("check_payment"));
				model.setMemo(rs.getString("memo"));
				model.setTransaction_date(rs.getString("transaction_date"));
				information.add(model);
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return information;
	}
}
