package control;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import model.StockRecordVO;
import model.StockVO;

public class StockRecordController implements Initializable{
	@FXML
	private Button btnCheck;
	@FXML
	private TextField txtNo;
	@FXML
	private TextField txtName;
	@FXML
	private ComboBox<String> cbColour;
	@FXML
	private TextField txtMaterial;
	@FXML
	private TextField txtCost;
	@FXML
	private TextField txtMemo;
	@FXML
	private Button btnOk;
	@FXML
	private Button btnInitialize;
	@FXML
	private Button btnCancel;

	@FXML
	private TableView<StockRecordVO> stockRecordTable;
	@FXML
	private ObservableList<StockRecordVO> stockRecord = FXCollections.observableArrayList();
	private ObservableList<Integer> stockNoList = FXCollections.observableArrayList();
	int stockNo = 0;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		stockRecordTable.setEditable(false);
		TableColumn colStock_date = new TableColumn("�����");
		colStock_date.setMinWidth(100);
		colStock_date.setMaxWidth(100);
		colStock_date.setStyle("-fx-alignment:CENTER");
		colStock_date.setCellValueFactory(new PropertyValueFactory<>("stock_date"));
		TableColumn col���= new TableColumn("���");
		col���.setMinWidth(80);
		col���.setMaxWidth(80);
		col���.setStyle("-fx-alignment:CENTER");
		col���.setCellValueFactory(new PropertyValueFactory<>("�԰�"));
		TableColumn col�԰� = new TableColumn("�԰�");
		col�԰�.setMinWidth(80);
		col�԰�.setMaxWidth(80);
		col�԰�.setStyle("-fx-alignment:CENTER");
		col�԰�.setCellValueFactory(new PropertyValueFactory<>("�԰�"));
		TableColumn col��� = new TableColumn("���");
		col���.setMinWidth(80);
		col���.setMaxWidth(80);
		col���.setStyle("-fx-alignment:CENTER");
		col���.setCellValueFactory(new PropertyValueFactory<>("���"));
		TableColumn colȦ�� = new TableColumn("Ȧ��");
		colȦ��.setMinWidth(70);
		colȦ��.setMaxWidth(70);
		colȦ��.setStyle("-fx-alignment:CENTER");
		colȦ��.setCellValueFactory(new PropertyValueFactory<>("Ȧ��"));
		TableColumn col��ǰ = new TableColumn("��ǰ");
		col��ǰ.setMinWidth(70);
		col��ǰ.setMaxWidth(70);
		col��ǰ.setStyle("-fx-alignment:CENTER");
		col��ǰ.setCellValueFactory(new PropertyValueFactory<>("��ǰ"));
		TableColumn col���� = new TableColumn("����");
		col����.setMinWidth(70);
		col����.setMaxWidth(70);
		col����.setStyle("-fx-alignment:CENTER");
		col����.setCellValueFactory(new PropertyValueFactory<>("����"));
		TableColumn col�ҷ� = new TableColumn("����");
		col�ҷ�.setMinWidth(70);
		col�ҷ�.setMaxWidth(70);
		col�ҷ�.setStyle("-fx-alignment:CENTER");
		col�ҷ�.setCellValueFactory(new PropertyValueFactory<>("�ҷ�"));
		TableColumn col���� = new TableColumn("����");
		col����.setMinWidth(70);
		col����.setMaxWidth(70);
		col����.setStyle("-fx-alignment:CENTER");
		col����.setCellValueFactory(new PropertyValueFactory<>("����"));
		TableColumn col�޸� = new TableColumn("�޸�");
		col�޸�.setMinWidth(120);
		col�޸�.setMaxWidth(120);
		col�޸�.setCellValueFactory(new PropertyValueFactory<>("�޸�"));

		stockRecordTable.setItems(stockRecord);
		stockRecordTable.getColumns().addAll(colStock_date, col���, col�԰�, col���, colȦ��,
				col��ǰ, col����, col�ҷ�, col����, col�޸�);
		stockList();
		
		RecordDAO dao = new RecordDAO();
		stockNoList = dao.getNo();
		stockNo = stockNoList.get(0);
		stockNoList.clear();
		stockRecord = dao.getProductRecordList(stockNo);
		stockRecordTable.setItems(stockRecord);
		dao.clearNo();
	}
	
	public void stockList() {
		Object[][] stockData;

		RecordDAO dao = new RecordDAO();
		StockRecordVO model = new StockRecordVO();
		ArrayList<String> title;
		ArrayList<StockRecordVO> list;

		title = dao.getStockRecordColumnName();
		int columnCount = title.size();

		list = dao.getStockRecordList();
		int rowCount = list.size();

		stockData = new Object[rowCount][columnCount];

		for (int index = 0; index < rowCount; index++) {
			model = list.get(index);
			stockRecord.add(model);
		}
	}
}
