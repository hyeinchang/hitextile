package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.CustomerVO;

public class CustomerDAO {
	public boolean customerRegistration(CustomerVO input) {
		boolean registrationSuccess = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "insert into customer values " + "(customer_seq.nextval, ?,?,?,?,?,?,?)";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);

			pstmt.setString(1, input.getCustomer_name());
			pstmt.setString(2, input.getContact1());
			pstmt.setString(3, input.getContact1());
			pstmt.setString(4, input.getCorporate_registration_number());
			pstmt.setString(5, input.getCompany_name());
			pstmt.setString(6, input.getRepresentative());
			pstmt.setString(7, input.getBusiness_license());

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ŷ�ó ���");
				alert.setHeaderText("�ŷ�ó ��Ͽ� �����߽��ϴ�.");
				alert.setContentText("�ŷ�ó ��ϵ�");
				alert.showAndWait();

				registrationSuccess = true;
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ�ó���");
				alert.setHeaderText("�ŷ�ó ��Ͽ� �����߽��ϴ�.");
				alert.setContentText("�����");
				alert.showAndWait();
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return registrationSuccess;
	}

	public boolean checkCustomerName(String customerName) {
		boolean nameOverlap = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select customer_name from customer " + "where customer_name = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, customerName);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				nameOverlap = true;
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}

		return nameOverlap;
	}

	public CustomerVO mainSearchCustomerName(String customerName) {
		CustomerVO customer = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select customer_name, contact1, contact2 from customer " + "where customer_name = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, customerName);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				customer = new CustomerVO();
				customer.setCustomer_name(rs.getString("customer_name"));
				customer.setContact1(rs.getString("contact1"));
				customer.setContact2(rs.getString("contact2"));
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return customer;
	}

	public ArrayList<String> getCustomerColumnName() {
		ArrayList<String> customerColumnName = new ArrayList<>();
		String sql = "select * from customer";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				customerColumnName.add(rsmd.getColumnName(i));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return customerColumnName;
	}

	public ArrayList<CustomerVO> getCustomerInformation() {
		ArrayList<CustomerVO> customerInformation = new ArrayList<>();
		String sql = "select * from customer order by customer_no";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		CustomerVO model = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				model = new CustomerVO();
				model.setCustomer_no(rs.getInt("customer_no"));
				model.setCustomer_name(rs.getString("customer_name"));
				model.setContact1(rs.getString("contact1"));
				model.setContact2(rs.getString("contact2"));
				model.setCorporate_registration_number(rs.getString("corporate_registration_number"));
				model.setCompany_name(rs.getString("company_name"));
				model.setRepresentative(rs.getString("representative"));
				model.setBusiness_license(rs.getString("business_license"));

				customerInformation.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return customerInformation;
	}

	public ObservableList<String> callCustomerName() {
		ObservableList<String> customerName = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select customer_name from customer order by 1";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				customerName.addAll(rs.getString("customer_name"));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return customerName;
	}

	public CustomerVO callCustomerInformation(String name) {
		CustomerVO model = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from customer where customer_name = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new CustomerVO();
				model.setCustomer_no(rs.getInt(1));
				model.setCustomer_name(rs.getString(2));
				model.setContact1(rs.getString(3));
				model.setContact2(rs.getString(4));
				model.setCorporate_registration_number(rs.getString(5));
				model.setCompany_name(rs.getString(6));
				model.setRepresentative(rs.getString(7));
				model.setBusiness_license(rs.getString(8));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return model;
	}

	public CustomerVO updateCustomerInformation(CustomerVO enter) {
		CustomerVO information = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "update customer set customer_name=?,contact1=?,contact2=?,"
				+ "corporate_registration_number=?,company_name=?,representative=?,business_license=? "
				+ "where customer_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, enter.getCustomer_name());
			pstmt.setString(2, enter.getContact1());
			pstmt.setString(3, enter.getContact2());
			pstmt.setString(4, enter.getCorporate_registration_number());
			pstmt.setString(5, enter.getCompany_name());
			pstmt.setString(6, enter.getRepresentative());
			pstmt.setString(7, enter.getBusiness_license());
			pstmt.setInt(8, enter.getCustomer_no());
			int i = pstmt.executeUpdate();
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ŷ�ó ���� ����");
				alert.setHeaderText("�ŷ�ó ���� ���濡 �����߽��ϴ�.");
				alert.setContentText("�ŷ�ó ���� ���� �Ϸ�");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ�ó ���� ����");
				alert.setHeaderText("�ŷ�ó ���� ���濡 �����߽��ϴ�");
				alert.setContentText("�ŷ�ó ���� ���� ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
			}
		}
		return information;
	}

	public boolean deleteCustomerInformation(int no) {
		boolean delete = false;
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = "delete from customer where customer_no = ?";

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, no);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("�ŷ�ó ���� ����");
				alert.setHeaderText("�ŷ�ó ���� ������ �����߽��ϴ�.");
				alert.setContentText("�ŷ�ó ���� ���� �Ϸ�");
				alert.showAndWait();
				
				delete = true;
			} else {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ�ó ���� ����");
				alert.setHeaderText("�ŷ�ó ���� ������ �����߽��ϴ�");
				alert.setContentText("�ŷ�ó ���� ���� ����");
				alert.showAndWait();
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (pstmt != null) pstmt.close();
				if (con != null) con.close();
			} catch (Exception e) {	}
		}
		return delete;
	}
}
