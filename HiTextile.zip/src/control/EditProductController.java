package control;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import model.StockVO;

public class EditProductController implements Initializable{
	@FXML
	private Button btnCheck;
	@FXML
	private TextField txtNo;
	@FXML
	private TextField txtName;
	@FXML
	private ComboBox<String> cbColour;
	@FXML
	private TextField txtMaterial;
	@FXML
	private TextField txtCost;
	@FXML
	private TextField txtMemo;
	@FXML
	private Button btnOk;
	@FXML
	private Button btnInitialize;
	@FXML
	private Button btnCancel;
	ProductInformationController information = new ProductInformationController();
	int stockNo = 0;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

		stockNo = 0;
		String name = "";
		ObservableList<String> colour = FXCollections.observableArrayList();
		String material = "";
		int cost = 0;
		String memo = "";
		
		try {
			StockDAO dao = new StockDAO();
			StockVO product = new StockVO();
			product = dao.callProductInformation(stockNo);
			stockNo = product.getStock_no();
			name = product.getFabric_name();
			colour = dao.callColour(stockNo);
			material = product.getFabric_material();
			cost = product.getFabric_cost();
			memo = product.getStock_memo();

			txtNo.setText(stockNo + "");
			txtName.setText(name);
			cbColour.setItems(colour);
			cbColour.selectionModelProperty().get().selectFirst();
			txtMaterial.setText(material);
			txtCost.setText(cost + "");
			txtMemo.setText(memo);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
