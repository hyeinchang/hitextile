package control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.SearchVO;
import model.TransactionVO;

public class SearchDAO {
	public ObservableList<TransactionVO> searchShopMainTransactionTableOne(SearchVO search) {
		ObservableList<TransactionVO> list = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select t.transaction_no as transaction_no, c.customer_name as customerName, t.orderList as orderList, " + 
				"t.payment as payment, t.check_payment as check_payment, t.check_delivery as check_delivery, " + 
				"t.memo as memo, t.transaction_date as transaction_date from transaction t inner join customer c on " + 
				"t.customer_no = c.customer_no where transaction_no = ? or customer_name = ? or orderList like '%'||?||'%' " + 
				"or payment = ? or check_payment = ? or check_delivery = ? or memo =? or transaction_date = ?";
		TransactionVO model = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, search.getTransaction_no());
			pstmt.setString(2, search.getCustomer_name());
			pstmt.setString(3, search.getOrderList());
			pstmt.setInt(4, search.getPayment());
			pstmt.setString(5, search.getCheck_payment());
			pstmt.setString(6, search.getCheck_delivery());
			pstmt.setString(7, search.getMemo());
			pstmt.setString(8, search.getTransaction_date());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new TransactionVO();
				model.setTransaction_no(rs.getInt("transaction_no"));
				model.setCustomerName(rs.getString("customerName"));
				model.setOrderList(rs.getString("orderList"));
				model.setPayment(rs.getInt("payment"));
				model.setCheck_payment(rs.getString("check_payment"));
				model.setCheck_delivery(rs.getString("check_delivery"));
				model.setTransaction_date(rs.getString("transaction_date"));
				
				list.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close(); 
			} catch (Exception e) {	}
		}
		return list;
	}
	
	public ObservableList<TransactionVO> searchWareMainTransactionTable(SearchVO search) {
		ObservableList<TransactionVO> list = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select t.transaction_no as transaction_no, c.customer_name as customerName, t.orderList as orderList, " + 
				"t.payment as payment, t.check_payment as check_payment, t.check_delivery as check_delivery, " + 
				"t.memo as memo, t.transaction_date as transaction_date from transaction t inner join customer c on " + 
				"t.customer_no = c.customer_no where transaction_no = ? or customer_name = ? or orderList like '%'||?||'%' " + 
				"or address = ? or check_payment = ? or check_delivery = ? or memo = ? or transaction_date = ?";
		TransactionVO model = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, search.getTransaction_no());
			pstmt.setString(2, search.getCustomer_name());
			pstmt.setString(3, search.getOrderList());
			pstmt.setString(4, search.getAddress());
			pstmt.setString(5, search.getCheck_payment());
			pstmt.setString(6, search.getCheck_delivery());
			pstmt.setString(7, search.getMemo());
			pstmt.setString(8, search.getTransaction_date());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new TransactionVO();
				model.setTransaction_no(rs.getInt("transaction_no"));
				model.setCustomerName(rs.getString("customerName"));
				model.setOrderList(rs.getString("orderList"));
				model.setAddress(rs.getString("address"));
				model.setCheck_payment(rs.getString("check_payment"));
				model.setCheck_delivery(rs.getString("check_delivery"));
				model.setMemo(rs.getString("memo"));
				model.setTransaction_date(rs.getString("transaction_date"));
				
				list.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close(); 
			} catch (Exception e) {	}
		}
		return list;
	}
	
	public ObservableList<TransactionVO> searchShopMainTransactionTable(SearchVO search) {
		ObservableList<TransactionVO> list = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select t.transaction_no as transaction_no, m.member_name as memberName, c.customer_name as customerName, t.orderList as orderList, " + 
				"t.discount as discount, t.payment as payment, t.check_payment as check_payment, " + 
				"t.memo as memo, t.transaction_date as transaction_date from transaction t inner join customer c on " + 
				"t.customer_no = c.customer_no and t.transaction inner join on t.member_no = m.member_no " +
				"where transaction_no = ? or memberName =? or customer_name = ? or orderList like '%'||?||'%' " + 
				"or discount = ? or payment = ? or check_payment = ? or memo = ? or transaction_date = ?";
		TransactionVO model = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, search.getTransaction_no());
			pstmt.setString(2, search.getCustomer_name());
			pstmt.setString(3, search.getMember_name());
			pstmt.setString(4, search.getOrderList());
			pstmt.setInt(5, search.getPayment());
			pstmt.setString(6, search.getCheck_payment());
			pstmt.setString(8, search.getMemo());
			pstmt.setString(9, search.getTransaction_date());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				model = new TransactionVO();
				model.setTransaction_no(rs.getInt("transaction_no"));
				model.setMemberName(rs.getString("memberName"));
				model.setCustomerName(rs.getString("customerName"));
				model.setOrderList(rs.getString("orderList"));
				model.setAddress(rs.getString("address"));
				model.setCheck_payment(rs.getString("check_payment"));
				model.setCheck_delivery(rs.getString("check_delivery"));
				model.setMemo(rs.getString("memo"));
				model.setTransaction_date(rs.getString("transaction_date"));
				
				list.add(model);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close(); 
			} catch (Exception e) {	}
		}
		return list;
	}
	
	ObservableList<String> callFabricName(){
		ObservableList<String> list = FXCollections.observableArrayList();
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select distinct fabric_name from stock";
		String name = "";
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				name = rs.getString("fabric_name");
				list.addAll(name);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) rs.close();
				if (pstmt != null) pstmt.close();
				if (con != null) con.close(); 
			} catch (Exception e) {	}
		}
		return list;
	}
}
