package control;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TouchEvent;
import javafx.stage.Stage;
import model.CustomerVO;
import model.StockVO;
import model.TransactionVO;

public class ReceiptController implements Initializable {
	@FXML
	private TextField txtMemberNo;
	@FXML
	private TextField txtCustomer;
	@FXML
	private Button btnCustomerSearch;
	@FXML
	private Button btnDelete;
	@FXML
	private TextField txtProduct1;
	@FXML
	private Button btnProduct1;
	@FXML
	private TextField txtCost1;
	@FXML
	private ComboBox<String> cbColour1;
	@FXML
	private TextField txtYard1;
	@FXML
	private TextField txtProduct2;
	@FXML
	private Button btnProduct2;
	@FXML
	private TextField txtCost2;
	@FXML
	private ComboBox<String> cbColour2;
	@FXML
	private TextField txtYard2;
	@FXML
	private TextField txtProduct3;
	@FXML
	private Button btnProduct3;
	@FXML
	private TextField txtCost3;
	@FXML
	private ComboBox<String> cbColour3;
	@FXML
	private TextField txtYard3;
	@FXML
	private TextField txtDiscount;
	@FXML
	private Button btnCal;
	@FXML
	private TextField txtPrice;
	@FXML
	private TextField txtContact1;
	@FXML
	private TextField txtContact2;
	@FXML
	private TextField txtAddress;
	@FXML
	private RadioButton rbBeforePayment;
	@FXML
	private RadioButton rbAfterPayment;
	@FXML
	private ToggleGroup paymentGroup;
	@FXML
	private RadioButton rbStock;
	@FXML
	private RadioButton rbHolding;
	@FXML
	private RadioButton rbComplete;
	@FXML
	private ToggleGroup deliveryGroup;
	@FXML
	private TextField txtMemo;
	@FXML
	private Button btnOk;
	@FXML
	private Button btnClear;
	@FXML
	private TextField txtTransactionNo;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		TransactionDAO dao = new TransactionDAO();
		StockDAO stockDao = null;

		TransactionVO model = null;
		StockVO fabric1 = null;
		StockVO fabric2 = null;
		StockVO fabric3 = null;
		String customer = "";
		String product1 = "";
		double yard1 = 0;
		String contact1 = "";
		String contact2 = "";
		String address = "";
		int price = 0;
		String pay = "";
		String delivery = "";
		String memo = "";
		String product2 = "";
		double yard2 = 0;
		String product3 = "";
		double yard3 = 0;
		int stock1 = 0;
		int stock2 = 0;
		int stock3 = 0;
		String colour1 = "";
		String colour2 = "";
		String colour3 = "";
		int cost1 = 0;
		int cost2 = 0;
		int cost3 = 0;
		double discount = 0;
		int memberNo = 0;
		int transactionNo = 0;

		dao = new TransactionDAO();
		model = new TransactionVO();
		model = dao.callReceiptInformation();

		transactionNo = model.getTransaction_no();
		memberNo = model.getMember_no();
		customer = model.getCustomerName();

		stock1 = model.getStock_no1();
		stock2 = model.getStock_no2();
		stock3 = model.getStock_no3();

		stockDao = new StockDAO();
		fabric1 = new StockVO();
		fabric1 = stockDao.callNameAndColourAndCost(stock1);
		product1 = fabric1.getFabric_name();
		colour1 = fabric1.getFabric_colour();
		cost1 = fabric1.getFabric_cost();
		txtProduct1.setText(product1);
		txtCost1.setText(cost1 + "");
		cbColour1.setItems(FXCollections.observableArrayList(colour1));
		cbColour1.getSelectionModel().select(0);

		fabric2 = new StockVO();
		fabric2 = stockDao.callNameAndColourAndCost(stock2);
		product2 = fabric2.getFabric_name();
		colour2 = fabric2.getFabric_colour();
		cost2 = fabric2.getFabric_cost();
		txtProduct2.setText(product2);
		txtCost2.setText(cost2 + "");
		cbColour2.setItems(FXCollections.observableArrayList(colour2));
		cbColour2.getSelectionModel().select(0);

		fabric3 = new StockVO();
		fabric3 = stockDao.callNameAndColourAndCost(stock3);
		product3 = fabric3.getFabric_name();
		colour3 = fabric3.getFabric_colour();
		cost3 = fabric3.getFabric_cost();
		txtProduct3.setText(product3);
		txtCost3.setText(cost3 + "");
		cbColour3.setItems(FXCollections.observableArrayList(colour3));
		cbColour3.getSelectionModel().select(0);

		yard1 = model.getYard1();
		yard2 = model.getYard2();
		yard3 = model.getYard3();

		discount = model.getDiscount();

		price = model.getPayment();
		contact1 = model.getContact1();
		contact2 = model.getContact2();
		address = model.getAddress();
		pay = model.getCheck_payment();
		delivery = model.getCheck_delivery();
		memo = model.getMemo();

		txtTransactionNo.setText(transactionNo + "");
		txtMemberNo.setText(memberNo + "");
		txtCustomer.setText(customer);

		txtYard1.setText(yard1 + "");
		txtYard2.setText(yard2 + "");
		txtYard3.setText(yard3 + "");
		txtDiscount.setText(discount + "");

		txtPrice.setText(price + "");
		txtContact1.setText(contact1);
		txtContact2.setText(contact2);
		txtAddress.setText(address);
		txtMemo.setText(memo);

		if (pay.equals("û��")) {
			rbBeforePayment.setSelected(true);
		} else if (pay.equals("����")) {
			rbAfterPayment.setSelected(true);
		}

		if (delivery.equals("���")) {
			rbStock.setSelected(true);
		} else if (delivery.equals("Ȧ��")) {
			rbHolding.setSelected(true);
		} else if (delivery.equals("�Ϸ�")) {
			rbComplete.setSelected(true);
		}

		cbColour1.setItems(FXCollections.observableArrayList("ȭ��Ʈ", "������", "��ũ", "����", "����"));
		cbColour2.setItems(FXCollections.observableArrayList("ȭ��Ʈ", "������", "��ũ", "����", "����"));
		cbColour2.setItems(FXCollections.observableArrayList("ȭ��Ʈ", "������", "��ũ", "����", "����"));

		txtMemberNo.setEditable(false);

		btnCal.setOnAction(event -> handlerBtnCalculateConditionAction(event));
		btnCal.setOnAction(event -> handlerBtnCalculateAction(event));
		btnOk.setOnAction(event -> handlerBtnOkAction(event));
		btnClear.setOnAction(event -> handlerBtnClearAction(event));
		btnCustomerSearch.setOnAction(event -> handlerBtnCustomerSearchAction(event));
		btnProduct1.setOnAction(event -> handlerBtnProduct1Action(event));
		btnProduct2.setOnAction(event -> handlerBtnProduct2Action(event));
		btnProduct3.setOnAction(event -> handlerBtnProduct3Action(event));
		btnDelete.setOnAction(event -> handlerBtnDeleteAction(event));
		
	}

	public void handlerBtnDeleteAction(ActionEvent event) {
		TransactionDAO dao = new TransactionDAO();
		int no = Integer.parseInt(txtTransactionNo.getText());
		dao.deleteTransactionInformation(no);
		handlerBtnOkAction(event);
	}

	public void handlerBtnStockViewAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/stock_view.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("��� ����Ʈ");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void handlerBtnProduct3Action(ActionEvent event) {
		String product3 = "";
		int cost3 = 0;
		ObservableList<String> setColour = FXCollections.observableArrayList();
		StockDAO dao = null;
		StockVO model = null;

		try {
			if (event.getSource().equals(btnProduct3)) {
				product3 = txtProduct3.getText().trim();
				dao = new StockDAO();

				if (product3.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��3 �˻�");
					alert.setHeaderText("ǰ��3�� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("ǰ��3 �Է� �� ����");
					alert.showAndWait();
					txtProduct3.requestFocus();
				} else if (dao.checkNameAndInformation(product3) == null) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��3 �˻�");
					alert.setHeaderText("�Էµ� ǰ��3�� �ش�Ǵ� ��ǰ�� �����ϴ�.");
					alert.setContentText("ǰ��3 �Է� �� Ȯ��");
					alert.showAndWait();
					txtProduct3.requestFocus();
				} else {
					model = new StockVO();

					model = dao.checkNameAndInformation(product3);
					cost3 = model.getFabric_cost();
					setColour = dao.callColourBox(product3);
					txtCost3.setText(cost3 + "");
					cbColour3.setItems(setColour);
					cbColour3.setPromptText("����");

					// �ŷ�ó�� ��ǰ���� �˻����� �ҷ������� ���ٲٰ� ����
					txtProduct3.setEditable(false);
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnProduct2Action(ActionEvent event) {
		String product2 = "";
		int cost2 = 0;
		ObservableList<String> setColour = FXCollections.observableArrayList();
		StockDAO dao = null;
		StockVO model = null;

		try {
			if (event.getSource().equals(btnProduct2)) {
				product2 = txtProduct2.getText().trim();
				dao = new StockDAO();

				if (product2.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��2 �˻�");
					alert.setHeaderText("ǰ��2�� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("ǰ��2 �Է� �� ����");
					alert.showAndWait();
					txtProduct2.requestFocus();
				} else if (dao.checkNameAndInformation(product2) == null) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��2 �˻�");
					alert.setHeaderText("�Էµ� ǰ��2�� �ش�Ǵ� ��ǰ�� �����ϴ�.");
					alert.setContentText("ǰ��2 �Է� �� Ȯ��");
					alert.showAndWait();
					txtProduct2.requestFocus();
				} else {
					model = new StockVO();

					model = dao.checkNameAndInformation(product2);
					cost2 = model.getFabric_cost();
					setColour = dao.callColourBox(product2);
					txtCost2.setText(cost2 + "");
					cbColour2.setItems(setColour);
					cbColour2.setPromptText("����");

					txtProduct3.setEditable(true);
					btnProduct3.setDisable(false);

					// �ŷ�ó�� ��ǰ���� �˻����� �ҷ������� ���ٲٰ� ����
					txtProduct2.setEditable(false);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnProduct1Action(ActionEvent event) {
		String product1 = "";
		int cost1 = 0;
		ObservableList<String> setColour = FXCollections.observableArrayList();
		StockDAO dao = null;
		StockVO model = null;

		try {
			if (event.getSource().equals(btnProduct1)) {
				product1 = txtProduct1.getText().trim();
				dao = new StockDAO();

				if (product1.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��1 �˻�");
					alert.setHeaderText("ǰ��1�� ���� �Է��Ͻʽÿ�.");
					alert.setContentText("ǰ��1 �Է� �� ����");
					alert.showAndWait();
					txtProduct1.requestFocus();
				} else if (dao.checkNameAndInformation(product1) == null) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("ǰ��1 �˻�");
					alert.setHeaderText("�Էµ� ǰ��1�� �ش�Ǵ� ��ǰ�� �����ϴ�.");
					alert.setContentText("ǰ��1 �Է� �� Ȯ��");
					alert.showAndWait();
					txtProduct1.requestFocus();
				} else {
					model = new StockVO();

					model = dao.checkNameAndInformation(product1);
					cost1 = model.getFabric_cost();
					setColour = dao.callColourBox(product1);
					txtCost1.setText(cost1 + "");
					cbColour1.setItems(setColour);
					cbColour1.setPromptText("����");

					txtProduct2.setEditable(true);
					btnProduct2.setDisable(false);
					btnCal.setDisable(false);

					// �ŷ�ó�� ��ǰ���� �˻����� �ҷ������� ���ٲٰ� ����
					txtProduct1.setEditable(false);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void handlerBtnCustomerSearchAction(ActionEvent event) {
		String searchName = "";
		CustomerDAO dao = null;
		CustomerVO result = null;

		try {
			dao = new CustomerDAO();
			result = new CustomerVO();
			searchName = txtCustomer.getText().trim();
			result = dao.mainSearchCustomerName(searchName);

			if (searchName.equals("")) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ�ó��ȸ");
				alert.setHeaderText("�ŷ�ó �̸��� �Է��Ͻʽÿ�.");
				alert.setContentText("�ŷ�ó �̸� �Է� �� ����");
				alert.showAndWait();
			} else if (result == null) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ŷ�ó��ȸ");
				alert.setHeaderText("�˻��� �ŷ�ó ������ �����ϴ�.");
				alert.setContentText("�ŷ�ó�̸� Ȯ��");
				alert.showAndWait();
			} else {
				txtCustomer.setText(result.getCustomer_name());
				txtContact1.setText(result.getContact1());
				txtContact2.setText(result.getContact2());

				btnProduct1.setDisable(false);

				// �ŷ�ó�� ��ǰ���� �˻����� �ҷ������� ���ٲٰ� ����
				txtCustomer.setEditable(false);
			}

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�ŷ�ó�� �˻�");
			alert.setHeaderText("�˻��� �ŷ�ó���� �Է��Ͻʽÿ�.");
			alert.setContentText("�ŷ�ó�� �Է� �� ����");
			alert.showAndWait();

			txtCustomer.requestFocus();
		}
	}

	public void handlerBtnCustomerRegistrationAction(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/customer_registration.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setTitle("�ŷ�ó ���");
			mainMtage.setResizable(false);
			mainMtage.setScene(scene);
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean handlerBtnClearAction(ActionEvent event) {
		boolean update1 = false;
		TransactionDAO dao = null;
		TransactionVO model = null;
		int memberNo = 0;
		String customer = "";
		String product1 = "";
		String colour1 = "";
		double yard1 = 0;
		String product2 = "";
		String colour2 = "";
		double yard2 = 0;
		String product3 = "";
		String colour3 = "";
		double yard3 = 0;
		double discount = 0;
		int price = 0;
		String address = "";
		String check_payment = "";
		String check_delivery = "";
		String memo = "";
		String orderList = "";
		int transactionNo = 0;

		try {
			if (event.getSource().equals(btnClear)) {
				product1 = txtProduct1.getText();
				check_payment = paymentGroup.getSelectedToggle().getUserData().toString();
				check_delivery = deliveryGroup.getSelectedToggle().getUserData().toString();

				if (product1.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�ŷ�����");
					alert.setHeaderText("ù��° ǰ���� �Է��ؾ��մϴ�.");
					alert.setContentText("ù��° ǰ�� �Է� �� ����");
					alert.showAndWait();

					txtProduct1.requestFocus();
				} else if (check_payment.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�ŷ�����");
					alert.setHeaderText("�������θ� �����Ͻʽÿ�.");
					alert.setContentText("�������� �Է� �� ����");
					alert.showAndWait();

					rbBeforePayment.requestFocus();
				} else if (check_delivery.equals("")) {
					Alert alert = new Alert(AlertType.WARNING);
					alert.setTitle("�ŷ�����");
					alert.setHeaderText("��ۿ��θ� �����Ͻʽÿ�.");
					alert.setContentText("��ۿ��� �Է� �� ����");
					alert.showAndWait();

					rbStock.requestFocus();
				} else {
					dao = new TransactionDAO();
					model = new TransactionVO();

					transactionNo = Integer.parseInt(txtTransactionNo.getText());
					customer = txtCustomer.getText();
					memberNo = Integer.parseInt(txtMemberNo.getText());

					product1 = txtProduct1.getText();
					colour1 = cbColour1.getSelectionModel().getSelectedItem();
					yard1 = Double.parseDouble(txtYard1.getText().trim());
					product2 = txtProduct2.getText();
					colour2 = cbColour2.getSelectionModel().getSelectedItem();
					yard2 = Double.parseDouble(txtYard2.getText().trim());
					product3 = txtProduct3.getText();
					colour3 = cbColour3.getSelectionModel().getSelectedItem();
					yard3 = Double.parseDouble(txtYard3.getText().trim());
					discount = Double.parseDouble(txtDiscount.getText().trim());
					price = Integer.parseInt(txtPrice.getText());
					address = txtAddress.getText();
					check_delivery = deliveryGroup.getSelectedToggle().getUserData().toString();
					check_payment = paymentGroup.getSelectedToggle().getUserData().toString();
					memo = txtMemo.getText();

					int customerNo = dao.callCustomerNo(customer);
					model.setTransaction_no(transactionNo);
					model.setCustomer_no(customerNo);
					model.setMember_no(memberNo);
					model.setStock_no1(0);
					model.setStock_no2(0);
					model.setStock_no3(0);
					model.setYard1(yard1);
					model.setYard2(yard2);
					model.setYard3(yard3);
					model.setDiscount(discount);
					model.setPayment(price);
					model.setAddress(address);
					model.setCheck_payment(check_payment);
					model.setCheck_delivery(check_delivery);
					model.setMemo(memo);

					String abb1 = model.colourNameChange(colour1);
					String abb2 = model.colourNameChange(colour2);
					String abb3 = model.colourNameChange(colour3);

					orderList = product1 + "/" + abb1 + "/" + yard1 + " " + product2 + "/" + abb2 + "/" + yard2 + " "
							+ product3 + "/" + abb3 + "/" + yard3;
					model.setOrderList(orderList);

					model.setStock_no1(nullToValue(product1, colour1));
					model.setStock_no2(nullToValue(product2, colour2));
					model.setStock_no3(nullToValue(product3, colour3));

					update1 = dao.updateTransactionInformation(model);

					if (update1) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("�ŷ�����");
						alert.setHeaderText("'�˻�'��ư�� ������ �ŷ������ �����Ͻʽÿ�.");
						alert.setContentText("�ŷ����� �Ϸ�");
						alert.showAndWait();

						handlerBtnOkAction(event);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return update1;
	}

	public void handlerBtnOkAction(ActionEvent event) {
		try {
			Stage mainMtage = (Stage) btnOk.getScene().getWindow();
			mainMtage.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int nullToValue(String name, String colour) {
		int stockNo = 0;
		TransactionDAO dao = new TransactionDAO();

		if (name.equals("") && colour.equals("")) {
			stockNo = 0;
		} else {
			stockNo = dao.returnStockNo(name, colour);
		}
		return stockNo;
	}

	public boolean handlerBtnCalculateConditionAction(ActionEvent event) {
		boolean condition = false;
		int cost1 = 0;
		int cost2 = 0;
		int cost3 = 0;
		double yard1 = 0.0;
		double yard2 = 0.0;
		double yard3 = 0.0;
		double discount = 0.0; // ���η��� 0 % ~ 20 %

		try {
			cost1 = Integer.parseInt(txtCost1.getText().trim());
			cost2 = Integer.parseInt(txtCost2.getText().trim());
			cost3 = Integer.parseInt(txtCost3.getText().trim());
			yard1 = Double.parseDouble(txtYard1.getText().trim());
			yard2 = Double.parseDouble(txtYard2.getText().trim());
			yard3 = Double.parseDouble(txtYard3.getText().trim());

			discount = Double.parseDouble(txtDiscount.getText().trim()) / 100;

			if (cost1 != 0 && yard1 == 0) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �� �Է�");
				alert.setHeaderText("ǰ��1�� �ߵ���� �Է��Ͻʽÿ�.");
				alert.setContentText("ǰ��1�� ���� �� ����");
				alert.showAndWait();
			} else if (cost2 != 0 && yard2 == 2) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �� �Է�");
				alert.setHeaderText("ǰ��2�� �ߵ���� �Է��Ͻʽÿ�.");
				alert.setContentText("ǰ��2�� ���� �� ����");
				alert.showAndWait();
			} else if (cost3 != 0 && yard3 == 2) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� �� �Է�");
				alert.setHeaderText("ǰ��3�� �ߵ���� �Է��Ͻʽÿ�.");
				alert.setContentText("ǰ��3�� ���� �� ����");
				alert.showAndWait();
			}

			if (yard1 < 0 || yard2 < 0 || yard3 < 0) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�ߵ�� �Է� ����");
				alert.setHeaderText("�ߵ���� ���� ������ �Է��Ͻʽÿ�.");
				alert.setContentText("�ߵ�� ���Է�");
				alert.showAndWait();
			} else if (discount < 0 || 20 < discount) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���η� �Է� ����");
				alert.setHeaderText("�������� 0% �̻� 20% �̸��� ������ �Է��Ͻʽÿ�.");
				alert.setContentText("������ ���Է�");
				alert.showAndWait();
				txtDiscount.requestFocus();
			} else {
				condition = true;
			}
		} catch (NumberFormatException e) {
			System.out.println(e);
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("���� �Է� ����");
			alert.setHeaderText("���ڸ� ��Ȯ�� �Է��Ͻʽÿ�.");
			alert.setContentText("���Է�");
			alert.showAndWait();
		}

		return condition;
	}

	public void handlerBtnCalculateAction(ActionEvent event) {
		boolean condition = handlerBtnCalculateConditionAction(event);
		int cost1 = 0;
		int cost2 = 0;
		int cost3 = 0;
		double yard1 = 0.0;
		double yard2 = 0.0;
		double yard3 = 0.0;
		double discount = 0.0; // ���η��� 0 % ~ 20 %
		double excludeVat = 0;
		int vat = 0;
		int price = 0;

		try {
			if (condition && event.getSource().equals(btnCal)) {
				cost1 = Integer.parseInt(txtCost1.getText().trim());
				cost2 = Integer.parseInt(txtCost2.getText().trim());
				cost3 = Integer.parseInt(txtCost3.getText().trim());

				yard1 = Double.parseDouble(txtYard1.getText().trim());
				yard2 = Double.parseDouble(txtYard2.getText().trim());
				yard3 = Double.parseDouble(txtYard3.getText().trim());

				discount = Double.parseDouble(txtDiscount.getText().trim()) / 100;
				excludeVat = (cost1 * yard1 + cost2 * yard2 + cost3 * yard3)
						- (cost1 * yard1 + cost2 * yard2 + cost3 * yard3) * discount;
				vat = (int) (excludeVat * 0.1);
				price = (int) (excludeVat) + vat;
				txtPrice.setText(price + "");

				btnOk.setDisable(false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
