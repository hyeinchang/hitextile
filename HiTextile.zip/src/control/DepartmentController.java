package control;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class DepartmentController implements Initializable {
	@FXML
	private ImageView btnShop;
	@FXML
	private ImageView btnWarehouse;
	@FXML
	private ImageView btnOffice;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		btnShop.setOnMouseClicked(event -> HandlerBtnShopLoginAction(event));
		btnWarehouse.setOnMouseClicked(event -> HandlerBtnWarehouseLoginAction(event));
		btnOffice.setOnMouseClicked(event -> HandlerBtnOfficeLoginAction(event));
	}

	public void HandlerBtnOfficeLoginAction(MouseEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/login_office.fxml"));
			Parent login_office = (Parent) loader.load();
			Scene scene = new Scene(login_office);
			Stage mainStage = new Stage();
			mainStage.setScene(scene);
			mainStage.setResizable(false);
			mainStage.setTitle("Login");
			Stage oldStage = (Stage) btnOffice.getScene().getWindow();
			oldStage.close();
			mainStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void HandlerBtnWarehouseLoginAction(MouseEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/login_warehouse.fxml"));
			Parent login_warehouse = (Parent) loader.load();
			Scene scene = new Scene(login_warehouse);
			Stage mainStage = new Stage();
			mainStage.setScene(scene);
			mainStage.setResizable(false);
			mainStage.setTitle("Login");
			Stage oldStage = (Stage) btnWarehouse.getScene().getWindow();
			oldStage.close();
			mainStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void HandlerBtnShopLoginAction(MouseEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/login_shop.fxml"));
			Parent login_shop = (Parent) loader.load();
			Scene scene = new Scene(login_shop);
			Stage mainStage = new Stage();
			mainStage.setScene(scene);
			mainStage.setResizable(false);
			mainStage.setTitle("Login");
			Stage oldStage = (Stage) btnShop.getScene().getWindow();
			oldStage.close();
			mainStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
