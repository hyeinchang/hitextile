package control;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import model.TransactionVO;

public  class FileSaveController implements Initializable{
	@FXML
	private TextField txtSave;
	@FXML
	private Button btnSave;
	@FXML
	private Button btnExcel;
	@FXML
	private Button btnOk;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		btnOk.setOnAction(event -> handlerBtnOkAction(event));
		btnExcel.setOnAction(event -> handlerBtnExcelAction(event));
		btnSave.setOnAction(event -> handlerBtnSaveAction(event));
	}
	
	public void handlerBtnSaveAction(ActionEvent event) {
		Stage primaryStage = new Stage();
		final DirectoryChooser directoryChooser = new DirectoryChooser();
		final File selectedDiretory = directoryChooser.showDialog(primaryStage);
		
		if (selectedDiretory != null) {
			txtSave.setText(selectedDiretory.getAbsolutePath());
			btnExcel.setDisable(false);
		}
	}
	
	public void handlerBtnExcelAction(ActionEvent event) {
		TransactionDAO dao = new TransactionDAO();
		boolean saveSuccess;
		ArrayList<TransactionVO> list;
		list = dao.getOfficeTransactionInformation();
		
		saveSuccess = xlsxWriter(list, txtSave.getText());
		if (saveSuccess) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("���� ���� ����");
			alert.setHeaderText("�ŷ����� ���� ���� ������ �����߽��ϴ�.");
			alert.setContentText("�ŷ����� ���� ���� ���� �Ϸ�");
			alert.showAndWait();
		}
		txtSave.clear();
		btnExcel.setDisable(true);
	}
	
	public void handlerBtnOkAction(ActionEvent event) {
		try {
			Stage stage = (Stage) btnOk.getScene().getWindow();
			stage.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean xlsxWriter(List<TransactionVO> list, String saveDir) {
		boolean saveSuccess = false;
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet();
		XSSFRow row = sheet.createRow(0);
		XSSFCell cell;
		cell = row.createCell(0);
		cell.setCellValue("�ŷ�no");
		cell = row.createCell(1);
		cell.setCellValue("�����");
		cell = row.createCell(2);
		cell.setCellValue("�ŷ�ó");
		cell = row.createCell(3);
		cell.setCellValue("�ֹ�����");
		cell = row.createCell(4);
		cell.setCellValue("������");
		cell = row.createCell(5);
		cell.setCellValue("�����ݾ�");
		cell = row.createCell(6);
		cell.setCellValue("��������");
		cell = row.createCell(7);
		cell.setCellValue("�޸�");
		cell = row.createCell(8);
		cell.setCellValue("�����");
		
		TransactionVO model;
		for (int rowIndex = 0; rowIndex < list.size(); rowIndex++) {
			model = list.get(rowIndex);
			
			row = sheet.createRow(rowIndex + 1); 
			cell = row.createCell(0);
			cell.setCellValue(model.getTransaction_no());
			cell = row.createCell(1);
			cell.setCellValue(model.getMemberName());
			cell = row.createCell(2);
			cell.setCellValue(model.getCustomerName());
			cell = row.createCell(3);
			cell.setCellValue(model.getOrderList());
			cell = row.createCell(4);
			cell.setCellValue(model.getDiscount());
			cell = row.createCell(5);
			cell.setCellValue(model.getPayment());
			cell = row.createCell(6);
			cell.setCellValue(model.getCheck_payment());
			cell = row.createCell(7);
			cell.setCellValue(model.getMemo());
			cell = row.createCell(8);
			cell.setCellValue(model.getTransaction_date());
		}
		
		String strReportPDFName = "transaction_" +System.currentTimeMillis() + ".xlsx";
		File file = new File(saveDir + "\\" + strReportPDFName);
		FileOutputStream fos = null;
		
		try {
			fos = new FileOutputStream(file);
			if (fos != null) {
				workbook.write(fos);
				saveSuccess = true;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (workbook != null)
					workbook.close();
				if (fos != null)
					fos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return saveSuccess;
	}
}
