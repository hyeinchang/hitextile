package model;

public class MemberVO {
	private int mamber_no;
	private String id;
	private String password;
	private String member_name;
	private String member_phone;
	private String department;
	private String position;
	
	public MemberVO() {
		super();
	}

	public MemberVO(int mamber_no, String id, String password, String member_name, String member_phone, String department,
			String position) {
		super();
		this.mamber_no = mamber_no;
		this.id = id;
		this.password = password;
		this.member_name = member_name;
		this.member_phone = member_phone;
		this.department = department;
		this.position = position;
	}

	public MemberVO(String id, String password, String member_name, String member_phone, String department,
			String position) {
		super();
		this.id = id;
		this.password = password;
		this.member_name = member_name;
		this.member_phone = member_phone;
		this.department = department;
		this.position = position;
	}

	public int getMamber_no() {
		return mamber_no;
	}

	public void setMamber_no(int mamber_no) {
		this.mamber_no = mamber_no;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMember_name() {
		return member_name;
	}

	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}

	public String getMember_phone() {
		return member_phone;
	}

	public void setMember_phone(String member_phone) {
		this.member_phone = member_phone;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
	
}	