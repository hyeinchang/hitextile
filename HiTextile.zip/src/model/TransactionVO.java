package model;

public class TransactionVO {
	private int transaction_no;
	private int member_no;
	private int customer_no;
	private int stock_no1;
	private int stock_no2;
	private int stock_no3;
	private double yard1;
	private double yard2;
	private double yard3;
	private double discount;
	private int payment;
	private String check_payment;
	private String address;
	private String check_delivery;
	private String memo;
	private String transaction_date;
	
	private String customerName;
	private String product1;
	private String product2;
	private String product3;
	
	private String orderList;
	
	private String contact1;
	private String contact2;
	private String colour1;
	private String colour2;
	private String colour3;
	
	private String memberName;
	
	private String member_name;
	private String customer_name;
	
	public String getMember_name() {
		return member_name;
	}

	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String colourNameChange(String colourName) {
		String abb = "";
		if (colourName.equals("ȭ��Ʈ")) {
			abb = "wh";
		} else if (colourName.equals("������")) {
			abb = "bg";
		} else if (colourName.equals("��ũ")) {
			abb = "pk";
		} else if (colourName.equals("����")) {
			abb = "bu";
		} else if (colourName.equals("����")) {
			abb = "bk";		
		} else if (colourName.equals("")) {
			abb = " ";
		} else if (colourName == null) {
			abb = " ";
		} else {
			abb = " ";
		}
		
		return abb;
	}

	public TransactionVO() {
		super();
	}

	public TransactionVO(int transaction_no, int member_no, int customer_no, int stock_no1, int stock_no2,
			int stock_no3, double yard1, double yard2, double yard3, double discount, int payment, String check_payment,
			String address, String check_delivery, String memo, String transaction_date, String customerName,
			String product1, String product2, String product3, String orderList, String contact1, String contact2,
			String colour1, String colour2, String colour3) {
		super();
		this.transaction_no = transaction_no;
		this.member_no = member_no;
		this.customer_no = customer_no;
		this.stock_no1 = stock_no1;
		this.stock_no2 = stock_no2;
		this.stock_no3 = stock_no3;
		this.yard1 = yard1;
		this.yard2 = yard2;
		this.yard3 = yard3;
		this.discount = discount;
		this.payment = payment;
		this.check_payment = check_payment;
		this.address = address;
		this.check_delivery = check_delivery;
		this.memo = memo;
		this.transaction_date = transaction_date;
		this.customerName = customerName;
		this.product1 = product1;
		this.product2 = product2;
		this.product3 = product3;
		this.orderList = orderList;
		this.contact1 = contact1;
		this.contact2 = contact2;
		this.colour1 = colour1;
		this.colour2 = colour2;
		this.colour3 = colour3;
	}

	public int getTransaction_no() {
		return transaction_no;
	}

	public void setTransaction_no(int transaction_no) {
		this.transaction_no = transaction_no;
	}

	public int getMember_no() {
		return member_no;
	}

	public void setMember_no(int member_no) {
		this.member_no = member_no;
	}

	public int getCustomer_no() {
		return customer_no;
	}

	public void setCustomer_no(int customer_no) {
		this.customer_no = customer_no;
	}

	public int getStock_no1() {
		return stock_no1;
	}

	public void setStock_no1(int stock_no1) {
		this.stock_no1 = stock_no1;
	}

	public int getStock_no2() {
		return stock_no2;
	}

	public void setStock_no2(int stock_no2) {
		this.stock_no2 = stock_no2;
	}

	public int getStock_no3() {
		return stock_no3;
	}

	public void setStock_no3(int stock_no3) {
		this.stock_no3 = stock_no3;
	}

	public double getYard1() {
		return yard1;
	}

	public void setYard1(double yard1) {
		this.yard1 = yard1;
	}

	public double getYard2() {
		return yard2;
	}

	public void setYard2(double yard2) {
		this.yard2 = yard2;
	}

	public double getYard3() {
		return yard3;
	}

	public void setYard3(double yard3) {
		this.yard3 = yard3;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public int getPayment() {
		return payment;
	}

	public void setPayment(int payment) {
		this.payment = payment;
	}

	public String getCheck_payment() {
		return check_payment;
	}

	public void setCheck_payment(String check_payment) {
		this.check_payment = check_payment;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCheck_delivery() {
		return check_delivery;
	}

	public void setCheck_delivery(String check_delivery) {
		this.check_delivery = check_delivery;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getTransaction_date() {
		return transaction_date;
	}

	public void setTransaction_date(String transaction_date) {
		this.transaction_date = transaction_date;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProduct1() {
		return product1;
	}

	public void setProduct1(String product1) {
		this.product1 = product1;
	}

	public String getProduct2() {
		return product2;
	}

	public void setProduct2(String product2) {
		this.product2 = product2;
	}

	public String getProduct3() {
		return product3;
	}

	public void setProduct3(String product3) {
		this.product3 = product3;
	}

	public String getOrderList() {
		return orderList;
	}

	public void setOrderList(String orderList) {
		this.orderList = orderList;
	}

	public String getContact1() {
		return contact1;
	}

	public void setContact1(String contact1) {
		this.contact1 = contact1;
	}

	public String getContact2() {
		return contact2;
	}

	public void setContact2(String contact2) {
		this.contact2 = contact2;
	}

	public String getColour1() {
		return colour1;
	}

	public void setColour1(String colour1) {
		this.colour1 = colour1;
	}

	public String getColour2() {
		return colour2;
	}

	public void setColour2(String colour2) {
		this.colour2 = colour2;
	}

	public String getColour3() {
		return colour3;
	}

	public void setColour3(String colour3) {
		this.colour3 = colour3;
	}
	
}	