package control;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.net.ssl.HandshakeCompletedListener;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import model.StockVO;

public class ProductInformationController implements Initializable {
	@FXML
	private TableView<StockVO> productTable;
	ObservableList<StockVO> product = FXCollections.observableArrayList();
	StockDAO dao = null;
	int stockNo = 0;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		dao = new StockDAO();
		productTable.setEditable(false);
		TableColumn colStock_no = new TableColumn("���no");
		colStock_no.setMinWidth(60);
		colStock_no.setMaxWidth(60);
		colStock_no.setStyle("-fx-alignment:CENTER");
		colStock_no.setCellValueFactory(new PropertyValueFactory<>("stock_no"));
		TableColumn colFabric_name = new TableColumn("���ܸ�");
		colFabric_name.setMinWidth(100);
		colFabric_name.setMaxWidth(100);
		colFabric_name.setStyle("-fx-alignment:CENTER");
		colFabric_name.setCellValueFactory(new PropertyValueFactory<>("fabric_name"));
		TableColumn colFabric_colour = new TableColumn("�÷�");
		colFabric_colour.setMinWidth(70);
		colFabric_colour.setMaxWidth(70);
		colFabric_colour.setStyle("-fx-alignment:CENTER");
		colFabric_colour.setCellValueFactory(new PropertyValueFactory<>("fabric_colour"));
		TableColumn colFabric_material = new TableColumn("����");
		colFabric_material.setMinWidth(140);
		colFabric_material.setMaxWidth(140);
		colFabric_material.setCellValueFactory(new PropertyValueFactory<>("fabric_material"));
		TableColumn colFabric_cost = new TableColumn("�ܰ�");
		colFabric_cost.setMinWidth(70);
		colFabric_cost.setMaxWidth(70);
		colFabric_cost.setStyle("-fx-alignment:CENTER");
		colFabric_cost.setCellValueFactory(new PropertyValueFactory<>("fabric_cost"));
		TableColumn colStock = new TableColumn("���");
		colStock.setMinWidth(85);
		colStock.setMaxWidth(85);
		colStock.setStyle("-fx-alignment:CENTER");
		colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));
		TableColumn colStock_memo = new TableColumn("�޸�");
		colStock_memo.setMinWidth(123);
		colStock_memo.setMaxWidth(123);
		colStock_memo.setCellValueFactory(new PropertyValueFactory<>("stock_memo"));
		
		productTable.setItems(product);
		productTable.getColumns().addAll(colStock_no,colFabric_name,colFabric_colour,colFabric_material,
				colFabric_cost,colStock,colStock_memo);
		productList();
		
		productTable.setOnMouseClicked(event -> handlerEditProductAction(event));
		
	}
	
	public void handlerEditProductAction(MouseEvent event) {
		
		stockNo = productTable.getSelectionModel().getSelectedItem().getStock_no();
		
		try {
			RecordDAO dao = new RecordDAO();
			dao.insertNo(stockNo);
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/record_stock.fxml"));
			Parent mainView = (Parent) loader.load();
			Scene scene = new Scene(mainView);
			Stage mainMtage = new Stage();
			mainMtage.setScene(scene);
			mainMtage.setTitle("��ǰ ����");
			mainMtage.setResizable(false);
			mainMtage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void productList() {
		Object[][] productData;
		
		StockDAO dao = new StockDAO();
		StockVO model = null;
		ArrayList<String> title;
		ArrayList<StockVO> productList;
		
		title = dao.getProductColoumnName();
		int columnCount = title.size();
		
		productList = dao.getProductInformation();
		int rowCount = productList.size();
		
		productData = new Object[rowCount][columnCount];
		
		for (int index = 0; index < rowCount; index++) {
			model = productList.get(index);
			product.add(model);
		}
	}
}
