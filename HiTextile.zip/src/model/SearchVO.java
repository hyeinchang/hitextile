package model;

import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;
import javafx.scene.control.SingleSelectionModel;

public class SearchVO {
	int member_no;
	int customer_no;
	int stock_no;
	int transaction_no;
	String member_name;
	String memberName;
	String customer_name;
	String customerName;
	String fabric_name;
	String orderList;
	String fabric_colour;
	String stock_date;
	String transaction_date;
	int payment;
	String check_payment;
	String check_delivery;
	String fabric_material;
	String stock_memo;
	String memo;
	String address;
	String contact1;
	String contact2;
	String id;
	String department;
	String position;
	String member_phone;
	public int getMember_no() {
		return member_no;
	}
	public void setMember_no(int member_no) {
		this.member_no = member_no;
	}
	public int getCustomer_no() {
		return customer_no;
	}
	public void setCustomer_no(int customer_no) {
		this.customer_no = customer_no;
	}
	public int getStock_no() {
		return stock_no;
	}
	public void setStock_no(int stock_no) {
		this.stock_no = stock_no;
	}
	public int getTransaction_no() {
		return transaction_no;
	}
	public void setTransaction_no(int transaction_no) {
		this.transaction_no = transaction_no;
	}
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getFabric_name() {
		return fabric_name;
	}
	public void setFabric_name(String fabric_name) {
		this.fabric_name = fabric_name;
	}
	public String getOrderList() {
		return orderList;
	}
	public void setOrderList(String orderList) {
		this.orderList = orderList;
	}
	public String getFabric_colour() {
		return fabric_colour;
	}
	public void setFabric_colour(String fabric_colour) {
		this.fabric_colour = fabric_colour;
	}
	public String getStock_date() {
		return stock_date;
	}
	public void setStock_date(String stock_date) {
		this.stock_date = stock_date;
	}
	public String getTransaction_date() {
		return transaction_date;
	}
	public void setTransaction_date(String transaction_date) {
		this.transaction_date = transaction_date;
	}
	public int getPayment() {
		return payment;
	}
	public void setPayment(int payment) {
		this.payment = payment;
	}
	public String getCheck_payment() {
		return check_payment;
	}
	public void setCheck_payment(String check_payment) {
		this.check_payment = check_payment;
	}
	public String getCheck_delivery() {
		return check_delivery;
	}
	public void setCheck_delivery(String check_delivery) {
		this.check_delivery = check_delivery;
	}
	public String getFabric_material() {
		return fabric_material;
	}
	public void setFabric_material(String fabric_material) {
		this.fabric_material = fabric_material;
	}
	public String getStock_memo() {
		return stock_memo;
	}
	public void setStock_memo(String stock_memo) {
		this.stock_memo = stock_memo;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getContact1() {
		return contact1;
	}
	public void setContact1(String contact1) {
		this.contact1 = contact1;
	}
	public String getContact2() {
		return contact2;
	}
	public void setContact2(String contact2) {
		this.contact2 = contact2;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getMember_phone() {
		return member_phone;
	}
	public void setMember_phone(String member_phone) {
		this.member_phone = member_phone;
	}
	
	public String nullToValue(String value) {
		String str = "";
		if (value.equals("")) {
			str = " ";
		} else {
			str = value;
		}
		return str;
	}
	
	public String nullToValue2(String value) {
		String str = "";
		if (value == null) {
			str = " ";
		} else {
			str = value;
		}
		return str;
	}
	
	public String nullToValue3(String value) {
		String number = "";
		if (value.equals("")) {
			number = "0";
		} else {
			number = value;
		}
		return number;
	}
	
	public String colourNameChange(String colourName) {
		String abb = "";
		if (colourName == null) {
			abb = " ";
		} else if (colourName.equals("ȭ��Ʈ")) {
			abb = "wh";
		} else if (colourName.equals("������")) {
			abb = "bg";
		} else if (colourName.equals("��ũ")) {
			abb = "pk";
		} else if (colourName.equals("����")) {
			abb = "bu";
		} else if (colourName.equals("����")) {
			abb = "bk";		
		} else
			abb = " ";
		
		return abb;
	}
}
